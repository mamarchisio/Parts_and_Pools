#!/usr/bin/python
# Rule-based sirna part and corresponding pool generator 

import re
import sys
import os
from collections import defaultdict

#------------------------------------------------------------

##############################
# Start of the IN program
#############################

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('siRNA.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# sirna name
sirna_name=inp_values[0]
print 'sirna_name', sirna_name

# polymerase leakage
pol_lk=inp_values[1]
if pol_lk != 'y' and pol_lk != 'n':
    print "Error. Polymerase leakage can be either 'y' or 'n'."
    sys.exit()
print "pol_lk",pol_lk

# sirna length
sirna_length=int(inp_values[2])
print 'sirna_length', sirna_length
v_pol=23.3 # RNA polymerase elongation rate 
k_el=v_pol/float(sirna_length)  

# dicer-dsDNA binding rate
k1d=float(inp_values[3])

# dicer-dsDNA unbinding rate
k_1d=float(inp_values[4])

# n_sirna production rate
k2d=float(inp_values[5])

# sirna maturation rate
km=float(inp_values[6])

# RISC-sirna binding rate
k1risc=float(inp_values[7])

# RISC-sirna unbinding rate
k_1risc=float(inp_values[8])

# promoter name (leakage)
promoter_name=inp_values[9].lower()

################################################
# Coding region generation: MDL file directly
#  PoPSin => [PolA]
#  [PolA] -> Pol_el + dsRNA (k_el)
#  D_free + dsRNA <-> [DdsRNA] (k1d,k_1d)
# [DdsRNA] -> D_free + n_sirna (k2d)
# n_sirna -> sirna (km) 
# ds_RNA -> (k_d)
# n_sirna -> (k_d)
# [DdsRNA] -> D_free (k_d)

# Opening the output file
nuclear_sirna=sirna_name+'_coding'
fname=nuclear_sirna+'.mdl'
out_file=open(fname,'w')

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-terminal
  :class "term-para-in"
  :super-classes ("terminal")
  :documentation "Input terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-input")))

(define-terminal
  :class "term-para-out"
  :super-classes ("terminal")
  :documentation "Output terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-output")))

(define-module
  :class "%(nuclear_sirna)s"
  :super-classes ("module")
  :icon "coding.png"
  :parameters(
  ("pola.c0"
   :value "0")
  ("dsRNA.c0"
   :value "0")
  ("DdsRNA.c0"
   :value "0")
  ("n_sirna.c0"
   :value "0")
  ("k_el.k1"
   :value "%(k_el)f")
  ("k_el.r"
   :value "parent.v*k1*a.c")   
  ("k1d.k1"
   :value "%(k1d)f")
  ("k1d.r"
   :value "parent.v*k1*a.c*b.c")   
  ("k_1d.k1"
   :value "%(k_1d)f")
  ("k_1d.r"
   :value "parent.v*k1*a.c")
  ("k2d.k1"
   :value "%(k2d)f")
  ("k2d.r"
   :value "parent.v*k1*a.c")
  ("km.k1"
   :value "%(km)f")
  ("km.r"
   :value "parent.v*k1*a.c")
  )
  :terminals
  (("in_pol"
    :is-eq-to "pops_in.in"
    :geometry-side "LEFT"
    :geometry-position "0.1")
   ("out_pol"
    :is-eq-to "pops_out.out"
    :geometry-side "RIGHT"
    :geometry-position "0.1")
   ("exc_D"
    :is-eq-to "Dps_b.in"
    :geometry-side "LEFT"
    :geometry-position "0.5")
   ("out_%(sirna_name)s"
    :is-eq-to "RNAps_out.out"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
   ("k_d_in"
    :is-a "term-para-in"
    :geometry-side "RIGHT"
    :geometry-position "0.5")
   ("out_k_d_%(sirna_name)s"
    :is-a "term-para-out"
    :geometry-side "BOTTOM"
    :geometry-position "0.9")
   )
  :modules(
   ("pops_in"
     :is-a "adapter-flux")
   ("Dps_b"
    :is-a "adapter-flux")
   ("pops_out"
    :is-a "adapter-flux")
   ("RNAps_out"
    :is-a "adapter-flux")
   ("pola"
     :is-a "storage-intra")
   ("dsRNA"
     :is-a "storage-intra")
   ("DdsRNA"
     :is-a "storage-intra")
   ("n_sirna"
     :is-a "storage-intra")
   ("k_el"
     :is-a "trans3a-fi1_r")
   ("k1d"
     :is-a "trans3a-fi2ab_r")
   ("k_1d"
     :is-a "trans3a-fi1_r")
   ("k2d"
     :is-a "trans3a-fi1_r")
   ("km"
     :is-a "trans2a-fi1_r")
   ("kd_ds"
     :is-a "trans1a-fi1_r"
    :variables(       
    ("k1"
     :is-eq-to "parent.kd")
    ("r"
     :value "parent.v*k1*a.c")))     
   ("kd_n"
     :is-a "trans1a-fi1_r"
    :variables(       
    ("k1"
     :is-eq-to "parent.kd")
    ("r"
     :value "parent.v*k1*a.c")))
   ("kd_dd"
     :is-a "trans2a-fi1_r"
    :variables(       
    ("k1"
     :is-eq-to "parent.kd")
    ("r"
     :value "parent.v*k1*a.c")))
  )
  :links(
  ("link_1"
    :terminals ("pola.cf" "k_el.a" "pops_in.out"))
  ("link_2"
    :terminals ("dsRNA.cf" "k_el.c" "k1d.b" "k_1d.b" "kd_ds.a"))
  ("link_3"
    :terminals ("n_sirna.cf" "k2d.b" "km.a" "kd_n.a"))
  ("link_4"
    :terminals ("DdsRNA.cf" "k1d.c" "k_1d.a" "k2d.a" "kd_dd.a"))
  ("link_5"
    :terminals ("RNAps_out.in" "km.b"))
  ("link_6"
    :terminals ("pops_out.in" "k_el.b"))
  ("link_7"
    :terminals ("Dps_b.out" "k1d.a" "k_1d.c" "k2d.c" "kd_dd.b"))
  )
  :variables(
  ("kd"
    :is-eq-to "k_d_in.k"))  
  :equations(
  ("set_k_out"
   :relation "out_k_d_%(sirna_name)s.k == kd")
  )) ''' %locals()

out_file.write(lines)
out_file.close()

###########
# sirna pool in the cytoplasm, MDL file generator
# sirna -> (k_d)
# RISC_free + sirna <-> [risi] (k1risc,k_1risc)
# [risi] -> RISC_free (k_d)


#@@@@@@@@@@@
# MDL file generator
fname=sirna_name+'_pool.mdl'
cy_sirna=sirna_name+'_pool'
out_file=open(fname,'w')

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-terminal
  :class "term-para-in"
  :super-classes ("terminal")
  :documentation "Input terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-input")))

(define-module
  :class "%(cy_sirna)s"
  :super-classes ("module")
  :icon "sirna_pool.png"
  :parameters(
  ("sirna.c0"
   :value "0")
  ("risi.c0"
   :value "0")
  ("k1risc.k1"
   :value "%(k1risc)f")
  ("k1risc.r"
   :value "parent.v*k1*a.c*b.c")
  ("k_1risc.k1"
   :value "%(k_1risc)f")
  ("k_1risc.r"
   :value "parent.v*k1*a.c")
  )
  :terminals
  (("in_%(sirna_name)s"
    :is-eq-to "RNAps_in.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
   ("exc_risc"
    :is-eq-to "riscps_b.in"
    :geometry-side "RIGHT"
    :geometry-position "0.7")
   ("exc_%(sirna_name)s"
    :is-eq-to "risips_b.in"
    :geometry-side "LEFT"
    :geometry-position "0.7")
''' %locals()
out_file.write(lines)

if pol_lk == 'y':
    lines='''   ("in_pol_lk_%(promoter_name)s"
    :is-eq-to "pops_in_lk.in"
    :geometry-side "TOP"
    :geometry-position "0.5")
''' %locals()
    out_file.write(lines)

lines='''   ("in_k_d_%(sirna_name)s"
    :is-a "term-para-in"
    :geometry-side "TOP"
    :geometry-position "0.9"))
  :modules(
   ("RNAps_in"
    :is-a "adapter-flux")
   ("riscps_b"
    :is-a "adapter-flux")
   ("risips_b"
    :is-a "adapter-flux")
''' %locals()
out_file.write(lines)    

if pol_lk == 'y':
    lines='''   ("pops_in_lk"
    :is-a "adapter-flux")
''' %locals()
    out_file.write(lines)    
    
lines='''   ("sirna"
    :is-a "storage-intra")
   ("risi"
    :is-a "storage-intra")
   ("k1risc"
    :is-a "trans3a-fi2ab_r")
   ("k_1risc"
    :is-a "trans3a-fi1_r")
   ("kd_s"
    :is-a "trans1a-fi1_r"
    :variables(       
    ("k1"
     :is-eq-to "parent.kd")
    ("r"
     :value "parent.v*k1*a.c")))
   ("kd_risi"
     :is-a "trans2a-fi1_r"
    :variables(       
    ("k1"
     :is-eq-to "parent.kd")
    ("r"
     :value "parent.v*k1*a.c"))))
  :links(
  ("link_1"
   :terminals ("sirna.cf" "k1risc.b" "k_1risc.c" "kd_s.a" "RNAps_in.out"'''%locals()
out_file.write(lines)
   
if pol_lk == 'y':
    out_file.write(' "pops_in_lk.out"')

out_file.write('))\n')   
   
lines='''  ("link_2"
   :terminals ("risi.cf" "k1risc.c" "k_1risc.a" "kd_risi.a" "risips_b.out"))
  ("link_3"
   :terminals ("riscps_b.out" "k1risc.a" "k_1risc.b" "kd_risi.b")))
  :variables(
  ("kd"
    :is-eq-to "in_k_d_%(sirna_name)s.k"))) ''' %locals()

out_file.write(lines)
out_file.close()

