#!/usr/bin/python
# Eukaryotic pool generator 

import re
import sys
import os
from collections import defaultdict

#------------------------------------------------------------

##############################
# Start of the MAIN program
#############################

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('EU_pools.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# terminator name
pool_kind=inp_values[0]
available_kinds=['polymerase','ribosome','spliceosome','dicer','risc']

if pool_kind not in available_kinds:
    print "Error. The pool kind is not correct. You wrote: ", pool_kind
    sys.exit()

print 'pool_kind', pool_kind

# free molecule concentration
free_conc=inp_values[1]
if re.search('e',free_conc):
    free_conc=re.sub('e','d',free_conc)

if free_conc == 'd':
    if pool_kind == 'polymerase':
        free_conc = '1.3d-7'  #'1.1d-5'
    elif pool_kind == 'ribosome':
        free_conc = '5.0d-8'  #'8d-7'
    elif pool_kind == 'spliceosome':
        free_conc = '1.3d-7'  #'1.2d-5'
    elif pool_kind == 'dicer':
        free_conc = '1.3d-7'  #'1.2d-5'
    elif pool_kind == 'risc':
        free_conc = '5.0d-8'  #'2.2d-7'
    
print free_conc

molecule_dict={'polymerase': 'pol','ribosome': 'rib','spliceosome': 'y','dicer': 'dicer','risc': 'risc' }
flux_dict={'polymerase': 'pops','ribosome': 'rips','spliceosome': 'yps','dicer': 'dps','risc': 'riscps' }

molecule=molecule_dict[pool_kind]
flux=flux_dict[pool_kind]

# MDL file generator
pool_name=molecule+'_pool'

fname=pool_name+'.mdl'
out_file=open(fname,'w')
icon=pool_name+'.png'

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-module
  :class "%(pool_name)s"
  :super-classes ("module")
  :icon "%(icon)s"
  :parameters
  (("%(molecule)s_free.c0"
    :value "%(free_conc)s"))
  :terminals
  (("exc_%(molecule)s"
    :is-eq-to "%(flux)s_b.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1"))
  :modules
  (("%(molecule)s_free"
    :is-a "storage-intra")
   ("%(flux)s_b"
    :is-a "adapter-flux"))
  :links
  (("link_1"
    :terminals ("%(molecule)s_free.cf" "%(flux)s_b.out")))) ''' %locals()

out_file.write(lines)
out_file.close()

