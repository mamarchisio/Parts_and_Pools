#!/usr/bin/python
# Rule-based terminator part (gene) generator 

import re
import sys
import os
from collections import defaultdict

#------------------------------------------------------------

##############################
# Start of the MAIN program
#############################

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('EU_terminator.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# terminator name
terminator_name=inp_values[0]
print 'terminator_name', terminator_name

# mRNA decay rate
kd=float(inp_values[1])

# RNA polymerase-DNA separation rate
zeta=float(inp_values[2])
print 'zeta', zeta

# MDL file generator
fname=terminator_name+'.mdl'
fname=fname.lower()
out_file=open(fname,'w')

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-terminal
  :class "term-para-out"
  :super-classes ("terminal")
  :documentation "Output terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-output")))

(define-module
  :class "%(terminator_name)s"
  :super-classes ("module")
  :icon "terminator.png"
  :parameters(
  ("polt.c0"
   :value "0")
  ("zeta.k1"
   :value "%(zeta)f")
  ("zeta.r"
   :value "parent.v*k1*a.c")
  )
  :terminals
  (("in_pol"
    :is-eq-to "pops_in.in"
    :geometry-side "LEFT"
    :geometry-position "0.1")
   ("out_pol"
    :is-eq-to "pops_out.out"
    :geometry-side "RIGHT"
    :geometry-position "0.1")
   ("out_k_d"
    :is-a "term-para-out"
    :geometry-side "BOTTOM"
    :geometry-position "0.9"))
  :modules(
   ("pops_in"
    :is-a "adapter-flux")
   ("pops_out"
    :is-a "adapter-flux")
   ("polt"
    :is-a "storage-intra")
   ("zeta"
    :is-a "trans2a-fi1_r"))
  :links(
  ("link_1"
   :terminals ("polt.cf" "zeta.a" "pops_in.out"))
  ("link_2"
   :terminals ("pops_out.in" "zeta.b")))
  :variables(
  ("kd"
   :system-theoretic "real-parameter"
   :value "%(kd)f"))
   :equations(
   ("set_k_out"
    :relation "out_k_d.k == kd")
   )) ''' %locals()

out_file.write(lines)
out_file.close()

