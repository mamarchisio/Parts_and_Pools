#!/usr/bin/python
# Reporter pool generator 

import re
import sys
import os
from collections import defaultdict

#------------------------------------------------------------

##############################
# Start of the MAIN program
#############################

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('reporter_pool.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# terminator name
reporter_name=inp_values[0]
print 'reporter_name', reporter_name

# reporter kind
kind=inp_values[1]
if kind != 'm' and kind != 'd':
    print "Error. Reporter can be either 'm' or 'd'."
    sys.exit()
print kind

# initial concentration
in_conc=inp_values[2]
print in_conc

# degradation rate
k_d=inp_values[3]
print k_d

# dimerization rate
delta=inp_values[4]
print delta

# dimer dissociation rate
epsilon=inp_values[5]
print epsilon

# Compartment
compartment=inp_values[6]
if compartment != 'y' and compartment != 'n':
    print "Error. Compartment can be either 'y' or 'n'."
    sys.exit()
print "compartment",compartment

# MDL file generator
fname=reporter_name+'_pool.mdl'
fname=fname.lower()
out_file=open(fname,'w')

if kind == 'm':
#    lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
    lines='''             
(define-module
 :class "%(reporter_name)s_pool"
 :super-classes ("module")
 :icon "reporter_pool.png"
 :parameters(
  ("rep_m.c0"
   :value "%(in_conc)s")
  ("k_d.k1"
   :value "%(k_d)s")
''' %locals()
    out_file.write(lines)
    if compartment == 'y':
        lines= '''  ("k_d.r"
   :value "parent.v*k1*a.c")
''' %locals()
        out_file.write(lines)
    out_file.write('  )')
    out_file.write('\n')
    lines = ''' :terminals(
  ("in_%(reporter_name)s"
   :is-eq-to "faps_in.in"
   :geometry-side "BOTTOM"
   :geometry-position "0.1"))
 :modules(
  ("faps_in"
   :is-a "adapter-flux")
  ("rep_m"
   :is-a "storage-intra")
  ("k_d"
   :is-a "trans1a-fi1_r"))
 :links(
  ("link_1"
   :terminals ("rep_m.cf" "k_d.a" "faps_in.out")))) ''' %locals()
    
    out_file.write(lines)

elif kind == 'd':
#    lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
    lines='''       
(define-module
  :class "%(reporter_name)s_pool"
  :super-classes ("module")
  :icon "reporter.png"
  :parameters(
   ("rep_m.c0"
    :value "%(in_conc)s")
   ("rep_d.c0"
    :value "0")
   ("k_d_m.k1"
    :value "%(k_d)s")
''' %locals()
    out_file.write(lines)
    if compartment == 'y':
        lines= '''   ("k_dm.r"
    :value "parent.v*k1*a.c")
''' %locals()
        out_file.write(lines)
        
    lines= '''   ("k_dd.k1"
    :value "%(k_d)s")
''' %locals()
    out_file.write(lines)
    if compartment == 'y':
        lines= '''   ("k_dd.r"
   :value "parent.v*k1*a.c")
''' %locals()
        out_file.write(lines)        
        
    lines= '''   ("delta.k1"
    :value "%(delta)s")
''' %locals()
    out_file.write(lines)
    if compartment == 'y':
        lines= '''   ("delta.r"
    :value "parent.v*k1*a.c^2")
''' %locals()
        out_file.write(lines)
        
    lines= '''   ("epsilon.k1"
    :value "%(epsilon)s")
''' %locals()
    out_file.write(lines)
    if compartment == 'y':
        lines= '''   ("epsilon.r"
    :value "parent.v*k1*a.c")
''' %locals()
        out_file.write(lines)        

    out_file.write('  )')
    out_file.write('\n')
    lines = '''  :terminals
   (("in_%(reporter_name)s"
     :is-eq-to "faps_in.in"
     :geometry-side "BOTTOM"
     :geometry-position "0.1"))
  :modules(
    ("faps_in"
    :is-a "adapter-flux")
    ("rep_m"
     :is-a "storage-intra")
    ("rep_d"
     :is-a "storage-intra") 
    ("k_dm"
     :is-a "trans1a-fi1_r")
    ("k_dd"
     :is-a "trans1a-fi1_r")
    ("delta"
     :is-a "trans2p-fi2a_r")
    ("epsilon"
     :is-a "trans2b-fi1b_r"))
  :links(
   ("link_1"
    :terminals ("rep_m.cf" "k_dm.a" "delta.a" "epsilon.b" "faps_in.out"))
   ("link_2"
    :terminals ("rep_d.cf" "k_dd.a" "delta.b" "epsilon.a")))) ''' %locals()
    
    out_file.write(lines)

out_file.close()
