#! /usr/bin/python
# Ruled-based RNAi regulated eukaryotic coding region part and (mature) mRNA pool generator
# !!!!!!!!!!!!!
# IMPORTANT
# sirna is the symbol for the comples RiSC-siRNA. A free RiSC is released in case of "sirna" degradation
# !!!!!!!!!!!!!
#####
# the reaction [rb]-->r_free + b_free + I (csi) is new and has no module
#
#####

########## TO CHECK --> s reaction

import re
import sys
import os
import itertools
from collections import defaultdict
import time

#### GLOBAL VARIABLES
species_dict={}
letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
lib_kinetics=[]
lib_structure=[]
lib_type=[]
# CREATING THE REACTION LIB FILE (.MDL)
coding_name=""
lib_name=""
#lib_file=open(lib_name,'w')
#


##### CLASSES
class Reaction:
    def __init__(self,number):
        self.number=number
        self.educts=[]
        self.products=[]
        self.educts_mult={}
        self.products_mult={}
        self.react_mult=1
        
        self.parameter=''
        self.name=''
        self.kinetics=''
        self.structure=''
        self.type=''

    def print_r(self):
        print 'Name:',self.name
        print 'Parameter:',self.parameter
        print 'Number:',self.number
        print 'Educts:',self.educts
        print 'Products:',self.products
        print 'Type:',self.type
        print 'Kinetics:',self.kinetics
        print 'Structure',self.structure

    def setName(self):
        if re.search('pops',self.parameter):
            self.name=self.parameter
        elif re.search('\*',self.parameter):
            tmp_name=self.parameter.split('*')
            self.name=tmp_name[1]+'_'+self.number
            self.parameter=tmp_name[1]
            self.react_mult=tmp_name[0]
        else:    
            self.name=self.parameter+'_'+self.number

        
    def setKinetics(self):
        # kinetics->irreversible class: for MDL file generation
#        letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        kin='fi_'
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            if edu_mult != 1:
                kin += str(edu_mult)
            lt=letters[i]
            kin += lt
        if len(self.educts) == 0:
            kin += '-'
        self.kinetics=kin

    def setStructure(self):
        # structure class: for MDL file generation
#        letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        
        st='s_'
        
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            if edu_mult != 1:
                st += str(edu_mult)
            lt=letters[i]
            st += lt
        if len(self.educts) == 0:
            st += '-'

        st += '_'   
        for i in range(0,len(self.products)):
            j=i+len(self.educts)
            pro_id=self.products[i]
            pro_name=species_dict[pro_id]
            pro_mult=self.products_mult[pro_name]
            if pro_mult != 1:
                st += str(pro_mult)
            lt=letters[j]
            st += lt
        if len(self.products) == 0:
            st += '-'
        self.structure=st

    def setType(self):
        suff=re.sub('s','trans',self.structure)
        self.type=suff

    def setEducts(self): 
   # order preserving
        checked = []
        for e in self.educts:
            if e not in checked:
                checked.append(e)
        self.educts=checked

    def setProducts(self): 
   # order preserving
        checked = []
        for e in self.products:
            if e not in checked:
                checked.append(e)
        self.products=checked

    def writeKinetics(self):
        if self.kinetics not in lib_kinetics:
            lib_kinetics.append(self.kinetics)

            cl_name=self.kinetics
            if cl_name == 'fi_-':
                self.type='constant-rate-flux'
                write_constant_rate_flux()
            else:   
                edu=[]
                for i in range(0,len(self.educts)):
                    edu_id=self.educts[i]
                    edu_name=species_dict[edu_id]
                    edu_mult=self.educts_mult[edu_name]
                    
                    if edu_mult == 1:
                        edu.append(letters[i])
                    else:
                        edu_c=''
                        for j in range(0,edu_mult):
                            edu_c += letters[i]
                            if j != edu_mult-1:
                                edu_c += '*'
                        edu.append(edu_c)
                        
                value=''
                for i in range(0,len(edu)):
                    value += edu[i]
                    value += '.c'
                    if i != len(edu)-1:
                        value +='*'
        
                lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("irreversible")
  :parameters            
   (("r"
     :value "k1*%(value)s"))
  :variables
   (("k1"
     :is-a "var-real-parameter"
     :value "1.0d0"
     :unit "g_dw/umol/h")))
''' %locals()
        
                lib_file.write(lines)


    def calcFlux(self):
        edu=[]
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            
            if edu_mult == 1:
                edu.append(letters[i])
            else:
                edu_c=''
                for j in range(0,edu_mult):
                    edu_c += letters[i]
                    if j != edu_mult-1:
                        edu_c += '*'
                edu.append(edu_c)
                
        value=''
        for i in range(0,len(edu)):
            value += edu[i]
            value += '.c'
            if i != len(edu)-1:
                value +='*'
        return value

    def writeStructure(self):
        if self.structure not in lib_structure:
            lib_structure.append(self.structure)

            cl_name=self.structure
    
            term=[]
            flux=[]
            for i in range(0,len(self.educts)):
                edu_id=self.educts[i]
                edu_name=species_dict[edu_id]
                edu_mult=self.educts_mult[edu_name]
                
                term.append(letters[i])                
                if edu_mult == 1:
                    flux.append('-r')
                else:
                    sf='-'+str(edu_mult)+'*r'
                    flux.append(sf)

            for i in range(0,len(self.products)):
                 j=i+len(self.educts)
                 pro_id=self.products[i]
                 pro_name=species_dict[pro_id]
                 pro_mult=self.products_mult[pro_name]
                 
                 term.append(letters[j])                
                 if pro_mult == 1:
                    flux.append('r')
                 else:
                    sf=str(pro_mult)+'*r'
                    flux.append(sf)

            lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("structure")
  :terminals( ''' %locals()
            lib_file.write(lines)
            
            for i in range(0,len(term)):
                c_term=term[i]
                lines='''                
  ("%(c_term)s"
    :is-a "term-reaction-flux")''' %locals()
                lib_file.write(lines)
            
            lib_file.write(')\n')
            lines='''  :equations( '''
            lib_file.write(lines)

            for i in range(0,len(term)):
                c_term=term[i]
                c_flux=flux[i]
                lines='''                
  ("stoech_%(c_term)s"
    :relation "%(c_term)s.r == %(c_flux)s")''' %locals()
                lib_file.write(lines)
            lib_file.write('))\n')
            
            
    def writeType(self):
        if self.type not in lib_type:
            lib_type.append(self.type)

            cl_name=self.type
            k_name=self.kinetics
            s_name=self.structure

            lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("%(k_name)s" "%(s_name)s")
  :properties
  (("abstract"
    :value "no"))
  :icon "icons/irrev_r")
  ''' %locals()
            lib_file.write(lines)
            
#------------------------------------------------------------

##### FUNCTIONS
def write_constant_rate_flux():
    lines = '''
(define-module
  :class "constant-rate-flux"
  :super-classes ("help" "special-reaction")
  :properties
  (("abstract"
    :value "no"))
  :icon "icons/irrev_r"
  :terminals
  (("cf"
    :is-a "term-reaction-flux"
    :geometry-side "right"
    :geometry-position "0.5"))
  :variables
  (("rate"
    :is-a "reaction-rate"
    :documentation "Constant rate"
    :system-theoretic "help"
    :value "0.0d0"))
  :equations
  (("hurg"
    :relation "cf.r == rate")))
''' %locals()
    lib_file.write(lines)

#------------------------------------------------------------
def write_rule_number(out_file):
    global ct_rl
    out_file.write('\n')
    out_file.write('// RULE ')
    out_file.write(str(ct_rl))
    #out_file.write('\n')
    ct_rl += 1
    return     
#------------------------------------------------------------
def rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics):
    eff += '()'
    rule='''    %(eff)s + %(rbsPattern)s(%(rsPattern)s,%(ribsPattern)s) <-> %(rbsPattern)s(%(change)s,%(ribsPattern)s)   %(kinetics)s  ''' % locals()
    out_file.write(rule)
    out_file.write('\n')    
    return
#------------------------------------------------------------
def rule_theta_csi_site_sirna(eff,rbsPattern,ssPattern,change,osPatternList,kinetics):
    eff += '()'
    rule='''    %(eff)s + %(rbsPattern)s(%(ssPattern)s''' % locals()
    out_file.write(rule)
    if len(osPatternList):
        for i in range(0,len(osPatternList)):
            out_file.write(',')
            out_file.write(osPatternList[i])
    out_file.write(')')
    rule=''' <-> %(rbsPattern)s(%(change)s''' % locals()
    out_file.write(rule)
    if len(osPatternList):
        for i in range(0,len(osPatternList)):
            out_file.write(',')
            out_file.write(osPatternList[i])
    out_file.write(')')
    rule='''   %(kinetics)s  ''' % locals()
    out_file.write(rule)
    out_file.write('\n')    
    return
#------------------------------------------------------------
def rule_csi_site(eff,rib_free,rbsPattern,rsPattern,ribsPattern,change,changeRib,kinetics):
    eff += '()'
    rule='''    %(rbsPattern)s(%(rsPattern)s,%(ribsPattern)s) -> %(rbsPattern)s(%(change)s,%(changeRib)s) + %(eff)s + %(rib_free)s     %(kinetics)s ''' % locals()    
    out_file.write(rule)
    out_file.write('\n')    
    return
#------------------------------------------------------------
def rule_theta_site(eff,rbsPattern,rsPattern,ribsPattern,change,changeRib,rib_free,kinetics):
    eff += '()'    
    rule='''    %(eff)s + %(rbsPattern)s(%(rsPattern)s,%(ribsPattern)s) -> %(rbsPattern)s(%(change)s,%(changeRib)s) + %(rib_free)s     %(kinetics)s ''' % locals()    
    out_file.write(rule)
    out_file.write('\n')    
    return
#------------------------------------------------------------
def rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics):
    eff += '()'
    rule='''    %(eff)s + %(rbsPattern)s(%(rsPattern1)s,%(rsPattern2)s,%(ribsPattern)s) <-> %(rbsPattern)s(%(change1)s,%(change2)s,%(ribsPattern)s)     %(kinetics)s ''' % locals()
    out_file.write(rule)
    out_file.write('\n')    
    return    
#------------------------------------------------------------
def rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics):
    eff += '()'
    rule=''' %(rbsPattern)s(%(rsPattern1)s,%(rsPattern2)s,%(ribsPattern)s) -> %(rbsPattern)s(%(change1)s,%(change2)s,%(changeRib)s) + %(eff)s + %(rib_free)s    %(kinetics)s ''' % locals()
    out_file.write(rule)
    out_file.write('\n')    
    return    
#------------------------------------------------------------
def rule_theta_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,rib_free,kinetics):
    eff += '()'
    rule='''    %(eff)s + %(rbsPattern)s(%(rsPattern1)s,%(rsPattern2)s,%(ribsPattern)s) -> %(rbsPattern)s(%(change1)s,%(change2)s,%(changeRib)s) + %(rib_free)s     %(kinetics)s ''' % locals()
    out_file.write(rule)
    out_file.write('\n')    
    return    
#------------------------------------------------------------
def rule_deg_fast_plus_ribosome(risi,rbsPattern,ribsPattern,stPatternDeg,sigOut,ssPattern,osPatternList,kinetics):
    out_file.write('\n')
    rule='''    %(rbsPattern)s(''' %locals()
    out_file.write(rule)
    if len(stPatternDeg):
        for i in range(0,len(stPatternDeg)):
            out_file.write(stPatternDeg[i])
            out_file.write(',')
    out_file.write(ssPattern)
    out_file.write(',')
    if len(osPatternList):
        for i in range(0,len(osPatternList)):
            out_file.write(osPatternList[i])
            out_file.write(',')
    rule='''%(ribsPattern)s) -> Trash() + rib_free() + %(risi)s()''' %locals()
    out_file.write(rule)
    if len(sigOut) > 0:
        out_file.write(' + ')
    for i in range(0,len(sigOut)):
        out_file.write(sigOut[i])
        out_file.write('()')
        if i < len(sigOut)-1:
            out_file.write(' + ')
    out_file.write('    ')       
    out_file.write(kinetics)
    return    
#------------------------------------------------------------
def rule_deg(rbsPattern,stPatternDeg,ribsPattern,sigOut,kinetics):
    out_file.write('\n')
    out_file.write('    ')
    out_file.write(rbsPattern)
    out_file.write('(')
    for i in range(0,len(stPatternDeg)):
        out_file.write(stPatternDeg[i])
    out_file.write(ribsPattern)
    out_file.write(')')
    out_file.write(' -> ')
    out_file.write('Trash()')
    if len(sigOut) > 0:
        out_file.write(' + ')
    for i in range(0,len(sigOut)):
        out_file.write(sigOut[i])
        out_file.write('()')
        if i < len(sigOut)-1:
            out_file.write(' + ')
    out_file.write('    ')       
    out_file.write(kinetics)
    return    
#------------------------------------------------------------
def rule_deg_rb(rbsPattern,ribsPattern,siteOnPattern,sigOut,kinetics):
    out_file.write('\n')
    out_file.write('    ')
    out_file.write(rbsPattern)
    out_file.write('(')
    for i in range(0,len(stPatternDeg)):
        out_file.write(stPatternDeg[i])
    for i in range(0,len(siteOnPattern)):
        out_file.write(siteOnPattern[i])        
    out_file.write(ribsPattern)
    out_file.write(')')
    out_file.write(' -> ')
    out_file.write('Trash()')
    if len(sigOut) > 0:
        out_file.write(' + ')
    for i in range(0,len(sigOut)):
        out_file.write(sigOut[i])
        out_file.write('()')
        if i < len(sigOut)-1:
            out_file.write(' + ')
    out_file.write('    ')            
    out_file.write(kinetics)
    return    
#------------------------------------------------------------
def rule_fast_deg_sirna(risi,rbsPattern,ribsPattern,ssPattern,osPatternList,stPatternDeg,sigOut,kinetics):
    out_file.write('\n')
    rule='''    %(rbsPattern)s(%(ssPattern)s,''' %locals()
    out_file.write(rule)
    if len(osPatternList):
        for i in range(0,len(osPatternList)):
            out_file.write(osPatternList[i])
            out_file.write(',')
    if len(stPatternDeg):
        for i in range(0,len(stPatternDeg)):
            out_file.write(stPatternDeg[i])
    rule='''%(ribsPattern)s) -> Trash() + %(risi)s()''' %locals()
    out_file.write(rule)
    if len(sigOut) > 0:
        out_file.write(' + ')
    for i in range(0,len(sigOut)):
        out_file.write(sigOut[i])
        out_file.write('()')
        if i < len(sigOut)-1:
            out_file.write(' + ')
    out_file.write('    ')            
    out_file.write(kinetics)
    return    
#------------------------------------------------------------
#def rule_leakage(rbsPattern,rsPattern,ribsPattern,rib_cl_lk,kinetics):
#    out_file.write('\n')
#    rule='''    %(rbsPattern)s(%(rsPattern)s,%(ribsPattern)s) -> %(rbsPattern)s(%(rsPattern)s,%(ribsPattern)s) + %(rib_cl_lk)s  %(kinetics)s ''' % locals()
#    out_file.write(rule)
#    return
#------------------------------------------------------------
def rule_leakage(rbsPattern,stPatternDeg,siteOnPattern,ribsPattern,kinetics):
    out_file.write('\n')
    out_file.write('    ')
    out_file.write(rbsPattern)
    out_file.write('(')
    for i in range(0,len(stPatternDeg)):
        out_file.write(stPatternDeg[i])
    for i in range(0,len(siteOnPattern)):
        out_file.write(siteOnPattern[i])
    out_file.write(ribsPattern)
    out_file.write(')')
    out_file.write(' -> ')
    out_file.write(rbsPattern)
    out_file.write('(')
    for i in range(0,len(stPatternDeg)):
        out_file.write(stPatternDeg[i])
    for i in range(0,len(siteOnPattern)):
        out_file.write(siteOnPattern[i])
    out_file.write(ribsPattern)
    out_file.write(') + protein()')
    out_file.write('    ')       
    out_file.write(kinetics)
    return    
#------------------------------------------------------------

#### START OF THE MAIN PROGRAM

# To specify by hands:
new_reactions='n' # y/n, with n the old model should be reproduced.

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('EU_coding.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1

# print inp_values
inp_file.close()

# Assigning input values to variables
# Coding region name
coding_name=inp_values[0]
print 'coding_name', coding_name
mrna_name='m_mrna_'+coding_name

lib_name='m_mrna_'+coding_name.lower()+"_REACTIONS_LIB.mdl"
lib_file=open(lib_name,'w')
#lib_file.write('(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")\n')

# Riboswitch number
rib_num=int(inp_values[1])
print 'riboswitches number:', rib_num

# Riboswitch kinds
# ton: tandem-homo (one chemical, two siteamers), no coperativity
# ten: tandem-hetero (two chemicals, two aptamers), no coperativity
# toc: tandem, homo-cooperativity
# tec: tandem, hetero-cooperativity
# s: single
rib_kind=inp_values[2].split(',')
for i in range(0,rib_num):
    id=i+1
#    print id, rib_kind[i]
    if rib_kind[i] != 's' and rib_kind[i] != 'ton' and rib_kind[i] != 'ten' and rib_kind[i] != 'toc' and rib_kind[i] != 'tec':
        print "Error in rib_kind. Riboswitch #",id,"is: ",rib_kind[i]
        sys.exit()
        
# Chemicals number per riboswitch: 1 for single or tandem-homo riboswitches, 2 for hetero-tandem ones
che_num=[]
for i in range(0,rib_num):
    if rib_kind[i] == 's' or rib_kind[i] == 'ton' or rib_kind[i] == 'toc':
        che_num.insert(i,1)
    else:
        che_num.insert(i,2)        
#print "che_num:",che_num


# Effectors per riboswitch
eff_per_rib=inp_values[3].split(',')

for i in range(0,rib_num):
    id = i+1
    if re.search('\(',eff_per_rib[i]):
        if re.search('o',rib_kind[i]) or re.search('s',rib_kind[i]):
            print "Error in the effectors. Riboswitch #",id,"has two effectors whereas it should have only one."
            sys.exit()
        eff_per_rib[i]=re.sub('\(','',eff_per_rib[i])
        eff_per_rib[i]=re.sub('\)','',eff_per_rib[i])
        eff_per_rib[i]=eff_per_rib[i].split(';')
    else:  
        eff_per_rib[i]=re.sub("$",";",eff_per_rib[i])
        eff_per_rib[i]=eff_per_rib[i].split(';')
        eff_per_rib[i].remove('')
        # tandem-homo: the same effector acts on both aptamers
        if re.search('o',rib_kind[i]):   # still necessary???
            double=eff_per_rib[i][0]
            eff_per_rib[i].append(double)
#    print id, eff_per_rib[i]
    # CHECK
    for j in range(0,len(eff_per_rib[i])):
        if not re.search('I',eff_per_rib[i][j]) and not re.search('C',eff_per_rib[i][j]):
            print "Error in the effectors. Riboswitch #",id,"has a wrong effector: ",eff_per_rib[i][j]
            sys.exit()
        if re.search('e',rib_kind[i]) and len(eff_per_rib[i]) != 2:
            print "Error in the effectors. Riboswitch #",id,"should have two effectors: ",eff_per_rib[i][j]
            sys.exit()
            

#sirna number
sirna_num=int(inp_values[4])
print 'sirnas number:', sirna_num

# k_fd, mRNA fast degradation rate
k_fd=float(inp_values[5])

# sirna kind: they are all locks (only repression is possible)
sirna_kind=[]
for i in range(0,sirna_num):
    sirna_kind.append('l')

# sirna name
sirna_name=[]
for i in range(0,sirna_num):
    id=i+1
    name='s'+str(id)
    sirna_name.append(name)
    
# sites per sirna
st_per_sirna=inp_values[6].split(',')
#for i in range(0,sirna_num):
#    print i, st_per_sirna[i]

# polymerase leakage
pol_lk=inp_values[7]
#print "pol leakage:", pol_lk
if pol_lk != 'y' and pol_lk != 'n':
    "Error: pol_lk must be 'y' or 'n'. You set: pol_lk =",pol_lk
#print "LK",pol_lk

# gene length
gene_length=float(inp_values[8])
v_pol=23.3 # RNA polymerase elongation rate 
v_rib=24.0 # ribosome elongation rate
k_el=v_pol/float(gene_length)     
k_el_r=v_rib/float(gene_length)   

# k_d
#k_d=float(inp_values[9])
# k_d should arrive from the terminator
k_d=1.0

# k_d_s RiSC-siRNA degradation rate, from the siRNA pool
#k_d_s=1.0

# k1r
k1r=float(inp_values[9])

# k_1r
k_1r=float(inp_values[10])

# k2r
k2r=float(inp_values[11])

# theta riboswitch
theta_rib=inp_values[12].split(',')
for i in range(0,rib_num):
    id=i+1
    if re.search('\(',theta_rib[i]):
        theta_rib[i]=re.sub('\(','',theta_rib[i])
        theta_rib[i]=re.sub('\)','',theta_rib[i])
        theta_rib[i]=theta_rib[i].split(';')
    else:  
        theta_rib[i]=re.sub("$",";",theta_rib[i])
        theta_rib[i]=theta_rib[i].split(';')
        theta_rib[i].remove('')
#    print id, theta_rib[i]                     
    # CHECK
    if (rib_kind[i] == 's' or rib_kind[i] == 'ton') and len(theta_rib[i]) != 1:
        print "Error. Riboswitch #",id,"has",len(theta_rib[i]),"values for theta whereas 1 is required."
        sys.exit()
    if (rib_kind[i] == 'ten' or rib_kind[i] == 'toc') and len(theta_rib[i]) != 2:
        print "Error. Riboswitch #",id,"has",len(theta_rib[i]),"values for theta whereas 2 are required."
        sys.exit()        
    if rib_kind[i] == 'tec' and len(theta_rib[i]) != 3:
        print "Error. Riboswitch #",id,"has",len(theta_rib[i]),"values for theta whereas 3 are required."
        sys.exit()                
    # WARNINGS
    if rib_kind[i] == 'toc' and theta_rib[i][0] > theta_rib[i][1]:
        print "Warning! In riboswitch #",id,"theta1 > theta1c. This is not a cooperative behaviour."
    if rib_kind[i] == 'tec' and theta_rib[i][1] > theta_rib[i][2]:
        print "Warning! In riboswitch #",id,"theta2 > theta2c. This is not a cooperative behaviour." 
        
# csi riboswitch
csi_rib=inp_values[13].split(',')
for i in range(0,rib_num):
    id=i+1
    if re.search('\(',csi_rib[i]):
        csi_rib[i]=re.sub('\(','',csi_rib[i])
        csi_rib[i]=re.sub('\)','',csi_rib[i])
        csi_rib[i]=csi_rib[i].split(';')
    else:  
        csi_rib[i]=re.sub("$",";",csi_rib[i])
        csi_rib[i]=csi_rib[i].split(';')
        csi_rib[i].remove('')
#    print id, csi_rib[i]
    # CHECK
    if (rib_kind[i] == 's' or rib_kind[i] == 'ton') and len(csi_rib[i]) != 1:
        print "Error. Riboswitch #",id,"has",len(csi_rib[i]),"values for csi whereas 1 is required."
        sys.exit()
    if (rib_kind[i] == 'ten' or rib_kind[i] == 'toc') and len(csi_rib[i]) != 2:
        print "Error. Riboswitch #",id,"has",len(csi_rib[i]),"values for csi whereas 2 are required."
        sys.exit()        
    if rib_kind[i] == 'tec' and len(csi_rib[i]) != 3:
        print "Error. Riboswitch #",id,"has",len(csi_rib[i]),"values for csi whereas 3 are required."
        sys.exit()                
    # WARNINGS
    if rib_kind[i] == 'toc' and csi_rib[i][0] < csi_rib[i][1]:
        print "Warning! In riboswitch #",id,"csi1 < csi1c. This is not a cooperative behaviour."
    if rib_kind[i] == 'tec' and csi_rib[i][1] > csi_rib[i][2]:
        print "Warning! In riboswitch #",id,"csi2 < csi2c. This is not a cooperative behaviour."     

# theta sirna
theta_sirna=inp_values[14].split(',')
for i in range(0,sirna_num):
    id=i+1
#    print id, theta_sirna[i]

# csi sirna
csi_sirna=inp_values[15].split(',')
for i in range(0,sirna_num):
    id=i+1
#    print id, csi_sirna[i]
    
# k2r leakage 
k2r_lk=float(inp_values[16])    
#print k2r_lk

# k1y, splicesome binding rate
k1y=float(inp_values[17])

# k_1y, splicesome unbinding rate
k_1y=float(inp_values[18])

# k2y, unspliced, nuclear mRNA production rate 
k2y=float(inp_values[19])

# km, mRNA maturation (and transport) rate 
km=float(inp_values[20])

# zeta_r, ribosome-ribSTOP unbing rate
zeta_r=float(inp_values[21])

# k_tr, for protein nuclear import
k_tr=float(inp_values[22])

# k_dp, protein deay rate
k_dp=float(inp_values[23])

# local path
path_local=inp_values[24]

# BioNetGen path
path_BNG=inp_values[25]

# product name
product_name=inp_values[26]

# promoter name
promoter_name=inp_values[27].lower()
################################################
# Coding region generation: MDL file directly
#  PoPSin => [PolA]
#  [PolA] -> Pol_el + u_mRNA (k_el)
#  Y_free + u_mRNA <-> [Yu_mRNA] (k1y,k_1y)
# [Yu_mRNA] -> Y_free + n_mRNA (k2y)
# n_mRNA -> m_mRNA (km) 
# u_mRNA -> (k_d)
# n_mRNA -> (k_d)
# [Yu_mRNA] -> Y_free (k_d)

# Opening the output file
fname=coding_name+'.mdl'
fname=fname.lower()
out_file=open(fname,'w')

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-terminal
  :class "term-para-in"
  :super-classes ("terminal")
  :documentation "Input terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-input")))

(define-terminal
  :class "term-para-out"
  :super-classes ("terminal")
  :documentation "Output terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-output")))

(define-module
  :class "%(coding_name)s"
  :super-classes ("module")
  :icon "coding.png"
  :parameters(
  ("pola.c0"
   :value "0")
  ("u_mRNA.c0"
   :value "0")
  ("Yu_mRNA.c0"
   :value "0")
  ("n_mRNA.c0"
   :value "0")
  ("k_el.k1"
   :value "%(k_el)f")
  ("k_el.r"
   :value "parent.v*k1*a.c")
  ("k1y.k1"
   :value "%(k1y)f")
  ("k1y.r"
   :value "parent.v*k1*a.c*b.c")   
  ("k_1y.k1"
   :value "%(k_1y)f")
  ("k_1y.r"
   :value "parent.v*k1*a.c")
  ("k2y.k1"
   :value "%(k2y)f")
  ("k2y.r"
   :value "parent.v*k1*a.c")
  ("km.k1"
   :value "%(km)f")
  ("km.r"
   :value "parent.v*k1*a.c")
  )
  :terminals
  (("in_pol"
    :is-eq-to "pops_in.in"
    :geometry-side "LEFT"
    :geometry-position "0.1")
   ("out_pol"
    :is-eq-to "pops_out.out"
    :geometry-side "RIGHT"
    :geometry-position "0.1")
   ("exc_Y"
    :is-eq-to "Yps_b.in"
    :geometry-side "LEFT"
    :geometry-position "0.5")
   ("out_m_mRNA_%(coding_name)s"
    :is-eq-to "RNAps_out.out"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
   ("in_k_d"
    :is-a "term-para-in"
    :geometry-side "RIGHT"
    :geometry-position "0.5")
   ("out_k_d_%(coding_name)s"
    :is-a "term-para-out"
    :geometry-side "BOTTOM"
    :geometry-position "0.9")
   )
  :modules(
   ("pops_in"
     :is-a "adapter-flux")
   ("Yps_b"
    :is-a "adapter-flux")
   ("pops_out"
    :is-a "adapter-flux")
   ("RNAps_out"
    :is-a "adapter-flux")
   ("pola"
     :is-a "storage-intra")
   ("u_mRNA"
     :is-a "storage-intra")
   ("Yu_mRNA"
     :is-a "storage-intra")
   ("n_mRNA"
     :is-a "storage-intra")
   ("k_el"
     :is-a "trans3a-fi1_r")
   ("k1y"
     :is-a "trans3a-fi2ab_r")
   ("k_1y"
     :is-a "trans3a-fi1_r")
   ("k2y"
     :is-a "trans3a-fi1_r")
   ("km"
     :is-a "trans2a-fi1_r")
   ("kd_u"
     :is-a "trans1a-fi1_r"
     :variables(       
     ("k1"
      :is-eq-to "parent.kd")
     ("r"
      :value "parent.v*k1*a.c")))    
   ("kd_n"
     :is-a "trans1a-fi1_r"
     :variables(       
     ("k1"
      :is-eq-to "parent.kd")
     ("r"
      :value "parent.v*k1*a.c")))    
   ("kd_yu"
     :is-a "trans2a-fi1_r"
     :variables(       
     ("k1"
      :is-eq-to "parent.kd")
     ("r"
      :value "parent.v*k1*a.c")))         
  )
  :links(
  ("link_1"
    :terminals ("pola.cf" "k_el.a" "pops_in.out"))
  ("link_2"
    :terminals ("u_mRNA.cf" "k_el.c" "k1y.b" "k_1y.b" "kd_u.a"))
  ("link_3"
    :terminals ("n_mRNA.cf" "k2y.b" "km.a" "kd_n.a"))
  ("link_4"
    :terminals ("Yu_mRNA.cf" "k1y.c" "k_1y.a" "k2y.a" "kd_yu.a"))
  ("link_5"
    :terminals ("RNAps_out.in" "km.b"))
  ("link_6"
    :terminals ("pops_out.in" "k_el.b"))
  ("link_7"
    :terminals ("Yps_b.out" "k1y.a" "k_1y.c" "k2y.c" "kd_yu.b"))
  )
  :variables(
  ("kd"
    :is-eq-to "in_k_d.k"))  
  :equations(
  ("set_k_out"
   :relation "out_k_d_%(coding_name)s.k == kd")
  )) ''' %locals()

out_file.write(lines)
out_file.close()

################################################
# mature mMRNA pool generation
#
# BioNetGen file containing reactions
#
# Notice that:
# pops_in_lk => b()
# rib_free + b() <-> b(taken) (k1r,k_1r)
# b(taken) <-> b(free) + [ribSTART] (k2r)
# [ribSTART] -> [ribSTOP] (k_el_r)
# [ribSTOP] -> rib_free + protein (z_r)
# 

# Opening the output file
fname=mrna_name+'.bngl'
out_file=open(fname,'w')

#######################
# Writing initial concentrations and parameters parameters
#######################

para_dict={}  # to be used in the MDL file generation

out_file.write('begin parameters')


params='''
    b_conc_init         0
    ribSTART_conc_init  0
    ribSTOP_conc_init   0
    k_el_r              %(k_el_r)f
    k_d                 %(k_d)f
    k1r                 %(k1r)f
    k_1r                %(k_1r)f
    k2r                 %(k2r)f
    zeta_r              %(zeta_r)f
    k_fd                %(k_fd)f
    k_dp                %(k_dp)f    
''' % locals()
out_file.write(params)

if k_tr != 0:
    lines='''    k_tr                %(k_tr)f''' %locals()
    out_file.write(lines)
    out_file.write('\n')

if pol_lk == 'y':
    out_file.write('    pops_in_lk          0')
    out_file.write('\n')

### FAKE    k_s                 1.0

para_dict['k_el_r']=k_el_r
para_dict['k_d']=k_d
#para_dict['k_d_s']=k_d_s
para_dict['k1r']=k1r
para_dict['k_1r']=k_1r
para_dict['k2r']=k2r
para_dict['zeta_r']=zeta_r
para_dict['k_fd']=k_fd
para_dict['k_dp']=k_dp

if k_tr != 0:
    para_dict['k_tr']=k_tr
##############FAKE
#para_dict['k_s']=k_s 

if rib_num > 0 or sirna_num > 0:
    rib_lk='''    k2r_lk                %(k2r_lk)f''' % locals()
    out_file.write(rib_lk)
    para_dict['k2r_lk']=k2r_lk

for i in range(0,rib_num):
    id = i+1
    if rib_kind[i] == 's' or rib_kind[i] == 'ton':
        th_val=float(theta_rib[i][0])
        th_str="theta_r"+str(id)
        para='''
    %(th_str)s              %(th_val)f''' %locals()
        out_file.write(para)
        para_dict[th_str]=th_val
            
        cs_val=float(csi_rib[i][0])
        cs_str="csi_r"+str(id) 
        para='''
    %(cs_str)s              %(cs_val)f''' %locals()
        out_file.write(para)
        para_dict[cs_str]=cs_val
    
    if rib_kind[i] == 'toc':
        th_val=float(theta_rib[i][0])
        th_str="theta_r"+str(id)
        para='''
    %(th_str)s              %(th_val)f''' %locals()
        out_file.write(para)
        para_dict[th_str]=th_val

        cs_val=float(csi_rib[i][0])
        cs_str="csi_r"+str(id)
        para='''
    %(cs_str)s              %(cs_val)f''' %locals()
        out_file.write(para)
        para_dict[cs_str]=cs_val
    
        th_val=float(theta_rib[i][1])
        th_str="theta_r"+str(id)+"c"
        para='''
    %(th_str)s              %(th_val)f''' %locals()
        out_file.write(para)
        para_dict[th_str]=th_val        

        cs_val=float(csi_rib[i][1])
        cs_str="csi_r"+str(id)+"c" 
        para='''
    %(cs_str)s              %(cs_val)f''' %locals()
        out_file.write(para)
        para_dict[cs_str]=cs_val
    
    if rib_kind[i] == 'ten':
        for j in range(0,2):
            eff = j+1
            th_val=float(theta_rib[i][j])
            th_str="theta_r"+str(id)+"_"+str(eff)
            para='''
    %(th_str)s              %(th_val)f''' %locals()
            out_file.write(para)
            para_dict[th_str]=th_val
    
            cs_val=float(csi_rib[i][j])
            cs_str="csi_r"+str(id)+"_"+str(eff)
            para='''
    %(cs_str)s              %(cs_val)f''' %locals()
            out_file.write(para)
            para_dict[cs_str]=cs_val

    if rib_kind[i] == 'tec':
        for j in range(0,3):
            eff = j+1
            if j < 2:
                th_val=float(theta_rib[i][j])
                th_str="theta_r"+str(id)+"_"+str(eff)
                para='''
    %(th_str)s              %(th_val)f''' %locals()
                out_file.write(para)
                para_dict[th_str]=th_val
                
                cs_val=float(csi_rib[i][j])
                cs_str="csi_r"+str(id)+"_"+str(eff)
                para='''
    %(cs_str)s              %(cs_val)f''' %locals()
                out_file.write(para)
                para_dict[cs_str]=cs_val                
            else:
                eff = 2
                th_val=float(theta_rib[i][j])
                th_str="theta_r"+str(id)+"_"+str(eff)+"c"
                para='''
    %(th_str)s              %(th_val)f''' %locals()
                out_file.write(para)
                para_dict[th_str]=th_val
        
                cs_val=float(csi_rib[i][j])
                cs_str="csi_r"+str(id)+"_"+str(eff)+"c"
                para='''
    %(cs_str)s              %(cs_val)f''' %locals()
                out_file.write(para)
                para_dict[cs_str]=cs_val

for i in range(0,sirna_num):
    id = i+1
    th_val=float(theta_sirna[i])
    th_str="theta_s"+str(id)
    para='''
    %(th_str)s              %(th_val)f''' %locals()
    out_file.write(para)
    para_dict[th_str]=th_val

    cs_val=float(csi_sirna[i])
    cs_str="csi_s"+str(id)
    para='''
    %(cs_str)s              %(cs_val)f''' %locals()
    out_file.write(para)
    para_dict[cs_str]=cs_val

out_file.write('\n')

out_file.write('end parameters')
out_file.write('\n')
out_file.write('\n')

#print "PARADICT:",para_dict

#######################################
# Molecule types (species) generation
#######################################

out_file.write('begin molecule types')

# ribSTART: complex, ribosome-mrna_START_codon
ribSTART='ribSTART()'
ribSTART_declaration='''
    %(ribSTART)s''' % locals()
out_file.write(ribSTART_declaration)

# ribSTOP: complex, ribosome-mrna_STOP_codon
ribSTOP='ribSTOP()'
ribSTOP_declaration='''
    %(ribSTOP)s''' % locals()
out_file.write(ribSTOP_declaration)

# PoPS_in_lk, flux
if pol_lk == 'y':
    pops_in_lk='pops_in_lk()'
    pops_in_lk_declaration='''
    %(pops_in_lk)s''' % locals()
    out_file.write(pops_in_lk_declaration)

if k_tr != 0:
    # protein_c, protein in the cytoplasm
    protein_c='protein_c()'
    protein_c_declaration='''
        %(protein_c)s''' % locals()
    out_file.write(protein_c_declaration) 

# protein (FaPSout): protein leaving the pool (FaPS, Factor Per Second)
protein='protein()'
protein_declaration='''
    %(protein)s''' % locals()
out_file.write(protein_declaration) 

# rib_free(RiPSb)   
rib_free='rib_free()'
rib_free_declaration='''
    %(rib_free)s''' % locals()
out_file.write(rib_free_declaration)
#out_file.write('()')

## RiSC_free(RiPSb)   
#risc_free='risc_free()'
##risc_free_declaration='''
#   %(risc_free)s''' % locals()
#out_file.write(risc_free_declaration)
# when a siRNA decay into this part, a free RiSC complex is released and goes back to its pool !!!No, this decay cannot take place here!!!

#----------------
# RBS (b). Sites can have two states: on (transcription is allowed) and off (transcription is blocked).

rbs_naming='''
    b(''' % locals()
out_file.write(rbs_naming)

# riboswitch sites
r_id=0    
for i in range(0,rib_num):
    r_id += 1
    for j in range(0,len(eff_per_rib[i])):  # tandem hetero-riboswitches 
        apt_id = j + 1
        s_declaration='''R%(r_id)i_%(apt_id)i~on~off,''' % locals()
        out_file.write(s_declaration)
    
# sirna sites
sirna_id=0
for i in range(0,sirna_num):
    sirna_id += 1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        s_declaration='''S%(sirna_id)i_%(st_id)i~on~off,''' % locals()
        out_file.write(s_declaration)

# Ribosome binding site
#rib_site='rib_st'
rib_site_declaration='''rib_site~free~taken''' % locals()
out_file.write(rib_site_declaration)         

out_file.write(')') 
out_file.write('\n') 

# Signals/Chemicals
#out_file.write('\n// Chemicals')
sg=[]
ct_sg=0
if rib_num > 0:
    for i in range(0,rib_num):
        for j in range(0,che_num[i]):
            sg.append(eff_per_rib[i][j])
            sig=sg[ct_sg]
            sig_declaration='''    %(sig)s() ''' % locals()
            ct_sg += 1
            out_file.write(sig_declaration)
            out_file.write('\n')

# small intefering RNAs
#out_file.write('\n// sirnas')
if sirna_num > 0:
    for i in range(0,sirna_num):
            sirna_n=sirna_name[i]
            sirna_declaration='''    %(sirna_n)s()''' % locals()
            out_file.write(sirna_declaration)
            out_file.write('\n')

#########FAKE
#kr='KR()'
#kr_declaration='''    %(kr)s
#''' % locals()
#out_file.write(kr_declaration)

out_file.write('    Trash()\n')
out_file.write('end molecule types')
out_file.write('\n') 
out_file.write('\n')

###########################
# Writing seed species
###########################
out_file.write('begin seed species')

# PoPS_in_lk, flux
if pol_lk == 'y':
    pops_in_lk='pops_in_lk()'
    pops_in_lk_declaration='''
    %(pops_in_lk)s      0''' % locals()
    out_file.write(pops_in_lk_declaration)

# rib_free(RiPSb)   
#rib_free_d='rib_free()'
rib_free_declaration='''
    %(rib_free)s        0''' % locals()
out_file.write(rib_free_declaration)
out_file.write('\n')

# Signals/Chemicals
#out_file.write('\n// Chemicals')
sg=[]
ct_sg=0
if rib_num > 0:
    for i in range(0,rib_num):
        for j in range(0,che_num[i]):
            sg.append(eff_per_rib[i][j])
            sig=sg[ct_sg]
            sig_declaration='''    %(sig)s()    0''' % locals()
            ct_sg += 1
            out_file.write(sig_declaration)
            out_file.write('\n')

# small interfering RNAs
#out_file.write('\n// sirnas')
if sirna_num > 0:
    for i in range(0,sirna_num):
            sirna_n=sirna_name[i]
            sirna_declaration='''    %(sirna_n)s()    0''' % locals()
            out_file.write(sirna_declaration)
            out_file.write('\n')             

# mRNA is present since it comes from the coding region part
# RBS (b). Sites can have two states: on (transcription is allowed) and off (transcription is blocked).

rbs_naming='''    b(''' % locals()
out_file.write(rbs_naming)

# riboswitch sites
r_id=0    
for i in range(0,rib_num):
    r_id += 1
    for j in range(0,len(eff_per_rib[i])):  # tandem hetero-riboswitches 
        apt_id = j + 1
        s_declaration='''R%(r_id)i_%(apt_id)i~on,''' % locals()
        out_file.write(s_declaration)
    
# sirna sites
sirna_id=0
for i in range(0,sirna_num):
    sirna_id += 1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        s_declaration='''S%(sirna_id)i_%(st_id)i~on,''' % locals()
        out_file.write(s_declaration)

# Ribosome binding site
#rib_site='rib_st'
rib_site_declaration='''rib_site~free''' % locals()
out_file.write(rib_site_declaration)         

out_file.write(')     0') 
out_file.write('\n') 


# FAKE
#kr='KR()'
#kr_declaration='''    %(kr)s         0
#''' % locals()
#out_file.write(kr_declaration)

out_file.write('end seed species')
out_file.write('\n') 
out_file.write('\n')

################################
# Writing reaction rules
################################
out_file.write('begin reaction rules')
out_file.write('\n')

ct_rl=1

# FAKE, for debugging
#kinetics="k_s"
#rule='''    %(kr)s -> %(kr)s + %(polb)s     %(kinetics)s ''' % locals()
#out_file.write(rule)
#out_file.write('\n')

# Ground state definition
ground_state='b_'

r_id=0    
for i in range(0,rib_num):
    r_id += 1
    for j in range(0,len(eff_per_rib[i])):  # tandem hetero-riboswitches 
        apt_id = j + 1
        if re.search('I',eff_per_rib[i][j]):
            state='off'
        else:
            state='on'    
        ground_state +='R'+str(r_id)+str(apt_id)+str(state)+'_'
    
# sirna sites
sirna_id=0
for i in range(0,sirna_num):
    sirna_id += 1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        state=""
        if re.search('k',sirna_kind[i]):
            state='off'
        else:
            state='on'
        ground_state +='S'+str(sirna_id)+str(st_id)+str(state)+'_'

# Ribosome binding site
ground_state += 'ribsitefree'        
#print "GROUND",ground_state

# Pol_lk (PoPSin_lk) ==> b
if pol_lk == 'y':
    kinetics="pops_in_lk"
    rule='''    %(pops_in_lk)s -> b(''' % locals()
    out_file.write(rule)

    r_id=0    
    for i in range(0,rib_num):
        r_id += 1
        for j in range(0,len(eff_per_rib[i])):  # tandem hetero-riboswitches 
            apt_id = j + 1
            if re.search('I',eff_per_rib[i][j]):
                state='off'
            else:
                state='on'    
            s_declaration='''R%(r_id)i_%(apt_id)i~%(state)s,''' % locals()
            out_file.write(s_declaration)
        
    # sirna sites
    sirna_id=0
    for i in range(0,sirna_num):
        sirna_id += 1
        for j in range(0,int(st_per_sirna[i])):
            st_id = j+1
            state=""
            if re.search('k',sirna_kind[i]):
                state='off'
            else:
                state='on'    
            s_declaration='''S%(sirna_id)i_%(st_id)i~%(state)s,''' % locals()
            out_file.write(s_declaration)

    # Ribosome binding site
    rib_site_declaration='''rib_site~free''' % locals()
    out_file.write(rib_site_declaration)         

    out_file.write(')')
    kinetics_decl='''    %(kinetics)s''' % locals()
    out_file.write(kinetics_decl)
    out_file.write('\n')

####

#---------
# Chemicals binding/unbinding riboswitches 
b_name='b'
rbsPattern=b_name

rib_id=0
for i in range(0,rib_num):
    rib_id =i+1
    # single riboswitches
    # Only one value for theta (and csi) is required.
    if rib_kind[i] == 's':
        eff=eff_per_rib[i][0]
        if re.search('I',eff):
            # theta-csi: binding and unbinding of I when ribosomes are not bound
            rsPattern="R"+str(rib_id)+"_1~off" 
            ribsPattern="rib_site~free"
            change="R"+str(rib_id)+"_1~on" 
            kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
            rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)
            if new_reactions == 'y':
                # csi: unbinding of I plus ribosome
                rsPattern="R"+str(rib_id)+"_1~on" 
                ribsPattern="rib_site~taken"
                change="R"+str(rib_id)+"_1~off"
                changeRib="rib_site~free"
                kinetics="csi_r"+str(rib_id)
                rule_csi_site(eff,rib_free,rbsPattern,rsPattern,ribsPattern,change,changeRib,kinetics)
        else:
            rsPattern="R"+str(rib_id)+"_1~on"
            ribsPattern="rib_site~free"
            change="R"+str(rib_id)+"_1~off"
            for state in ('free','taken'): # Co-repressors can bind when a ribosome is bound too. This is a new irrev reaction wrt the previous model
                ribsPattern="rib_site~"+state
                if state == 'free':
                    # theta-csi: binding and unbinding of C when ribosomes are not bound
                    kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
                    rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)    
                else:
                    if new_reactions == 'y':
                        # theta: binding of C and unbinding of ribosome 
                        changeRib="rib_site~free"
                        kinetics="theta_r"+str(rib_id)
                        rule_theta_site(eff,rbsPattern,rsPattern,ribsPattern,change,changeRib,rib_free,kinetics)

    # tandem-homo, no cooperativity: the chemicals bind symmetrically to the two aptamers.
    # Only one value for theta (and csi) is required.
    if rib_kind[i] == 'ton':
        for j in range(0,2):
            eff_id = j+1
            eff=eff_per_rib[i][j]
#           eff=eff_per_rib[i][0]
        
            if re.search('I',eff):
                # theta-csi: binding and unbinding of I when ribosomes are not bound
                rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~off"
    #            rsPattern="R"+str(rib_id)+"~off" 
                ribsPattern="rib_site~free"
                change="R"+str(rib_id)+"_"+str(eff_id)+"~on" 
                kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
                rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)
    
                if new_reactions == 'y':
                    # csi: unbinding of I plus ribosome   
                    rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~on"
                    ribsPattern="rib_site~taken"
                    change="R"+str(rib_id)+"_"+str(eff_id)+"~off" 
                    changeRib="rib_site~free"
                    kinetics="csi_r"+str(rib_id)
                    rule_csi_site(eff,rib_free,rbsPattern,rsPattern,ribsPattern,change,changeRib,kinetics)
            else:
                rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~on"
                change="R"+str(rib_id)+"_"+str(eff_id)+"~off" 
    
                for state in ('free','taken'): # Co-repressors can bind when a ribosome is bound too. This is a new irrev reaction wrt the previous model
                    ribsPattern="rib_site~"+state
                    if state == 'free':
                        # theta-csi: binding and unbinding of C when ribosomes are not bound
                        kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
                        write_rule_number(out_file)
                        rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)    
                    else:
                        if new_reactions == 'y':
                            # theta: binding of C and unbinding of ribosome 
                            changeRib="rib_site~free"
                            kinetics="theta_r"+str(rib_id)
                            write_rule_number(out_file)
                            rule_theta_site(eff,rbsPattern,rsPattern,ribsPattern,change,changeRib,rib_free,kinetics)
    
    # tandem-homo, cooperativity: when one of the two sites is bound, the affinity of the other site towards the chemical is higher. Two values for theta (and csi) are required.
    if rib_kind[i] == 'toc':
        eff=eff_per_rib[i][0]
        if re.search('I',eff):
            # theta-csi: both sites are off 
            rsPattern1="R"+str(rib_id)+"_1~off"
            rsPattern2="R"+str(rib_id)+"_2~off"
            ribsPattern="rib_site~free"
            
            change1="R"+str(rib_id)+"_1~on"
            change2="R"+str(rib_id)+"_2~off"
            kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)

            change1="R"+str(rib_id)+"_1~off"
            change2="R"+str(rib_id)+"_2~on"
            kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
                
            # theta-csi: one site is on 
            rsPattern1="R"+str(rib_id)+"_1~off"
            rsPattern2="R"+str(rib_id)+"_2~on"
            ribsPattern="rib_site~free"
            change1="R"+str(rib_id)+"_1~on"
            change2="R"+str(rib_id)+"_2~on"
            kinetics="theta_r"+str(rib_id)+"c,csi_r"+str(rib_id)+"c"
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)    

            rsPattern1="R"+str(rib_id)+"_1~on"
            rsPattern2="R"+str(rib_id)+"_2~off"
            ribsPattern="rib_site~free"
            change1="R"+str(rib_id)+"_1~on"
            change2="R"+str(rib_id)+"_2~on"
            kinetics="theta_r"+str(rib_id)+"c,csi_r"+str(rib_id)+"c"            
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
            if new_reactions == 'y':
                # csi: both sites are on, unbinding of I and ribosome   
                rsPattern1="R"+str(rib_id)+"_1~on"
                rsPattern2="R"+str(rib_id)+"_2~on"
                ribsPattern="rib_site~taken"
                change1="R"+str(rib_id)+"_1~off"
                change2="R"+str(rib_id)+"_2~on"
                changeRib="rib_site~free"
                kinetics="csi_r"+str(rib_id)+"c"
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics)

                change1="R"+str(rib_id)+"_1~on"
                change2="R"+str(rib_id)+"_2~off"
                changeRib="rib_site~free"
                kinetics="csi_r"+str(rib_id)+"c"
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics)                
        else:
            rsPattern1="R"+str(rib_id)+"_1~on"
            rsPattern2="R"+str(rib_id)+"_2~on"
            change1="R"+str(rib_id)+"_1~off"
            change2="R"+str(rib_id)+"_2~on"
            for state in ('free','taken'): 
                ribsPattern="rib_site~"+state
                if state == 'free':
                    # theta-csi: both sites are on, binding/unbinding of C, ribosome are absent
                    kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
                    rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
                else:
                    if new_reactions == 'y':
                        # theta: both sites are on, binding of C and unbinding of ribosome 
                        changeRib="rib_site~free"
                        kinetics="theta_r"+str(rib_id)
                        rule_theta_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,rib_free,kinetics)

            rsPattern1="R"+str(rib_id)+"_1~on"
            rsPattern2="R"+str(rib_id)+"_2~on"
            change1="R"+str(rib_id)+"_1~on"
            change2="R"+str(rib_id)+"_2~off"
            for state in ('free','taken'): 
                ribsPattern="rib_site~"+state
                if state == 'free':
                    # theta-csi: both sites are on, binding/unbinding of C, ribosome are absent
                    kinetics="theta_r"+str(rib_id)+",csi_r"+str(rib_id)
                    rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
                else:
                    if new_reactions == 'y':
                        # theta: both sites are on, binding of C and unbinding of ribosome 
                        changeRib="rib_site~free"
                        kinetics="theta_r"+str(rib_id)
                        rule_theta_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,rib_free,kinetics)

            # theta-csi: one site is off, binding/unbing of C        
            rsPattern1="R"+str(rib_id)+"_1~on"
            rsPattern2="R"+str(rib_id)+"_2~off"
            change1="R"+str(rib_id)+"_1~off"
            change2="R"+str(rib_id)+"_2~off"
            ribsPattern="rib_site~free"
            kinetics="theta_r"+str(rib_id)+"c,csi_r"+str(rib_id)
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
            
            rsPattern1="R"+str(rib_id)+"_1~off"
            rsPattern2="R"+str(rib_id)+"_2~on"
            change1="R"+str(rib_id)+"_1~off"
            change2="R"+str(rib_id)+"_2~off"
            ribsPattern="rib_site~free"
            kinetics="theta_r"+str(rib_id)+"c,csi_r"+str(rib_id)
            rule_theta_csi_tandem(eff,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,kinetics)
            
    # tandem-hetero, no cooperativity: the aptamers have different affinities towards their chemicals. Hence, two values for theta (and csi) are required.
    if rib_kind[i] == 'ten':
        # when the ribosome site is free, we have only the independent binding/unbinding of the two chemicals
        ribsPattern="rib_site~free"
        # binding/unbinding
        for j in range(0,2):
            eff_id = j+1
            eff=eff_per_rib[i][j]
            if re.search('I',eff):
                rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~off"
                change="R"+str(rib_id)+"_"+str(eff_id)+"~on"
                kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
                rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)
            if re.search('C',eff):
                rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~on"
                change="R"+str(rib_id)+"_"+str(eff_id)+"~off"
                kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
                rule_theta_csi_site(eff,rbsPattern,rsPattern,ribsPattern,change,kinetics)
        if new_reactions== 'y':                
            # when the ribosome site is taken, some reactions make the ribosomes leave the mRNA        
            ribsPattern="rib_site~taken"
            changeRib="rib_site~free"
    
            eff1=eff_per_rib[i][0]
            eff2=eff_per_rib[i][1]
            rsPattern1="R"+str(rib_id)+"_1~on"    
            change1=rsPattern1="R"+str(rib_id)+"_1~off"    
            rsPattern2="R"+str(rib_id)+"_2~on"
            change2="R"+str(rib_id)+"_2~off"
            if re.search('I',eff1) and re.search('I',eff2):
                # when either effector unbinds the riboswitch, the ribosome leaves
                kinetics1="csi_r"+str(rib_id)+"_1"            
                kinetics2="csi_r"+str(rib_id)+"_2"
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('I',eff1) and re.search('C',eff2):    
                # when either I unbinds or C binds the riboswitch, the ribosome leaves
                kinetics1="csi_r"+str(rib_id)+"_1"
                kinetics2="theta_r"+str(rib_id)+"_2"
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('C',eff1) and re.search('I',eff2):    
                # when either I unbinds or C binds the riboswitch, the ribosome leaves
                kinetics1="theta_r"+str(rib_id)+"_1"
                kinetics2="csi_r"+str(rib_id)+"_2"
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('C',eff1) and re.search('C',eff2):
                # when either effector binds the riboswitch, the ribosome leaves
                kinetics1="theta_r"+str(rib_id)+"_1"            
                kinetics2="theta_r"+str(rib_id)+"_2"
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)                
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
    if rib_kind[i] == 'tec':
        # the first aptamers has an higher affinity than the second one. When it is bound, the affinity of the second aptamers increases as an effect of cooperativity.
        # three values for theta (and csi) are required
        # probably, we should ask to have either two Is or two Cs
        
        # ribosome site is free
        ribsPattern="rib_site~free"
        # binding/unbinding to the first aptamer (this is independent of the second aptamer's state)
        eff_id = 1
        eff1=eff_per_rib[i][0]            
        if re.search('I',eff1):
            rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            change="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_site(eff1,rbsPattern,rsPattern,ribsPattern,change,kinetics)
        if re.search('C',eff1):
            rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            change="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_site(eff1,rbsPattern,rsPattern,ribsPattern,change,kinetics)

        # binding/unbinding to the second aptamer when the first is unbound: no cooperativity
        eff_id = 2
        eff2=eff_per_rib[i][1]            
        if re.search('I',eff2):
            if re.search('I',eff1):    
                rsPattern1="R"+str(rib_id)+"_1~off"                  # unbound state for I
            else:
                rsPattern1="R"+str(rib_id)+"_1~on"                   # unbound state for C                
            rsPattern2="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            unchange=rsPattern1
            change="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_tandem(eff2,rbsPattern,rsPattern1,rsPattern2,ribsPattern,unchange,change,kinetics)
        if re.search('C',eff2):
            if re.search('I',eff1):            
                rsPattern1="R"+str(rib_id)+"_1~off"                  # unbound state for I
            else:
                rsPattern1="R"+str(rib_id)+"_1~on"                   # unbound state for C                               
            rsPattern2="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            change="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            unchange=rsPattern1
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+",csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_tandem(eff2,rbsPattern,rsPattern1,rsPattern2,ribsPattern,unchange,change,kinetics)
            
        # binding/unbinding to the second aptamer when the first is bound: cooperativity
        eff_id = 2
        eff2=eff_per_rib[i][1]            
        if re.search('I',eff2):
            if re.search('I',eff1):    
                rsPattern1="R"+str(rib_id)+"_1~on"                  # bound state for I
            else:
                rsPattern1="R"+str(rib_id)+"_1~off"                 # bound state for C
            unchange=rsPattern1    
            rsPattern2="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            change="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+"c,csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_tandem(eff2,rbsPattern,rsPattern1,rsPattern2,ribsPattern,unchange,change,kinetics)
        if re.search('C',eff2):
            if re.search('I',eff1):    
                rsPattern1="R"+str(rib_id)+"_1~on"                  # bound state for I
            else:
                rsPattern1="R"+str(rib_id)+"_1~off"                 # bound state for C            
            rsPattern2="R"+str(rib_id)+"_"+str(eff_id)+"~on"
            change="R"+str(rib_id)+"_"+str(eff_id)+"~off"
            unchange=rsPattern1
            kinetics="theta_r"+str(rib_id)+"_"+str(eff_id)+"c,csi_r"+str(rib_id)+"_"+str(eff_id)
            rule_theta_csi_tandem(eff2,rbsPattern,rsPattern1,rsPattern2,ribsPattern,unchange,change,kinetics)

        if new_reactions == 'y':
            # ribosome site is taken, some reactions make the ribosome leave
            ribsPattern="rib_site~taken"
            changeRib="rib_site~free"
    
            eff1=eff_per_rib[i][0]
            eff2=eff_per_rib[i][1]
            rsPattern1="R"+str(rib_id)+"_1~on"    
            change1="R"+str(rib_id)+"_1~off"
            rsPattern2="R"+str(rib_id)+"_2~on"
            change2="R"+str(rib_id)+"_2~off"
            if re.search('I',eff1) and re.search('I',eff2):
                # when either effector unbinds the riboswitch, the ribosome leaves
                kinetics1="csi_r"+str(rib_id)+"_1"             
                kinetics2="csi_r"+str(rib_id)+"_2c"                               # cooperativity
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('I',eff1) and re.search('C',eff2):    
                # when either I unbinds or C binds the riboswitch, the ribosome leaves
                kinetics1="csi_r"+str(rib_id)+"_1"
                kinetics2="theta_r"+str(rib_id)+"_2c"                             # cooperativity
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('C',eff1) and re.search('I',eff2):    
                # when either I unbinds or C binds the riboswitch, the ribosome leaves
                kinetics1="theta_r"+str(rib_id)+"_1"
                kinetics2="csi_r"+str(rib_id)+"_2"
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_csi_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)
            if re.search('C',eff1) and re.search('C',eff2):
                # when either effector binds the riboswitch, the ribosome leaves
                kinetics1="theta_r"+str(rib_id)+"_1"            
                kinetics2="theta_r"+str(rib_id)+"_2"
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics1)
                rule_theta_tandem(eff,rib_free,rbsPattern,rsPattern1,rsPattern2,ribsPattern,change1,change2,changeRib,kinetics2)

# RiSC-sirna binding/unbinding their sites
# ribosomes can bind only when all the sirna sites are free
# A RiSC-sirna complex binds the mRNA no matter if the ribosomes are bound or not but all the other siRNA-RiSC sites must be on (free). Once a siRNA-RiSC complex
# is bound fast degradation is induced.

rbsPattern=b_name
#ribsPattern="rib_site~free"

for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1    
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~on"
        change="S"+str(sirna_id)+"_"+str(st_id)+"~off"
        osPatternList=[]
        for j1 in range(0,int(st_per_sirna[i])):
            ost_id = j1+1
            if j1 == j:
                continue
            else:
                osPattern="S"+str(sirna_id)+"_"+str(ost_id)+"~on"
                osPatternList.append(osPattern)
        for k in range(0,sirna_num):
            osirna_id= k+1
            if k == i:
                continue
            else:
                for l in range(0,int(st_per_sirna[k])):
                    ost_id = l+1    
                    osPattern="S"+str(osirna_id)+"_"+str(ost_id)+"~on"
                    osPatternList.append(osPattern)
        
        kinetics="theta_s"+str(sirna_id)+",csi_s"+str(sirna_id)
        rule_theta_csi_site_sirna(sirna_name[i],rbsPattern,ssPattern,change,osPatternList,kinetics)

# Ribosomes interacting with mRNA: binding/unbinding
rbsPattern=b_name
ribsPattern="rib_site~free"
changeRib="rib_site~taken"
kinetics="k1r,k_1r"

ct_st=0
siteOnPattern=[]
for i in range(0,rib_num):
    rib_id= i+1
    for j in range(0,len(eff_per_rib[i])):
        eff_id = j+1
        ct_st += 1
        rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~on,"
        siteOnPattern.append(rsPattern)

ct_st=0        
for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        ct_st += 1
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~on,"
        siteOnPattern.append(ssPattern)


rule = '''    %(rib_free)s + %(rbsPattern)s(''' %locals()    
out_file.write(rule)

for i in range(0,len(siteOnPattern)):
    out_file.write(siteOnPattern[i])
    
rule = '''%(ribsPattern)s) <-> ''' %locals()    
out_file.write(rule)

rule = '''%(rbsPattern)s(''' %locals()    
out_file.write(rule)

for i in range(0,len(siteOnPattern)):
    out_file.write(siteOnPattern[i])

rule = '''%(changeRib)s)     %(kinetics)s ''' %locals()    
out_file.write(rule)
out_file.write('\n')

# RiPS generation
rbsPattern=b_name
ribsPattern="rib_site~taken"
changeRib="rib_site~free"
kinetics="k2r"

rule = '''    %(rbsPattern)s(''' %locals()
out_file.write(rule)
for i in range(0,len(siteOnPattern)):
    out_file.write(siteOnPattern[i])
    
rule = '''%(ribsPattern)s) -> %(rbsPattern)s(''' %locals()
out_file.write(rule)
for i in range(0,len(siteOnPattern)):
    out_file.write(siteOnPattern[i])

rule = '''%(changeRib)s) + %(ribSTART)s     %(kinetics)s ''' %locals()    
out_file.write(rule)
#out_file.write('\n')


# [ribSTART] --> [ribSTOP]
kinetics="k_el_r"
rule='''    %(ribSTART)s -> %(ribSTOP)s     %(kinetics)s ''' % locals()
out_file.write('\n')
out_file.write(rule)

if k_tr != 0:
    # [ribSTOP] --> rib_free (RiPS) + protein_c 
    kinetics="zeta_r"
    rule='''    %(ribSTOP)s -> %(rib_free)s + %(protein_c)s     %(kinetics)s ''' % locals()
    out_file.write('\n')
    out_file.write(rule)
    
    # protein_c --> protein (FaPSout)
    kinetics="k_tr"
    rule='''    %(protein_c)s -> %(protein)s     %(kinetics)s ''' % locals()
    out_file.write('\n')
    out_file.write(rule)
    
    # protein_c --> 
    kinetics="k_dp"
    rule='''    %(protein_c)s -> Trash()     %(kinetics)s ''' % locals()
    out_file.write('\n')
    out_file.write(rule)
else:
    # [ribSTOP] --> rib_free (RiPS) + protein (FaPSout)
    kinetics="zeta_r"
    rule='''    %(ribSTOP)s -> %(rib_free)s + %(protein)s     %(kinetics)s ''' % locals()
    out_file.write('\n')
    out_file.write(rule)
    
# normal degradation: all the siRNA sites must be on (free of RiSC-siRNA)

# ribosome site is free
rbsPattern=b_name
ribsPattern="rib_site~free"
kinetics="k_d"

siteOnPattern=[]        
for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~on,"
        siteOnPattern.append(ssPattern)

apt_num=0       # total number of aptamers on the mRNA
for i in range(0,rib_num):
    for j in range(0,len(eff_per_rib[i])):
        apt_num +=1

apt_st=itertools.product(range(2), repeat=apt_num)

apt_st_num=2**apt_num

for i in range(0,apt_st_num):
    str_st=apt_st.next()
    curr_st=re.sub('\(','',str(str_st))
    curr_st=re.sub('\)','',str(curr_st))
    curr_st=re.split(',',curr_st)
#    print curr_st

    stPatternDeg=[]
    sigOut=[]

    ct_apt=0
    for j in range(0,rib_num):
        rib_id= j+1
        for k in range(0,len(eff_per_rib[j])):
            eff_id = k+1
            bin_state=int(curr_st[ct_apt])
            if bin_state == 0:
                state='off'
            else:
                state='on'    
            ct_apt += 1
            
#            else:
            rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~"+state+","
            stPatternDeg.append(rsPattern)            
            #print rsPattern
            if re.search('I',eff_per_rib[j][k]) and state == 'on':
                sigOut.append(eff_per_rib[j][k])
            if re.search('C',eff_per_rib[j][k]) and state == 'off':
                sigOut.append(eff_per_rib[j][k])

    rule_deg_rb(rbsPattern,ribsPattern,siteOnPattern,sigOut,kinetics)
#    print stPatternDeg,
#    print sigOut

# Fast degradation (one sirna binding site is off)
ribsPattern="rib_site~free"
kinetics="k_fd"

for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1    
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~off"
        osPatternList=[]
        for j1 in range(0,int(st_per_sirna[i])):
            ost_id = j1+1
            if j1 == j:
                continue
            else:
                osPattern="S"+str(sirna_id)+"_"+str(ost_id)+"~on"
                osPatternList.append(osPattern)

        for k in range(0,sirna_num):
            osirna_id= k+1
            if k == i:
                continue
            for l in range(0,int(st_per_sirna[k])):
                ost_id = l+1    
                osPattern="S"+str(osirna_id)+"_"+str(ost_id)+"~on"
                osPatternList.append(osPattern)
        
        # one sirna site is off, all the others are X all the possible configurations of riboswitches' states (rib_site is free)
        apt_num=0       # total number of aptamers on the mRNA
        for i1 in range(0,rib_num):
            for j1 in range(0,len(eff_per_rib[i1])):
                apt_num +=1
        
        apt_st=itertools.product(range(2), repeat=apt_num)
        
        apt_st_num=2**apt_num
        
        for i1 in range(0,apt_st_num):
            str_st=apt_st.next()
            curr_st=re.sub('\(','',str(str_st))
            curr_st=re.sub('\)','',str(curr_st))
            curr_st=re.split(',',curr_st)
#            print curr_st
        
            stPatternDeg=[]
            sigOut=[]
        
            ct_apt=0
            for j1 in range(0,rib_num):
                rib_id= j1+1
                for k1 in range(0,len(eff_per_rib[j1])):
                    eff_id = k1+1
                    bin_state=int(curr_st[ct_apt])
                    if bin_state == 0:
                        state='off'
                    else:
                        state='on'    
                    ct_apt += 1
                    
                    rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~"+state+","
                    stPatternDeg.append(rsPattern)            
                    #print rsPattern
                    if re.search('I',eff_per_rib[j1][k1]) and state == 'on':
                        sigOut.append(eff_per_rib[j1][k1])
                    if re.search('C',eff_per_rib[j1][k1]) and state == 'off':
                        sigOut.append(eff_per_rib[j1][k1])
        
        rule_fast_deg_sirna(sirna_name[i],rbsPattern,ribsPattern,ssPattern,osPatternList,stPatternDeg,sigOut,kinetics)

# ribosome site is taken and all the states are on - normal degradation
rbsPattern=b_name
ribsPattern="rib_site~taken"
kinetics="k_d"

state='on'
stPatternDeg=[]
sigOut=[]
ct_apt=0
for j in range(0,rib_num):
    rib_id= j+1
    for k in range(0,len(eff_per_rib[j])):
        ct_apt += 1
        eff_id = k+1
        rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~"+state+","
        stPatternDeg.append(rsPattern)            
    if re.search('I',eff_per_rib[j][k]):
        sigOut.append(eff_per_rib[j][k])

mod_rib_free='rib_free'
sigOut.append(mod_rib_free) # including rib_free into sigOut list  (without brackets)          

ct_st=0
for l in range(0,sirna_num):
    sirna_id= l+1
    for m in range(0,int(st_per_sirna[l])):
        st_id = m+1
        ct_st += 1
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~on"+","
        stPatternDeg.append(ssPattern)

rule_deg(rbsPattern,stPatternDeg,ribsPattern,sigOut,kinetics)

# ribosome site is taken and one sirna state is off - fast degradation
rbsPattern=b_name
ribsPattern="rib_site~taken"
kinetics="k_fd"

state='on'
stPatternDeg=[]
sigOut=[]
ct_apt=0
for j in range(0,rib_num):
    rib_id= j+1
    for k in range(0,len(eff_per_rib[j])):
        ct_apt += 1
        eff_id = k+1
        rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~"+state
        stPatternDeg.append(rsPattern)            
    if re.search('I',eff_per_rib[j][k]):
        sigOut.append(eff_per_rib[j][k])

#mod_rib_free='rib_free'
#sigOut.append(mod_rib_free) # including rib_free into sigOut list  (without brackets)          

for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1    
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~off"
        osPatternList=[]
        for j1 in range(0,int(st_per_sirna[i])):
            ost_id = j1+1
            if j1 == j:
                continue
            else:
                osPattern="S"+str(sirna_id)+"_"+str(ost_id)+"~on"
                osPatternList.append(osPattern)
        
        for k in range(0,sirna_num):
            osirna_id= k+1
            if k == i:
                continue
            for l in range(0,int(st_per_sirna[k])):
                ost_id = l+1    
                osPattern="S"+str(osirna_id)+"_"+str(ost_id)+"~on"
                osPatternList.append(osPattern)

        rule_deg_fast_plus_ribosome(sirna_name[i],rbsPattern,ribsPattern,stPatternDeg,sigOut,ssPattern,osPatternList,kinetics)


# translation leakage
# ribosome site is free
# here, we also require that all the RiSC-siRNA sites are on (free)
rbsPattern=b_name
ribsPattern="rib_site~free"
kinetics="k2r_lk"

siteOnPattern=[]        
for i in range(0,sirna_num):
    sirna_id= i+1
    for j in range(0,int(st_per_sirna[i])):
        st_id = j+1
        ssPattern="S"+str(sirna_id)+"_"+str(st_id)+"~on,"
        siteOnPattern.append(ssPattern)

apt_num=0       # total number of aptamers on the mRNA
for i in range(0,rib_num):
    for j in range(0,len(eff_per_rib[i])):
        apt_num +=1

apt_states=itertools.product(range(2), repeat=apt_num)
apt_st_num=2**apt_num

apt_st=[]
for i in range(0,apt_st_num):
    name_st=apt_states.next()
    apt_st.append(name_st)

del apt_st[apt_st_num-1]
apt_st_num -= 1

for i in range(0,apt_st_num):
    str_st=apt_st[i]
    curr_st=re.sub('\(','',str(str_st))
    curr_st=re.sub('\)','',str(curr_st))
    curr_st=re.split(',',curr_st)
#    print curr_st

    stPatternDeg=[]

    ct_apt=0
    for j in range(0,rib_num):
        rib_id= j+1
        for k in range(0,len(eff_per_rib[j])):
            eff_id = k+1
            bin_state=int(curr_st[ct_apt])
            if bin_state == 0:
                state='off'
            else:
                state='on'    
            ct_apt += 1
            
            rsPattern="R"+str(rib_id)+"_"+str(eff_id)+"~"+state+","
            stPatternDeg.append(rsPattern)            
                #print rsPattern

    rule_leakage(rbsPattern,stPatternDeg,siteOnPattern,ribsPattern,kinetics)

out_file.write('\n')
out_file.write('end reaction rules')
out_file.write('\n')

#
out_file.write('generate_network({overwrite=>1})\n')
out_file.write('writeNET({})\n')
#
out_file.close()

# MDL file generation    
filename=mrna_name+'.mdl'
filename=filename.lower()
mdl_file=open(filename,'w')

#path_BNG="/Users/mariom/RuleBender/BioNetGen-2.2.0/"
#path_local="/Users/mariom/RuleBender-workspace/test/"
command=path_BNG+'BNG2.pl'+' '+path_local+fname

os.system(command)

filenet=mrna_name+'.net'
pnet=filenet
net_file=open(pnet)
#print pnet

#species_dict={}
storage_intra=[]
adapter_flux=[]
reaction_dict={}

line=''
while line != 'end reactions':
    line=net_file.readline().rstrip('\r\n')
#    print 'LINE',line
    id_species=0
    if re.search('begin species',line):
#        print "HERE\n"
        while line != ('end species'):
        # DEFINING THE SPECIES: storage-intras and adapter-fluxes        
            line=net_file.readline().rstrip('\r\n')
            #print line
            line=line.lstrip()
            tmp=line.split(' ')
#            print tmp
            for i in range(0,len(tmp)):
                if re.search('^\d',tmp[i]) and tmp[i] != '0':
                    id_species=tmp[i]
#                    print 'ID_SPE',id_species
                    continue
                if re.search('\)$',tmp[i]):
                    if re.search('^b',tmp[i]):
                        tmp[i]=re.sub('_','',tmp[i])
                        tmp[i]=re.sub('\(','_',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        tmp[i]=re.sub('~','',tmp[i])
                        tmp[i]=re.sub(',','_',tmp[i])
                        storage_intra.append(tmp[i])
                        species_dict[id_species]=tmp[i]
                    elif re.search('Trash',tmp[i]):
                        species_dict[id_species]=tmp[i]
                        continue
                    elif re.search('KR',tmp[i]):
                        species_dict[id_species]=tmp[i]
                        continue                    
                    elif re.search('ribSTART',tmp[i]):
                        tmp[i]=re.sub('\(','',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        storage_intra.append(tmp[i])
                        species_dict[id_species]=tmp[i]
                    elif re.search('ribSTOP',tmp[i]):
                        tmp[i]=re.sub('\(','',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        storage_intra.append(tmp[i])
                        species_dict[id_species]=tmp[i]
                    elif re.search('protein_c',tmp[i]):
                        tmp[i]=re.sub('\(','',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        storage_intra.append(tmp[i])
                        species_dict[id_species]=tmp[i]
                        
#                    elif re.search('protein',tmp[i]):
#                        tmp[i]=re.sub('\(','',tmp[i])
#                        tmp[i]=re.sub('\)','',tmp[i])
#                        storage_intra.append(tmp[i])
#                        species_dict[id_species]=tmp[i]
                    else:
                        tmp[i]=re.sub('\(','',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        adapter_flux.append(tmp[i])
                        species_dict[id_species]=tmp[i]
        #print species_dict
        #break
#            print line
#        print 'AAAA',line
    #print line
    if re.search('begin reactions',line):
#        print "HEREHERE\n"
        while line != ('end reactions'):
            line=net_file.readline().rstrip('\r\n')
            if line == 'end reactions':
                break
            line=line.lstrip()            #print line
            tmp=line.split(' ')
            r_num=tmp[0]
            reaction_dict[r_num]=Reaction(r_num)
            # Generalization: including the case of creation: KR() must be deleted both from educts and products
            # educts list generation
            reaction_dict[r_num].educts=tmp[1].split(',')
#            print 'EEE:',reaction_dict[r_num].educts
            to_del='' # looking for KR()
            for i in range(0,len(reaction_dict[r_num].educts)):
                c_key=reaction_dict[r_num].educts[i]
                if re.search('KR',species_dict[c_key]):
                    to_del=c_key
 #                   print to_del
            if to_del != '':
                reaction_dict[r_num].educts.remove(to_del)
 #           print 'EEEDDD:',reaction_dict[r_num].educts
            # educts multiplicity
            for i in range(0,len(reaction_dict[r_num].educts)):
                c_val=reaction_dict[r_num].educts[i]
                mult=reaction_dict[r_num].educts.count(c_val)
                c_ed=species_dict[c_val]
                reaction_dict[r_num].educts_mult[c_ed]=mult
            # educts list without repeated elements
            reaction_dict[r_num].setEducts()
            
            # product list generation
            # removing Trash() and KR() from products
            tr_del=''
            kr_del=''
            reaction_dict[r_num].products=tmp[2].split(',')
            #tmp_products=tmp[2].split(',')
 #           print 'PRO:',reaction_dict[r_num].products
            for i in range(0,len(reaction_dict[r_num].products)):
                c_key=reaction_dict[r_num].products[i]
                if re.search('Trash',species_dict[c_key]):
                    tr_del=c_key
                if re.search('KR',species_dict[c_key]):
                    kr_del=c_key
            if tr_del != '':
                reaction_dict[r_num].products.remove(tr_del)
            if kr_del != '':
                reaction_dict[r_num].products.remove(kr_del)
#            reaction_dict[r_num].products=tmp[2].split(',')
 #           print 'PRODDD:',reaction_dict[r_num].products
            # products multiplicity      
            for i in range(0,len(reaction_dict[r_num].products)):
                c_val=reaction_dict[r_num].products[i]
                mult=reaction_dict[r_num].products.count(c_val)
                c_prod=species_dict[c_val]
                reaction_dict[r_num].products_mult[c_prod]=mult
            
            # products list without repeated elements
            reaction_dict[r_num].setProducts()

            reaction_dict[r_num].parameter=tmp[3]

            reaction_dict[r_num].setName()
            reaction_dict[r_num].setKinetics()
            reaction_dict[r_num].setStructure()
            reaction_dict[r_num].setType()
 #           reaction_dict[r_num].print_r()
            reaction_dict[r_num].writeKinetics()
            reaction_dict[r_num].writeStructure()
            if reaction_dict[r_num].type != 'constant-rate-flux':
                reaction_dict[r_num].writeType()

lib_file.close()
#            lib_kinetics.append(reaction_dict[r_num].kinetics)
#            lib_structure.append(reaction_dict[r_num].structure)
#            lib_type.append(reaction_dict[r_num].type)

# Removing repeated elements
#lib_kinetics=list(set(lib_kinetics))
#lib_structure=list(set(lib_structure))
#lib_type=list(set(lib_type))

#print lib_kinetics
#print lib_structure
#print lib_type
            
#----------------
# ADAPTER-FLUXES' HASH
adapter_dict={}
adapter_term={}

if pol_lk == 'y':
    adapter_dict['pops_in_lk']='pops_in_lk'
    adapter_term['pops_in_lk']='out'
    
adapter_dict['protein']='faps_out'
adapter_term['protein']='in'

adapter_dict['rib_free']='rips_b'
adapter_term['rib_free']='out'

adapter_dict['m_mRNA']='RNAps_in'
adapter_term['m_mRNA']='out'


for i in range(0,rib_num):
    for j in range(0,len(eff_per_rib[i])):
        sig=eff_per_rib[i][j]                        
        adapter_dict[sig]='sips_b_'+sig
        adapter_term[sig]='out'

for i in range(0,sirna_num):
    sirna=sirna_name[i]        
    adapter_dict[sirna]='rnaps_b_'+sirna
    adapter_term[sirna]='out'                
            
lim_reactions=int(r_num)+1

# INCIPIT
lines='''
(define-terminal
  :class "term-para-in"
  :super-classes ("terminal")
  :documentation "Input terminal for a real parameter."
  :icon "icons/term_concentration_in.gif"
  :link-color "pink"
  :variables
  (("k"
    :is-a "var-input")))

''' %locals()
mdl_file.write(lines)

#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-module
  :class "%(mrna_name)s"
  :super-classes ("module")
  :icon "m_mrna_pool.png"
  :parameters(
''' %locals()
mdl_file.write(lines)

# Writing the parameters: kinetic parameters and their values
for i in range(1,int(lim_reactions)):
    name_r=reaction_dict[str(i)].name
    if re.search('pops',name_r):
        continue
    param=reaction_dict[str(i)].parameter
    mult=reaction_dict[str(i)].react_mult
    value_p=para_dict[param]
    flux=reaction_dict[str(i)].calcFlux()
    if re.search('k_s',name_r):
        lines='''  ("%(name_r)s.rate"
   :value "%(value_p)f")
  ("%(name_r)s.c0"
   :value "0.0")\n''' %locals()
    elif re.search('k_d',name_r):
        continue
#        lines='''  ("%(name_r)s.k1"
#   :is-eq-to: "parent.kd")
#  ("%(name_r)s.r"
#   :value "parent.v*k1*%(flux)s)"\n''' %locals()
    else:
        lines='''  ("%(name_r)s.k1"
   :value "%(value_p)f")
  ("%(name_r)s.r"
   :value "parent.v*k1*%(flux)s") \n''' %locals()
    mdl_file.write(lines)
        
# Writing the storage-intra concentration (polb and the b-states)
for i in range(0,len(storage_intra)):
    storagei=storage_intra[i]
    lines='''  ("%(storagei)s.c0"
   :value "0")\n''' %locals()
    mdl_file.write(lines)
mdl_file.write('  )\n')                
 
# Writing the terminals
lines='''  :terminals 
   (("exc_rib"
    :is-eq-to "rips_b.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
   ("in_m_mrna_%(coding_name)s"
    :is-eq-to "RNAps_in.in"
    :geometry-side "TOP"
    :geometry-position "0.5")
   ("in_k_d_%(coding_name)s"
    :is-a "term-para-in"
    :geometry-side "TOP"
    :geometry-position "0.9")    
'''  %locals()
mdl_file.write(lines)
 
if pol_lk == 'y':
    lines='''   ("in_pol_lk_%(promoter_name)s"
    :is-eq-to "pops_in_lk.in"
    :geometry-side "LEFT"
    :geometry-position "0.5")
'''  %locals()
    mdl_file.write(lines)

lines='''   ("out_%(product_name)s"
    :is-eq-to "faps_out.out"
    :geometry-side "RIGHT"
    :geometry-position "0.5")
'''  %locals()
mdl_file.write(lines)

for i in range(0,rib_num):
    if re.search('o',rib_kind[i]) or re.search('s',rib_kind[i]):
        sig=eff_per_rib[i][0]        
        lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
'''  %locals()
        mdl_file.write(lines)
    else:
        for j in range(0,len(eff_per_rib[i])):
            sig=eff_per_rib[i][j]        
            lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)

for i in range(0,sirna_num):
    sirna=sirna_name[i]        
    lines='''   ("exc_%(sirna)s"
    :is-eq-to "rnaps_b_%(sirna)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.9")
'''  %locals()
    mdl_file.write(lines)

mdl_file.write('   )\n')
   
# Writing the modules: adapter-fluxes, storage-intras, and reactions
mdl_file.write('  :modules(\n')
for key in adapter_dict:
    adapter=adapter_dict[key]
    lines='''   ("%(adapter)s"
    :is-a "adapter-flux")
'''  %locals()
    mdl_file.write(lines)
    
for i in range(0,len(storage_intra)):
    storage=storage_intra[i]
    lines='''   ("%(storage)s"
    :is-a "storage-intra")
'''  %locals()
    mdl_file.write(lines)

for i in range(1,int(lim_reactions)):
    name_r=reaction_dict[str(i)].name
    if re.search('pops',name_r):
        #flux_id=reaction_dict[str(i)].educts[0]
        #flux_spe=species_dict[flux_id]
        #reaction_dict[str(i)].name=flux_spe
        continue
    elif re.search('k_d',name_r):
        type_r=reaction_dict[str(i)].type
        lines='''   ("%(name_r)s"
    :is-a "%(type_r)s"
    :variables(       
     ("k1"
      :is-eq-to "parent.kd")
     ("r"
      :value "parent.v*k1*%(flux)s")))
'''  %locals()
        mdl_file.write(lines)
    else:
        type_r=reaction_dict[str(i)].type
        lines='''   ("%(name_r)s"
    :is-a "%(type_r)s")
'''  %locals()
        mdl_file.write(lines)

mdl_file.write('   )\n')

# DICT num <-> letters
tm_rea={0:'a',1:'b',2:'c',3:'d',4:'e',5:'f',6:'g',7:'h'}


mdl_file.write('  :links(\n')

# Link generation: storage-intras
link_num=0
for i in range (0,len(storage_intra)):
    my_species=storage_intra[i]
    link=[]
    if my_species == ground_state:
        link_s='"RNAps_in.out"'
        link.append(link_s)

    for j in range(1,int(lim_reactions)):
        for k in range(0,len(reaction_dict[str(j)].educts)):
            edu_id=reaction_dict[str(j)].educts[k]
            edu_name=species_dict[str(edu_id)]
            if my_species == edu_name:
                if re.search('pops',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+"."+adapter_term[reaction_dict[str(j)].name]+'"'
                else:
                    link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[k]+'"'
                link.append(link_s)
                #print link
        for k in range(0,len(reaction_dict[str(j)].products)):
            pro_id=reaction_dict[str(j)].products[k]
            pro_name=species_dict[str(pro_id)]
            index=len(reaction_dict[str(j)].educts)+k
            if my_species == pro_name:
                if re.search('pops',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+"."+adapter_term[reaction_dict[str(j)].name]+'"'
                elif re.search('k_s',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+".cf"    
                else:
                    link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[index]+'"'
                link.append(link_s)
    if len(link) > 0:
        link_num += 1
        link_id="link_"+str(link_num)     
        lines='''   ("%(link_id)s"
    :terminals("%(my_species)s.cf" '''  %locals()
        mdl_file.write(lines)
        for k in range(0,len(link)):
            mdl_file.write(link[k])
            if k < len(link)-1:
                mdl_file.write(' ')
        mdl_file.write('))\n')

# Link generation: adapter-fluxes
for key in adapter_dict:
    key_species=key
    my_species=adapter_dict[key]
    my_terminal=adapter_term[key]
#    print 'ADAPTER:',key_species
    if re.search('pops_in',key):
        continue
    link=[]
    for j in range(1,int(lim_reactions)):
        for k in range(0,len(reaction_dict[str(j)].educts)):
            edu_id=reaction_dict[str(j)].educts[k]
            edu_name=species_dict[str(edu_id)]
            if key_species == edu_name:
                link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[k]+'"'
                link.append(link_s)
#                print 'EDU_NAME:',edu_name,link
                
                #print link
        for k in range(0,len(reaction_dict[str(j)].products)):
            pro_id=reaction_dict[str(j)].products[k]
            pro_name=species_dict[str(pro_id)]
            index=len(reaction_dict[str(j)].educts)+k
            if key_species == pro_name:
                link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[index]+'"'
                link.append(link_s)
#                print 'PRO_NAME:',pro_name,link
    if len(link) > 0:
        link_num += 1
        link_id="link_"+str(link_num)     
        lines='''   ("%(link_id)s"
    :terminals("%(my_species)s.%(my_terminal)s" '''  %locals()
        mdl_file.write(lines)
        for k in range(0,len(link)):
            mdl_file.write(link[k])
            if k < len(link)-1:
                mdl_file.write(' ')
        mdl_file.write('))\n')
mdl_file.write('   )\n')

# kd variable
lines='''  :variables(
   ("kd"
    :is-eq-to "in_k_d_%(coding_name)s.k"))
''' %locals()
mdl_file.write(lines)
#Closing the MDL file
mdl_file.write(')\n')

