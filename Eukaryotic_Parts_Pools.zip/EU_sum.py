#!/usr/bin/python
# Eukaryotic pool generator 

import re
import sys
import os
from collections import defaultdict

#------------------------------------------------------------

##############################
# Start of the MAIN program
#############################

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('EU_sum.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# terminator name
pool_kind=inp_values[0]
available_kinds=['polymerase','ribosome','spliceosome','dicer','risc','reporter']

if pool_kind not in available_kinds:
    print "Error. The pool kind is not correct. You wrote: ", pool_kind
    sys.exit()

print 'pool_kind', pool_kind

reporter_name=inp_values[1]

molecule_dict={'polymerase': 'pol','ribosome': 'rib','spliceosome': 'y','dicer': 'd','risc': 'risc', 'reporter': reporter_name}
flux_dict={'polymerase': 'pops','ribosome': 'rips','spliceosome': 'yps','dicer': 'dps','risc': 'riscps', 'reporter': 'faps'}

molecule=molecule_dict[pool_kind]
flux=flux_dict[pool_kind]

# MDL file generator
pool_name='sum_'+molecule+'_pool'

fname=pool_name+'.mdl'
out_file=open(fname,'w')

if pool_kind != 'reporter':
    icon=molecule+'_pool.png'
else:
    icon='reporter_pool.png'
    
free_conc=0
if pool_kind != 'reporter':
    #lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
    lines='''
    (define-module
      :class "%(pool_name)s"
      :super-classes ("module")
      :icon "%(icon)s"
      :terminals
      (("exc_%(molecule)s_i"
        :is-eq-to "%(flux)s.in"
        :geometry-side "BOTTOM"
        :geometry-position "0.5")
       ("exc_%(molecule)s_o"
        :is-eq-to "%(flux)s.out"
        :geometry-side "TOP"
        :geometry-position "0.5"))
      :modules
      (("%(flux)s"
        :is-a "adapter-flux"))) ''' %locals()
else:
    lines='''
    (define-module
      :class "%(pool_name)s"
      :super-classes ("module")
      :icon "%(icon)s"
      :terminals
      (("in_%(molecule)s"
        :is-eq-to "%(flux)s.in"
        :geometry-side "BOTTOM"
        :geometry-position "0.5")
       ("out_%(molecule)s"
        :is-eq-to "%(flux)s.out"
        :geometry-side "TOP"
        :geometry-position "0.5"))
      :modules
      (("%(flux)s"
        :is-a "adapter-flux"))) ''' %locals()

out_file.write(lines)
out_file.close()

