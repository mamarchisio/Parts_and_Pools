#!/usr/bin/python
# This file create a file for the "cell" system where the compartment "nucleus" and "cytoplasm" are linked
# Then the converter to an SBML-model file is called

import re
import sys
import os
from collections import defaultdict

# MAIN
inp_values=[]
inp_names=[]

# Reading the input 
inp_file=open('Link_compartment.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()
#print inp_values

nucleus_name=inp_values[0]
cytoplasm_name=inp_values[1]
cell_name=inp_values[2]

n_file_name=nucleus_name+'.mdl'
path='./'+n_file_name    
if not os.path.isfile(path):
    print "Error. File: ",n_file_name," does not exist."
    sys.exit()
    
cy_file_name=cytoplasm_name+'.mdl'
path='./'+cy_file_name    
if not os.path.isfile(path):
    print "Error. File: ",cy_file_name," does not exist."
    sys.exit()
                
cell_file_name=cell_name+'.mdl'                
                
n_file=open(n_file_name)
c_file=open(cell_file_name,'w')

terminals_n=[]
terminals_cy=[]

flag_terminal=0
while len(line):
    line=n_file.readline().rstrip('\r\n')
    if re.search('terminals',line):
        flag_terminal=1

    if re.search('modules',line):
        break
            
    if re.search('\(',line) and flag_terminal == 1:
        ter_tmp=line.split('"')
        terminals_n.append(ter_tmp[1])     

        
n_file.close()

# Determining cytoplasm terminals
for i in range(0,len(terminals_n)):
    if re.search('out_',terminals_n[i]):
        tc=terminals_n[i]
        tc=re.sub('out_','in_',tc)
        terminals_cy.append(tc)
    if re.search('in_',terminals_n[i]):
        tc=terminals_n[i]
        tc=re.sub('in_','out_',tc)
        terminals_cy.append(tc)

#print terminals_n
#print terminals_cy

        
# Writing the "cell" module file
lines='''(define-module
  :class "%(cell_name)s"
  :super-classes ("module")
  :modules
  (("%(cytoplasm_name)s"
    :is-a "%(cytoplasm_name)s"
    :geometry-x "180"
    :geometry-y "300")
   ("%(nucleus_name)s"
    :is-a "%(nucleus_name)s"
    :geometry-x "180"
    :geometry-y "100"))
  :links(
''' %locals()

c_file.write(lines)

for i in range(0,len(terminals_n)):
    ln=i+1
    tn=terminals_n[i]
    tcy=terminals_cy[i]
    lines='''   ("link_%(ln)i"
    :terminals ("%(nucleus_name)s.%(tn)s" "%(cytoplasm_name)s.%(tcy)s"))''' %locals()
    c_file.write(lines)
    c_file.write('\n')
    
c_file.write('  ))')
c_file.close()

# Calling the SBML-model parser
command='./SBML_parser.py '+cell_file_name
os.system(command)

