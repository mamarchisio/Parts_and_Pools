#!/usr/bin/python
# Parser for compartment files in MDL

import re
import sys
import os
from collections import defaultdict

tu_modules=[]

# function for parsing transcription unit files: looking for all the modules
def tu_parser(file_tu,tu_modules):
    i_file=open(file_tu)

    flag_module=0
    line=' '
    while len(line):
        line=i_file.readline().rstrip('\r\n')
        if re.search('modules',line):
            flag_module=1
            
        if re.search('links',line):
            flag_module=0
                    
        if re.search('\(',line) and flag_module == 1:
            mod_tmp=line.split('"')
            tu_modules.append(mod_tmp[1])
                
    i_file.close()
    return 
#------------------------------------------------------
# function for re-writing transcription unit files (volume has to be added to parts)
def tu_volume(file_tu):
    inp_file_name=file_tu
    out_file_name='volume_'+file_tu

    inp_file=open(inp_file_name)
    out_file=open(out_file_name,'w')
    
    volume_mod='''    :variables
    (("v"
      :is-eq-to "parent.v")))
''' 
    line=' '
    flag_module=0
    while len(line):
        line=inp_file.readline().rstrip('\r\n')
        if re.search('modules',line):
            flag_module=1
            
        if re.search('links',line):
            flag_module=0
            
        if re.search('\)\)$',line) and flag_module == 1:
            line=re.sub('\)\)$','',line)
            out_file.write(line)
            out_file.write('\n')
            out_file.write(volume_mod)
            out_file.write('    )')
            out_file.write('\n')
            continue
        
        if re.search('\)$',line) and flag_module == 1:
            line=re.sub('\)$','',line)
            out_file.write(line)
            out_file.write('\n')
            out_file.write(volume_mod)
            continue
            
        out_file.write(line)
        out_file.write('\n')
    
    inp_file.close()
    out_file.close()

#    command='cp ./'+inp_file_name+' ./BCK/'+inp_file_name
#    os.system(command)
#    
#    command='mv ./'+out_file_name+' ./'+inp_file_name
#    os.system(command)

#------------------------------------------------------
# MAIN
inp_values=[]
inp_names=[]

# Reading the input 
inp_file=open('Compartments.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

volume=inp_values[0]
if re.search('e',volume):
    volume=re.sub('e','d',volume)

if volume == 'dn':
    volume='3.74d-13'     #'4.2d-15'
elif volume == 'dc':
    volume='9.7d-13'      #'3.0d-14'    
        
ifile=inp_values[1]

c_type=inp_values[2]

#print ifile, volume

inp_file=open(ifile)

out_file_name='compartment_'+ifile
out_file=open(out_file_name,'w')
out_file.write('(include "promot:kb;sbml;sbml-library.mdl")')
out_file.write('\n')

modules=[]
mdl_files=[]
lib_files=[]
libstring='_REACTIONS_LIB.mdl'

if c_type == 'n':
    super_str='''   :super-classes ("compartment")
   :icon "nucleus.png" '''
elif c_type == 'c':
    super_str='''   :super-classes ("compartment")
   :icon "cytoplasm.png" '''    

volume_param='''
  :parameters
  (("v"
    :value "%(volume)s"))
''' %locals()

volume_mod='''    :variables
    (("v"
      :is-eq-to "parent.v")))
''' 

flag_module=0
while len(line):
    line=inp_file.readline().rstrip('\r\n')
    if re.search('modules',line):
        flag_module=1
        
    if re.search('links',line):
        flag_module=0
    
    if re.search('super-classes',line):
        out_file.write(super_str)
        out_file.write(volume_param)
        continue

    if re.search('\)\)$',line) and flag_module == 1:
        line=re.sub('\)\)$','',line)
        out_file.write(line)
        out_file.write('\n')
        out_file.write(volume_mod)
        out_file.write('    )')
        out_file.write('\n')
        continue
    
    if re.search('\)$',line) and flag_module == 1:
        line=re.sub('\)$','',line)
        out_file.write(line)
        out_file.write('\n')
        out_file.write(volume_mod)
        continue
    
    if re.search('\(',line) and flag_module == 1:
        mod_tmp=line.split('"')
        modules.append(mod_tmp[1])     
        mdl_files.append(mod_tmp[1]+'.mdl')
        lib_files.append(mod_tmp[1]+libstring)
        
    out_file.write(line)
    out_file.write('\n')

inp_file.close()
out_file.close()

#print modules
#print mdl_files
#print lib_files


# looking for transcription units
#tu_modules=[]
for i in range(0,len(modules)):
    if re.search('tu_',modules[i]):
#        print modules[i]
        path='./'+modules[i]+'.mdl'
#        print 'PATH:',path
        if os.path.isfile(path):
            file_tu=modules[i]+'.mdl'
            tu_parser(file_tu,tu_modules)
            tu_volume(file_tu)
            mdl_files[i]='volume_'+mdl_files[i]
        else:
            continue

for i in range(0,len(tu_modules)):
    mdl_files.insert(0,tu_modules[i]+'.mdl')
    lib_files.insert(0,tu_modules[i]+libstring)

#print 'TU:',tu_modules
#print mdl_files
#print lib_files

out_file_name='ALL_'+ifile
out_file=open(out_file_name,'w')

for i in range(0,len(lib_files)):
#    if re.search('m_mrna_',lib_files[i]):
#        lib_files[i]=re.sub('m_mrna_','',lib_files[i])
#        print lib_files[i]
    path='./'+lib_files[i]    
    if os.path.isfile(path):
        file_h=open(path)
        out_file.write(file_h.read())
        out_file.write('\n')
        file_h.close()
    else:
        continue
    
for i in range(0,len(mdl_files)):
    path='./'+mdl_files[i]
    if os.path.isfile(path):
        file_h=open(path)
        out_file.write(file_h.read())
        out_file.write('\n')
        file_h.close()
    else:
        continue

path='./'+'compartment_'+ifile
if os.path.isfile(path):
    file_h=open(path)
    out_file.write('\n\n')
    out_file.write(file_h.read())
    out_file.write('\n')
    file_h.close()
else:
    print ''

out_file.close()

