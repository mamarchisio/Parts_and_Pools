#!/usr/bin/python
# Parser for compartment files in MDL

import re
import sys
import os
from collections import defaultdict

if len(sys.argv) == 1:
    print 'One argument is expected.'
    sys.exit()

name=sys.argv[1]

if re.search('mdl',name):
    name=re.sub('\.mdl','',name)

ifile=name+'.mdl'    

print ifile
modules=[]
all_files=[]

inp_file=open(ifile)

out_file_name='sbml_model_'+ifile
out_file=open(out_file_name,'w')


super_str='  :super-classes ("sbml-model")'

flag_module=0
line=' '
while len(line):
    line=inp_file.readline().rstrip('\r\n')
    if re.search('modules',line):
        flag_module=1

    if re.search('links',line):
        flag_module=0    
        
    if re.search('super-classes',line):
        out_file.write(super_str)
        out_file.write('\n')
        continue

    if re.search('\(',line) and flag_module == 1:
        mod_tmp=line.split('"')
        modules.append(mod_tmp[1])     
        all_files.append('ALL_'+mod_tmp[1]+'.mdl')

    out_file.write(line)
    out_file.write('\n')

inp_file.close()
out_file.close()

print modules
print all_files

out_file_name='ALL_'+ifile
out_file=open(out_file_name,'w')

# Writing NEW_LIB.mdl into the "ALL" file
path='./NEW_LIB.mdl'
if os.path.isfile(path):
    file_h=open(path)
    out_file.write(file_h.read())
    file_h.close()

for i in range(0,len(all_files)):
    path='./'+all_files[i]    
    if os.path.isfile(path):
        file_h=open(path)
        out_file.write(file_h.read())
        file_h.close()

path='./'+'sbml_model_'+ifile
if os.path.isfile(path):
    file_h=open(path)
    out_file.write('\n\n')
    out_file.write(file_h.read())
    file_h.close()

out_file.close()

inp_file_name='ALL_'+ifile
#inp_file=open(inp_file_name)
print inp_file_name

out_file_name='TMP_'+ifile
out_file=open(out_file_name,'w')
    
lib_flag=0    
with open(inp_file_name) as i_f:
    for line in i_f:
        line=line.rstrip('\r\n')
        if re.search('sbml-library',line) and lib_flag == 0:
            out_file.write(line)
            out_file.write('\n')
            lib_flag=1
            continue
        
        if re.search('sbml-library',line) and lib_flag == 1:
            continue
        
        out_file.write(line)
        out_file.write('\n')

inp_file.close()
out_file.close()

command='mv TMP_'+ifile+' ALL_'+ifile
os.system(command)


