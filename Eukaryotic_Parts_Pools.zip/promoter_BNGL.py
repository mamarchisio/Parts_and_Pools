#! /usr/bin/python
# Rule-based promoter generator 

import re
import sys
import os
from collections import defaultdict
import itertools
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
import time

#### GLOBAL VARIABLES
species_dict={}
letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
lib_kinetics=[]
lib_structure=[]
lib_type=[]
# CREATING THE REACTION LIB FILE (.MDL)
lib_name=''
promoter_name=''
#lib_name="PROMOTER_REACTIONS_LIB.mdl"
#lib_file=open(lib_name,'w')
#lib_file.write('(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")\n')


##### CLASSES
class Reaction:
    def __init__(self,number):
        self.number=number
        self.educts=[]
        self.products=[]
        self.educts_mult={}
        self.products_mult={}
        self.react_mult=1
        
        self.parameter=''
        self.name=''
        self.kinetics=''
        self.structure=''
        self.type=''

    def print_r(self):
        print 'Name:',self.name
        print 'Parameter:',self.parameter
        print 'Number:',self.number
        print 'Educts:',self.educts
        print 'Products:',self.products
        print 'Type:',self.type
        print 'Kinetics:',self.kinetics
        print 'Structure',self.structure

    def setName(self):
        if re.search('pops',self.parameter):
            self.name=self.parameter
        elif re.search('\*',self.parameter):
            tmp_name=self.parameter.split('*')
            self.name=tmp_name[1]+'_'+self.number
            self.parameter=tmp_name[1]
            if self.parameter == 'k1' or self.parameter == 'k2' or self.parameter == 'k_1' or self.parameter == 'k2_lk':
                self.react_mult=1
            else:
                self.react_mult=tmp_name[0]   
        else:    
            self.name=self.parameter+'_'+self.number
        
    def setKinetics(self):
        # kinetics->irreversible class: for MDL file generation
#        letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        kin='fi_'
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            if edu_mult != 1:
                kin += str(edu_mult)
            lt=letters[i]
            kin += lt
        if len(self.educts) == 0:
            kin += '-'
        self.kinetics=kin

    def setStructure(self):
        # structure class: for MDL file generation
#        letters=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        
        st='s_'
        
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            if edu_mult != 1:
                st += str(edu_mult)
            lt=letters[i]
            st += lt
        if len(self.educts) == 0:
            st += '-'

        st += '_'   
        for i in range(0,len(self.products)):
            j=i+len(self.educts)
            pro_id=self.products[i]
            pro_name=species_dict[pro_id]
            pro_mult=self.products_mult[pro_name]
            if pro_mult != 1:
                st += str(pro_mult)
            lt=letters[j]
            st += lt
        if len(self.products) == 0:
            st += '-'
        self.structure=st

    def setType(self):
        suff=re.sub('s','trans',self.structure)
        self.type=suff

    def setEducts(self): 
   # order preserving
        checked = []
        for e in self.educts:
            if e not in checked:
                checked.append(e)
        self.educts=checked

    def setProducts(self): 
   # order preserving
        checked = []
        for e in self.products:
            if e not in checked:
                checked.append(e)
        self.products=checked

    def writeKinetics(self):
        if self.kinetics not in lib_kinetics:
            lib_kinetics.append(self.kinetics)

            cl_name=self.kinetics
            if cl_name == 'fi_-':
                self.type='constant-rate-flux'
                write_constant_rate_flux()
            else:   
                edu=[]
                for i in range(0,len(self.educts)):
                    edu_id=self.educts[i]
                    edu_name=species_dict[edu_id]
                    edu_mult=self.educts_mult[edu_name]
                    
                    if edu_mult == 1:
                        edu.append(letters[i])
                    else:
                        edu_c=''
                        for j in range(0,edu_mult):
                            edu_c += letters[i]
                            if j != edu_mult-1:
                                edu_c += '*'
                        edu.append(edu_c)
                        
                value=''
                for i in range(0,len(edu)):
                    value += edu[i]
                    value += '.c'
                    if i != len(edu)-1:
                        value +='*'
        
                lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("irreversible")
  :parameters            
   (("r"
     :value "k1*%(value)s"))
  :variables
   (("k1"
     :is-a "var-real-parameter"
     :value "1.0d0"
     :unit "g_dw/umol/h")))
''' %locals()
        
                lib_file.write(lines)

    def calcFlux(self):
        edu=[]
        for i in range(0,len(self.educts)):
            edu_id=self.educts[i]
            edu_name=species_dict[edu_id]
            edu_mult=self.educts_mult[edu_name]
            
            if edu_mult == 1:
                edu.append(letters[i])
            else:
                edu_c=''
                for j in range(0,edu_mult):
                    edu_c += letters[i]
                    if j != edu_mult-1:
                        edu_c += '*'
                edu.append(edu_c)
                
        value=''
        for i in range(0,len(edu)):
            value += edu[i]
            value += '.c'
            if i != len(edu)-1:
                value +='*'
        return value


    def writeStructure(self):
        if self.structure not in lib_structure:
            lib_structure.append(self.structure)

            cl_name=self.structure
    
            term=[]
            flux=[]
            for i in range(0,len(self.educts)):
                edu_id=self.educts[i]
                edu_name=species_dict[edu_id]
                edu_mult=self.educts_mult[edu_name]
                
                term.append(letters[i])                
                if edu_mult == 1:
                    flux.append('-r')
                else:
                    sf='-'+str(edu_mult)+'*r'
                    flux.append(sf)

            for i in range(0,len(self.products)):
                 j=i+len(self.educts)
                 pro_id=self.products[i]
                 pro_name=species_dict[pro_id]
                 pro_mult=self.products_mult[pro_name]
                 
                 term.append(letters[j])                
                 if pro_mult == 1:
                    flux.append('r')
                 else:
                    sf=str(pro_mult)+'*r'
                    flux.append(sf)

            lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("structure")
  :terminals( ''' %locals()
            lib_file.write(lines)
            
            for i in range(0,len(term)):
                c_term=term[i]
                lines='''                
  ("%(c_term)s"
    :is-a "term-reaction-flux")''' %locals()
                lib_file.write(lines)
            
            lib_file.write(')\n')
            lines='''  :equations( '''
            lib_file.write(lines)

            for i in range(0,len(term)):
                c_term=term[i]
                c_flux=flux[i]
                lines='''                
  ("stoech_%(c_term)s"
    :relation "%(c_term)s.r == %(c_flux)s")''' %locals()
                lib_file.write(lines)
            lib_file.write('))\n')
            
            
    def writeType(self):
        if self.type not in lib_type:
            lib_type.append(self.type)

            cl_name=self.type
            k_name=self.kinetics
            s_name=self.structure

            lines='''
(define-module
  :class "%(cl_name)s"
  :super-classes ("%(k_name)s" "%(s_name)s")
  :properties
  (("abstract"
    :value "no"))
  :icon "icons/irrev_r")
  ''' %locals()
            lib_file.write(lines)
            
#------------------------------------------------------------

##### FUNCTIONS
def write_constant_rate_flux():
    lines = '''
(define-module
  :class "constant-rate-flux"
  :super-classes ("help" "special-reaction")
  :properties
  (("abstract"
    :value "no"))
  :icon "icons/irrev_r"
  :terminals
  (("cf"
    :is-a "term-reaction-flux"
    :geometry-side "right"
    :geometry-position "0.5"))
  :variables
  (("rate"
    :is-a "reaction-rate"
    :documentation "Constant rate"
    :system-theoretic "help"
    :value "0.0d0"))
  :equations
  (("hurg"
    :relation "cf.r == rate")))
''' %locals()
    lib_file.write(lines)

#------------------------------------------------------------
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@








#################
## FUNCTIONS
#################
def write_rule_number(out_file):
    global r_numl
    out_file.write('\n')
    out_file.write('// RULE ')
    out_file.write(str(r_numl))
    #out_file.write('\n')
    r_numl += 1
    return
#------------------------------------------------------------
def find_index_coop(i,coop):
    id=i+1
    for j in range(0,len(coop)):
        for k in range(0,len(coop[j])):
            if id == int(coop[j][k]):
                ic = j            
    return ic 
#------------------------------------------------------------
def check_syn(i,syn):
    cs='n'
    if syn == "no":
        return 'n'
    id=i+1
    for j in range(0,len(syn)):
             if id == int(syn[j]):
                cs = 'y'            
    return cs 
#------------------------------------------------------------
def check_coop(i,coop,ic):
    id=i+1
    answ='n'
    for j in range(0,len(coop[ic])):
        if id == int(coop[ic][j]):
            answ = 'y'            
    return answ 
#------------------------------------------------------------
def rule_alpha_beta(prPattern,polSitePattern,opPattern,curr_tf,change,kinetics):
    curr_tf += '()'
    rule='''    %(curr_tf)s + %(prPattern)s(%(opPattern)s,%(polSitePattern)s) <-> %(prPattern)s(%(change)s,%(polSitePattern)s)   %(kinetics)s  ''' % locals()   
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_alpha_beta_c(prPattern,polSitePattern,opPatternList,curr_tf,changeList,kinetics):
    op0p=opPatternList[0]
    op1p=opPatternList[1]
    ch0p=changeList[0]
    ch1p=changeList[1]
    curr_tf += '()'
    rule='''    %(curr_tf)s +  %(prPattern)s(%(op0p)s,%(op1p)s,%(polSitePattern)s) <-> %(prPattern)s(%(ch0p)s,%(ch1p)s,%(polSitePattern)s)   %(kinetics)s  ''' % locals() 
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------ 
def rule_gamma(curr_sg,prPattern,opPattern,polSitePattern,change,curr_tf,kinetics):
    curr_sg += '()'
    curr_tf += '()'
    rule='''    %(curr_sg)s +  %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(change)s,%(polSitePattern)s) + %(curr_tf)s   %(kinetics)s  ''' % locals()     
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_RNApol_bu_simple(prPattern,polSitePattern,pol_free,change,kinetics):
    rule = '''    %(pol_free)s + %(prPattern)s(%(polSitePattern)s) <-> %(prPattern)s(%(change)s)    %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_RNApol_bu(prPattern,polSitePattern,opPatternList,pol_free,change,kinetics):
    #opPatternList corresponds to opPatternR
    rule = '''    %(pol_free)s + %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(polSitePattern)s) <-> %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(change)s)    %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_RNApol_bu_add(prPattern,polSitePattern,opPatternList,opPatternA,pol_free,change,kinetics):
    #opPatternList corresponds to opPatternR
    rule = '''    %(pol_free)s + %(prPattern)s(''' %locals()
    out_file.write(rule)
    if len(opPatternList):
        for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(opPatternA)s,%(polSitePattern)s) <-> %(prPattern)s(''' %locals()
    out_file.write(rule)
    if len(opPatternList):  
        for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(opPatternA)s,%(change)s)    %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return

#------------------------------------------------------------
def rule_RNApol_bu_l(prPattern,polSitePattern,opPatternR,opPatternCoopA,pol_free,change,kinetics):
    rule = '''    %(pol_free)s + %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternR)):
        out_file.write(opPatternR[i])
        out_file.write(',')
    for i in range(0,len(opPatternCoopA)):
        out_file.write(opPatternCoopA[i])
        out_file.write(',')        
    rule = '''%(polSitePattern)s) <-> %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternR)):
        out_file.write(opPatternR[i])
        out_file.write(',')
    for i in range(0,len(opPatternCoopA)):
        out_file.write(opPatternCoopA[i])
        out_file.write(',')
    rule = '''%(change)s)    %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_gamma_pol_free(curr_sig,prPattern,polSitePattern,opPattern1,opPatternList,a_free,changeOp,changePol,kinetics):
    curr_sig += '()'
    a_free += '()'
    rule = '''    %(curr_sig)s + %(prPattern)s(%(opPattern1)s,''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(changePol)s) + pol_free() + %(a_free)s   %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_gamma_pol_stay_1op(curr_sig,prPattern,polSitePattern,opPattern,a_free,changeOp,kinetics):
    curr_sig += '()'
    a_free += '()'
    rule = '''    %(curr_sig)s + %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(polSitePattern)s) + %(a_free)s    %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics):
    curr_sig += '()'
    a_free += '()'    
    rule = '''    %(curr_sig)s + %(prPattern)s(%(opPattern1)s,%(opPattern2)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(opPattern2)s,%(polSitePattern)s) + %(a_free)s     %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_kd_pol_stay_1op(prPattern,polSitePattern,opPattern,productDeg,changeOp,kinetics):
    if len(productDeg):
        productDeg += '()'
        rule = '''    %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(polSitePattern)s) + %(productDeg)s    %(kinetics)s''' %locals()
    else:
        rule = '''    %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(polSitePattern)s)    %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPattern2,productDeg,changeOp,kinetics):
    if len(productDeg):
        productDeg += '()'
        rule = '''    %(prPattern)s(%(opPattern)s,%(opPattern2)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(opPattern2)s,%(polSitePattern)s) + %(productDeg)s    %(kinetics)s''' %locals()
    else:
        rule = '''    %(prPattern)s(%(opPattern)s,%(opPattern2)s,%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,%(opPattern2)s,%(polSitePattern)s)    %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_kd_pol_free(prPattern,polSitePattern,opPattern,opPatternList,productDeg,changeOp,changePol,kinetics):
    rule = '''    %(prPattern)s(%(opPattern)s,''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(polSitePattern)s) -> %(prPattern)s(%(changeOp)s,''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(changePol)s)''' %locals()
    out_file.write(rule)
    if len(productDeg):
        productDeg += '()'
        rule =''' + %(productDeg)s + pol_free()   %(kinetics)s ''' %locals()
    else:
        rule =''' + pol_free()   %(kinetics)s ''' %locals()
    out_file.write(rule)    
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_kd_nopol(prPattern,polSitePattern,opPattern,productDeg,change,kinetics):
    if len(productDeg):
        productDeg += '()'
        rule = '''    %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(change)s,%(polSitePattern)s) + %(productDeg)s     %(kinetics)s''' %locals()
    else:
        rule = '''    %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(change)s,%(polSitePattern)s)      %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_k2(prPattern,polSitePattern,opPatternList,changePol,kinetics):
    rule = '''    %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(polSitePattern)s) -> %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(changePol)s) + pol_cl()      %(kinetics)s''' %locals()  
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_k2_act(prPattern,polSitePattern,opPatternA,opPatternList,changePol,kinetics):
    rule = '''    %(prPattern)s(''' %locals()
    out_file.write(rule)
    if len(opPatternList):
        for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(opPatternA)s,%(polSitePattern)s) -> %(prPattern)s(''' %locals()
    out_file.write(rule)
    if len(opPatternList):
        for i in range(0,len(opPatternList)):
            out_file.write(opPatternList[i])
            out_file.write(',')
    rule = '''%(opPatternA)s,%(changePol)s) + pol_cl()      %(kinetics)s''' %locals()  
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------


def rule_k2_const(prPattern,polSitePattern,changePol,kinetics):
    rule = '''    %(prPattern)s(%(polSitePattern)s) -> %(prPattern)s(%(changePol)s) + pol_cl()      %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return

#------------------------------------------------------------
def rule_k2_lk(prPattern,polSitePattern,opPattern,pol_cl_lk,kinetics):
    rule = '''    %(prPattern)s(%(opPattern)s,%(polSitePattern)s) -> %(prPattern)s(%(opPattern)s,%(polSitePattern)s) + %(pol_cl_lk)s      %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
def rule_k2_lk_ao(prPattern,polSitePattern,opPatternList,pol_cl_lk,kinetics):
    rule = '''    %(prPattern)s(''' %locals()
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(polSitePattern)s) -> %(prPattern)s(''' %locals()    
    out_file.write(rule)
    for i in range(0,len(opPatternList)):
        out_file.write(opPatternList[i])
        out_file.write(',')
    rule = '''%(polSitePattern)s) + %(pol_cl_lk)s      %(kinetics)s''' %locals()
    out_file.write(rule)
    out_file.write('\n')
    return
#------------------------------------------------------------
##############################
# Start of the MAIN program
#############################

with_mdl='n'  # BY HANDS

inp_names=[]
inp_values=[]

# Reading the input 
inp_file=open('promoter.inp')

i=0 
while True:
    line=inp_file.readline().rstrip('\r\n')
    if re.search('^#',line):        
        break 
    if re.search(':',line):
        tmp=line.split(': ')
        inp_names.insert(i,tmp[0])
        inp_values.insert(i,tmp[1])
        i += 1
inp_file.close()

# Assigning input values to variables
# Promoter name
promoter_name=inp_values[0]
print 'promoter_name', promoter_name

lib_name=promoter_name.lower()+"_REACTIONS_LIB.mdl"
lib_file=open(lib_name,'w')
#lib_file.write('(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")\n')

# Number of repressors
rep_num=int(inp_values[1])
#print 'rep_num', rep_num

# Operators per repressor
op_per_rep=inp_values[2].split(',')
#for i in range(0,rep_num):
#    print "R #:",i+1, "operators:",op_per_rep[i]

# Type of repressors
rep=inp_values[3].split(',')
#CHECK. Rep can be: Ra, Ri
for i in range(0,rep_num):
    id=i+1
    if rep[i] != "Ra"+str(id) and rep[i] != "Ri"+str(id):
        print "Error. Check Rep #: ",id
        sys.exit()
#    else:
#        print id, rep[i]

# Initializing the rep_a (active repressors) list
rep_a=[]
for i in range(0,rep_num):
    if re.search('i',rep[i]):
        rep_active=re.sub('i','a',rep[i])
        rep_a.append(rep_active)
    else:
        rep_a.append(rep[i])
#    print "Rep_a #",i+1," :",rep_a[i] 

# Type of chemicals binding repressors. #
sg_rep=inp_values[4].split(',')
for i in range(0,len(sg_rep)):
    sg_rep[i] += 'r'

# CHECK
# Chemicals can be: I (inducers), C (corepressors), and N (no signal).
# Inducers bind Ra.
# Corepressors bind Ri.
# Ra can be associated with No signals.
for i in range(0,rep_num):
    id=i+1
    if sg_rep[i] != "I"+str(id)+'r' and sg_rep[i] != "C"+str(id)+'r' and sg_rep[i] != "N"+str(id)+'r':
        print "Error. Signals can be: I, C, and N. Check Signal #: ",id
        sys.exit()
    if re.search('Ra',rep[i]) and not (re.search('I',sg_rep[i]) or re.search('N',sg_rep[i])):
        print "Error: a signal does not match with its transcription factor. Check Signal #: ",id
        sys.exit()
    if re.search('Ri',rep[i]) and not re.search('C',sg_rep[i]):
        print "Error: a signal does not match with its transcription factor. Check Signal #: ",id
        sys.exit()
 #   print id, sg_rep[i]

# Number of activators
act_num=int(inp_values[5])
#print 'act_num', act_num

# Operators per activator
op_per_act=inp_values[6].split(',')
#for i in range(0,act_num):
#    print "A #:",i+1, "operators:",op_per_act[i]

# Type of activators
act=inp_values[7].split(',')
#CHECK. Act can be: Aa, Ai
for i in range(0,act_num):
    id=i+1
    if act[i] != "Aa"+str(id) and act[i] != "Ai"+str(id):
        print "Error. Check Act #: ",id
        sys.exit()
#    else:
#        print id, act[i]

# Initializing the act_a (active activators) list
act_a=[]
for i in range(0,act_num):
    if re.search('i',act[i]):
        act_active=re.sub('i','a',act[i])
        act_a.append(act_active)
    else:
        act_a.append(act[i])
#    print "Act_a #",i+1," :",act_a[i] 

# Type of chemicals binding activators. #
sg_act=inp_values[8].split(',')
for i in range(0,len(sg_act)):
    sg_act[i] += 'a'
# CHECK
# Chemicals can be: I (inducers), C (coactressors), and N (no signal).
# Inducers bind Ai.
# Corepressors bind Aa.
# Aa can be associated with No signals.
for i in range(0,act_num):
    id=i+1
    if sg_act[i] != "I"+str(id)+'a' and sg_act[i] != "C"+str(id)+'a' and sg_act[i] != "N"+str(id)+'a':
        print "Error. Signals can be: I, C, and N. Check Signal #: ",id
        sys.exit()
    if re.search('Aa',act[i]) and not (re.search('C',sg_act[i]) or re.search('N',sg_act[i])):
        print "Error: a signal does not match with its transcription factor. Check Signal #: ",id
        sys.exit()
    if re.search('Ai',act[i]) and not re.search('I',sg_act[i]):
        print "Error: a signal does not match with its transcription factor. Check Signal #: ",id
        sys.exit()
#    print id, sg_act[i]


# Defining tf_num 
tf_num = rep_num + act_num  

# Repressor cooperativity
if inp_values[9]=='no':
    rep_coop='no'
else:
    rep_coop=inp_values[9].split(',')
    if len(rep_coop) > rep_num:
        print "Error: check repressors' cooperativity."
        sys.exit()
#    print "COOP",rep_coop

# Activator cooperativity
if inp_values[10]=='no':
    act_coop='no'
else:
    act_coop=inp_values[10].split(',')
    if len(act_coop) > act_num:
        print "Error: check activators' cooperativity."
        sys.exit()

#    print "COOP",act_coop

# CHECK. If a rep shows cooperativity, it must bind to more than one operator.
if rep_coop != 'no':
    for i in range(0,len(rep_coop)):
        rep_id=int(rep_coop[i])-1
#        print 'REP_ID',rep_id
        if int(op_per_rep[rep_id]) == 1:
            print "Error. Cooperativity requires at least two operators. Check rep #:",rep_coop[i]
            sys.exit()

# CHECK. If a act shows cooperativity, it must bind to more than one operator. 
if act_coop != 'no':
    for i in range(0,len(act_coop)):
        act_id=int(act_coop[i])-1
        if int(op_per_act[act_id]) == 1:
            print "Error. Cooperativity requires at least two operators. Check act #:",act_coop[i]
            sys.exit()

# CHECK: only two TFs of the same species are allowed
h_coop='no'
if h_coop=='yes':
    if rep_num !=2 and act_num !=0 or rep_num !=0 and act_num !=2:
        print "Error. Hetero cooperativity cannot sussist under these conditions. Check rep_num and act_num."
        sys.exit()
    
# Building a list with the repressors' cooperative behavior. This should be used to check the alpha (and beta) values later.
# oc: hOmo cooperativity           -> 3 alpha values
# nc: no cooperativity             -> 1 alpha value   

rep_cb=[]           # repressors' cooperative behavior
for i in range(0,rep_num):
    rep_cb.append('nc')

if rep_coop != 'no':
    for i in range (1,rep_num+1):
        id=i-1
        if str(i) in rep_coop:
            rep_cb[id]='oc'
        else:
            rep_cb[id]='nc'
#print "rep_CB:",rep_cb


act_cb=[]           # activators' cooperative behavior
for i in range(0,act_num):
    act_cb.append('nc')

if act_coop != 'no':
    for i in range (1,act_num+1):
        id=i-1
        if str(i) in act_coop:
            act_cb[id]='oc'
        else:
            act_cb[id]='nc'
#print "act_CB:",act_cb

    
# Promoter (DNA) concentration.
#p_free=float(inp_values[12])
p_free=inp_values[11]
print "P_free:",p_free


# alpha values (Rep binding)
# Cooperativity among repressors: a repressor bind strongly to the first operator, weakly to the other if the adjacent (to the right) operator is free, cooperatively if the adjacent
# operator is taken.
alpha_rep=inp_values[12].split(',')
for i in range(0,rep_num):
    id = i+1
    if re.search('\(',alpha_rep[i]):
        alpha_rep[i]=re.sub('\(','',alpha_rep[i])
        alpha_rep[i]=re.sub('\)','',alpha_rep[i])
        alpha_rep[i]=alpha_rep[i].split(';')
    else:  
        alpha_rep[i]=re.sub("$",";",alpha_rep[i])
        alpha_rep[i]=alpha_rep[i].split(';')
        alpha_rep[i].remove('')
#    print id, alpha_rep[i]

# CHECK
# alpha_rep requires 1 value (no cooperativity) or 3 values (alpha_s, alpha_w, and alpha_c, homo cooperativity.)    
for i in range(0,rep_num):
    if (re.search('oc',rep_cb[i])) and len(alpha_rep[i]) != 3:
        print "Error. Rep #:",i+1, "requires three values for alpha."
        sys.exit()
    if re.search('nc',rep_cb[i]) and len(alpha_rep[i]) != 1:
        print "Error. Rep #:",i+1, "requires one value for alpha."
        sys.exit()

# WARNINGS 
for i in range(0,rep_num):
    if (re.search('oc',rep_cb[i])) and float(alpha_rep[i][0]) < float(alpha_rep[i][1]):
        print "Warning! At Rep #:",i+1,"alpha_w > alpha_s. This is not consistent with cooperativity."
    if (re.search('oc',rep_cb[i])) and float(alpha_rep[i][1]) > float(alpha_rep[i][2]):
        print "Warning! At Rep #:",i+1,"alpha_w > alpha_c. This is not consistent with cooperativity."
    
# beta values (TF unbinding)
# Same rules as above for alpha. 
beta_rep=inp_values[13].split(',')
for i in range(0,rep_num):
    id = i+1
    if re.search('\(',beta_rep[i]):
        beta_rep[i]=re.sub('\(','',beta_rep[i])
        beta_rep[i]=re.sub('\)','',beta_rep[i])
        beta_rep[i]=beta_rep[i].split(';')
    else:  
        beta_rep[i]=re.sub("$",";",beta_rep[i])
        beta_rep[i]=beta_rep[i].split(';')
        beta_rep[i].remove('')
#    print id, beta_rep[i]

# CHECK
for i in range(0,rep_num):
    if (re.search('oc',rep_cb[i])) and len(beta_rep[i]) != 3:
        print "Error. Rep #:",i+1, "requires three values for beta."
        sys.exit()
    if re.search('nc',rep_cb[i]) and len(beta_rep[i]) != 1:
        print "Error. Rep #:",i+1, "requires one value for beta."
        sys.exit()

# WARNINGS 
for i in range(0,rep_num):
    if (re.search('oc',rep_cb[i])) and float(beta_rep[i][1]) < float(beta_rep[i][0]):
        print "Warning! At TF #:",i+1,"beta_w < beta_s. This is not consistent with cooperativity."
    if (re.search('oc',rep_cb[i])) and float(beta_rep[i][1]) < float(beta_rep[i][2]):
        print "Warning! At TF #:",i+1,"beta_w < beta_c. This is not consistent with cooperativity."


# alpha values (Act binding)
# Cooperativity among activators: a activators bind strongly to the first operator, weakly to the other if the adjacent (to the right) operator is free, cooperatively if the adjacent
# operator is taken.
alpha_act=inp_values[14].split(',')
for i in range(0,act_num):
    id = i+1
    if re.search('\(',alpha_act[i]):
        alpha_act[i]=re.sub('\(','',alpha_act[i])
        alpha_act[i]=re.sub('\)','',alpha_act[i])
        alpha_act[i]=alpha_act[i].split(';')
    else:  
        alpha_act[i]=re.sub("$",";",alpha_act[i])
        alpha_act[i]=alpha_act[i].split(';')
        alpha_act[i].remove('')
#    print id, alpha_act[i]

# CHECK
# alpha_act requires 1 value (no cooperativity) or 3 values (alpha_s, alpha_w, and alpha_c, homo cooperativity.)    
for i in range(0,act_num):
    if (re.search('oc',act_cb[i])) and len(alpha_act[i]) != 3:
        print "Error. Act #:",i+1, "requires three values for alpha."
        sys.exit()
    if re.search('nc',act_cb[i]) and len(alpha_act[i]) != 1:
        print "Error. Act #:",i+1, "requires one value for alpha."
        sys.exit()

# WARNINGS 
for i in range(0,act_num):
    if (re.search('oc',act_cb[i])) and float(alpha_act[i][0]) < float(alpha_act[i][1]):
        print "Warning! At Rep #:",i+1,"alpha_w > alpha_s. This is not consistent with cooperativity."
    if (re.search('oc',act_cb[i])) and float(alpha_act[i][1]) > float(alpha_act[i][2]):
        print "Warning! At Rep #:",i+1,"alpha_w > alpha_c. This is not consistent with cooperativity."
    
# beta values (TF unbinding)
# Same rules as above for alpha. 
beta_act=inp_values[15].split(',')
for i in range(0,act_num):
    id = i+1
    if re.search('\(',beta_act[i]):
        beta_act[i]=re.sub('\(','',beta_act[i])
        beta_act[i]=re.sub('\)','',beta_act[i])
        beta_act[i]=beta_act[i].split(';')
    else:  
        beta_act[i]=re.sub("$",";",beta_act[i])
        beta_act[i]=beta_act[i].split(';')
        beta_act[i].remove('')
#    print id, beta_act[i]

# CHECK
for i in range(0,act_num):
    if (re.search('oc',act_cb[i])) and len(beta_act[i]) != 3:
        print "Error. Act #:",i+1, "requires three values for beta."
        sys.exit()
    if re.search('nc',act_cb[i]) and len(beta_act[i]) != 1:
        print "Error. Act #:",i+1, "requires one value for beta."
        sys.exit()

# WARNINGS 
for i in range(0,act_num):
    if (re.search('oc',act_cb[i])) and float(beta_act[i][1]) < float(beta_act[i][0]):
        print "Warning! At TF #:",i+1,"beta_w < beta_s. This is not consistent with cooperativity."
    if (re.search('oc',act_cb[i])) and float(beta_act[i][1]) < float(beta_act[i][2]):
        print "Warning! At TF #:",i+1,"beta_w < beta_c. This is not consistent with cooperativity."

# k_d_rep (degradation) values. Rep. 
k_d_rep=inp_values[16].split(',')
#print "K_d",k_d_rep

# k_d_act (degradation) values. Act. 
k_d_act=inp_values[17].split(',')
#print "K_d",k_d_act

# gamma (signal-rep binding) values. 
gamma_rep=inp_values[18].split(',')
# CHECK
for i in range(0,rep_num):
    if float(gamma_rep[i]) > 0 and re.search('N',sg_rep[i]):
        print "Error. Gamma must be 0 when no signal is present. Check rep. signal #:",i+1
        sys.exit()

# gamma (signal-act binding) values. 
gamma_act=inp_values[19].split(',')
# CHECK
for i in range(0,act_num):
    if float(gamma_act[i]) > 0 and re.search('N',sg_act[i]):
        print "Error. Gamma must be 0 when no signal is present. Check act. signal #:",i+1
        sys.exit()

# k1 value
#k1=float(inp_values[21])
k1=inp_values[20]
#print "k1",k1

# k_1 value
#k_1=float(inp_values[22])
k_1=inp_values[21]
#print "k_1",k_1

# k2 value
#k2=float(inp_values[23])
k2=inp_values[22]
#print "k2",k2

# k2 leakage value
#k2_lk=float(inp_values[24])
k2_lk=inp_values[23]
#print "k2_lk",k2_lk

# Compartment
compartment=inp_values[24]
# CHECK
if compartment != 'y' and compartment != 'n':
    print "Error. Wrong setting for compartment."
    sys.exit()
#print "Compartment:",compartment

# local directory
path_local=inp_values[25]
#print path_local

# BioNetGen directory
path_BNG=inp_values[26]
#print path_BNG

###################################################################

# Opening the output file
fname=promoter_name+'.bngl'
out_file=open(fname,'w')

para_dict={}  # to be used in the MDL file generation

out_file.write('begin parameters')
p_conc_init=p_free

params='''
    p_conc_init         %(p_conc_init)s 
    k1                  %(k1)s
    k_1                 %(k_1)s
    k2                  %(k2)s
''' % locals()
out_file.write(params)

para_dict['k1']=k1
para_dict['k_1']=k_1
para_dict['k2']=k2

#############################                
# Writing concentrations and parameters
#############################

if rep_num > 0 or act_num > 0: 
    para='''    k2_lk               %(k2_lk)s ''' % locals()
    out_file.write(para)
    para_dict['k2_lk']=float(k2_lk)
    
for i in range(0,rep_num):
    id = i+1
    if re.search('oc',rep_cb[i]):
        alpha_v=alpha_rep[i][0]    
        alpha_str='alpha'+str(id)+"_s_rep"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_rep[i][0]    
        beta_str='beta'+str(id)+"_s_rep"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

        alpha_v=alpha_rep[i][1]    
        alpha_str='alpha'+str(id)+"_w_rep"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_rep[i][1]    
        beta_str='beta'+str(id)+"_w_rep"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

        alpha_v=alpha_rep[i][2]    
        alpha_str='alpha'+str(id)+"_c_rep"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_rep[i][2]    
        beta_str='beta'+str(id)+"_c_rep"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v
    
    if re.search('nc',rep_cb[i]):
        alpha_v=alpha_rep[i][0]    
        alpha_str='alpha'+str(id)+'_rep'
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_rep[i][0]    
        beta_str='beta'+str(id)+'_rep'
        
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

    gamma_v=gamma_rep[i]   
    gamma_str='gamma'+str(id)+'_rep'
    para='''
    %(gamma_str)s               %(gamma_v)s''' %locals()
    out_file.write(para)
    para_dict[gamma_str]=gamma_v

    k_d_v=k_d_rep[i]    
    k_d_str='k_d'+str(id)+'_rep'
    para='''
    %(k_d_str)s             %(k_d_v)s''' %locals()
    out_file.write(para)
    para_dict[k_d_str]=k_d_v

for i in range(0,act_num):
    id = i+1
    if re.search('oc',act_cb[i]):
        alpha_v=alpha_act[i][0]    
        alpha_str='alpha'+str(id)+"_s_act"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_act[i][0]    
        beta_str='beta'+str(id)+"_s_act"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

        alpha_v=alpha_act[i][1]    
        alpha_str='alpha'+str(id)+"_w_act"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_act[i][1]    
        beta_str='beta'+str(id)+"_w_act"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

        alpha_v=alpha_act[i][2]    
        alpha_str='alpha'+str(id)+"_c_act"
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_act[i][2]    
        beta_str='beta'+str(id)+"_c_act"
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v
    
    if re.search('nc',act_cb[i]):
        alpha_v=alpha_act[i][0]    
        alpha_str='alpha'+str(id)+'_act'
        para='''
    %(alpha_str)s               %(alpha_v)s''' %locals()
        out_file.write(para)
        para_dict[alpha_str]=alpha_v

        beta_v=beta_act[i][0]    
        beta_str='beta'+str(id)+'_act'
        para='''
    %(beta_str)s                %(beta_v)s''' %locals()
        out_file.write(para)
        para_dict[beta_str]=beta_v

    gamma_v=gamma_act[i]    
    gamma_str='gamma'+str(id)+'_act'
    para='''
    %(gamma_str)s               %(gamma_v)s''' %locals()
    out_file.write(para)
    para_dict[gamma_str]=gamma_v

    k_d_v=k_d_act[i]    
    k_d_str='k_d'+str(id)+'_act'
    para='''
    %(k_d_str)s             %(k_d_v)s''' %locals()
    out_file.write(para)
    para_dict[k_d_str]=k_d_v

out_file.write('\n end parameters')
out_file.write('\n')
out_file.write('\n')

#print "PARADICT:",para_dict

#####################################################

#######################################
# Molecule types (species) generation
#######################################
out_file.write('begin molecule types')

# Pol_cl (PoPSout): RNA polymerase in the clearing phase, leaving the Promoter
pol_cl='pol_cl()'
pol_cl_declaration='''
    %(pol_cl)s''' % locals()
out_file.write(pol_cl_declaration) 

# pol_free(PoPSb)   
pol_free='pol_free()'
pol_free_declaration='''
    %(pol_free)s''' % locals()
out_file.write(pol_free_declaration)

pol_cl_lk_flag='n'
if rep_num > 0 or act_num > 0:
    pol_cl_lk_flag='y'
    pol_cl_lk='pol_cl_lk()'
    pol_cl_lk_declaration='''
    %(pol_cl_lk)s''' % locals()
    out_file.write(pol_cl_lk_declaration) 


# PROMOTER
# It's made of operators, they are all free at the beginning of a simulation. In order to properly describe the interaction with RNA polymerase, instead of a unique 'taken' state I should
# specify also the kind of TF that 'takes' the operator. Furthermore, I have to give different labels to different operators hosting the same transcription factor.

p_naming='''
    p(''' % locals()
out_file.write(p_naming)

# operators
tf_kind='repressor'
op_id=0
for i in range(0,rep_num):
    tf_id=i+1
    for j in range(0,int(op_per_rep[i])):
        op_id += 1
#        op_label='OP'+str(op_id)
        op_sid = j+1 # second id        
        op_declaration='''Or%(tf_id)i_%(op_sid)i~free~taken_%(tf_kind)s,''' % locals()       
        out_file.write(op_declaration)

# operators
tf_kind='activator'
op_id=0
for i in range(0,act_num):
    tf_id=i+1
    for j in range(0,int(op_per_act[i])):
        op_id += 1
#        op_label='OP'+str(op_id)
        op_sid = j+1 # second id        
        op_declaration='''Oa%(tf_id)i_%(op_sid)i~free~taken_%(tf_kind)s,''' % locals()       
        out_file.write(op_declaration)

        
# polymerase binding site
pol_site_declaration='''pol_site~free~taken''' % locals()
out_file.write(pol_site_declaration)         

out_file.write(')') 
out_file.write('\n') 

# Fluxes and correspondent species (they won't have any site-structured aspect):
# Pol_free, PoPS_b
# TFa, FaPSa_b
# TFi, FaPSi_out
# s, SiPS_b
# Pol_cl, PoPS_out  


# TFa: each transcription factor enters the promoter only its active configuration
for i in range(0,rep_num):
    tfa=rep_a[i]
    tfa_declaration='''    %(tfa)s()''' % locals() 
    out_file.write(tfa_declaration)
    out_file.write('\n')

for i in range(0,act_num):
    tfa=act_a[i]
    tfa_declaration='''    %(tfa)s()''' % locals() 
    out_file.write(tfa_declaration)
    out_file.write('\n')


# TFi: inactive TFs are present in the promoter only with the Ra-I and Aa-C pairs. Indeeed, gamma reactions (I+Ot --> Of+ Ri; C+Ot --> Of+Ai) produce
# inactive TFs that are sent to their pools. 
for i in range(0,rep_num):
    if (re.search('Ra',rep[i]) and re.search('I',sg_rep[i])):
        tfi=rep[i]
        tfi=tfi.replace('a','i')
        tfi_declaration='''    %(tfi)s()''' % locals() 
        out_file.write(tfi_declaration)
        out_file.write('\n')

for i in range(0,act_num):
    if (re.search('Aa',act[i]) and re.search('C',sg_act[i])):
        tfi=act[i]
        tfi=tfi.replace('a','i')
        tfi_declaration='''    %(tfi)s()''' % locals() 
        out_file.write(tfi_declaration)
        out_file.write('\n')


# Signals (if declared they are always present--They appear only in decays when their TFs are inactive in their initial configuration)
for i in range(0,rep_num):
    if not re.search('N',sg_rep[i]):
        sig=sg_rep[i]
        sig_declaration='''    %(sig)s()''' % locals() 
        out_file.write(sig_declaration)
        out_file.write('\n')

for i in range(0,act_num):
    if not re.search('N',sg_act[i]):
        sig=sg_act[i]
        sig_declaration='''    %(sig)s()''' % locals() 
        out_file.write(sig_declaration)
        out_file.write('\n')

out_file.write('    Trash()\n')
out_file.write('end molecule types')
out_file.write('\n') 
out_file.write('\n')

###########################
# Writing seed species
###########################
out_file.write('begin seed species')

# pol_free(PoPSb)   
pol_free='pol_free()'
pol_free_declaration='''
    %(pol_free)s        0''' % locals()
out_file.write(pol_free_declaration)
out_file.write('\n')

# TFa (FaPSb_a)
for i in range(0,rep_num):
    tfa=rep_a[i]
    tfa_declaration='''    %(tfa)s()        0''' % locals() 
    out_file.write(tfa_declaration)
    out_file.write('\n')

for i in range(0,act_num):
    tfa=act_a[i]
    tfa_declaration='''    %(tfa)s()        0''' % locals() 
    out_file.write(tfa_declaration)
    out_file.write('\n')

# TFi (FaPSb_i)
for i in range(0,rep_num):
    if (re.search('Ra',rep[i]) and re.search('I',sg_rep[i])):
        tfi=rep[i]
        tfi=tfi.replace('a','i')
        tfi_declaration='''    %(tfi)s()        0''' % locals() 
        out_file.write(tfi_declaration)
        out_file.write('\n')

for i in range(0,act_num):
    if (re.search('Aa',act[i]) and re.search('C',sg_act[i])):
        tfi=act[i]
        tfi=tfi.replace('a','i')
        tfi_declaration='''    %(tfi)s()        0''' % locals() 
        out_file.write(tfi_declaration)
        out_file.write('\n')

# Signals (SiPSb)
for i in range(0,rep_num):
    if not re.search('N',sg_rep[i]):
        sig=sg_rep[i]
        sig_declaration='''    %(sig)s()        0''' % locals() 
        out_file.write(sig_declaration)
        out_file.write('\n')

for i in range(0,act_num):
    if not re.search('N',sg_act[i]):
        sig=sg_act[i]
        sig_declaration='''    %(sig)s()        0''' % locals() 
        out_file.write(sig_declaration)
        out_file.write('\n')


# promoter with all the operators set to free
p_naming='''    p(''' % locals()
out_file.write(p_naming)

# operators
op_id=0
for i in range(0,rep_num):
    tf_id=i+1
    for j in range(0,int(op_per_rep[i])):
        op_id += 1
        op_label='OP'+str(op_id)
        op_sid = j+1 # second id
        op_declaration='''Or%(tf_id)i_%(op_sid)i~free,''' % locals()       
        out_file.write(op_declaration)

op_id=0
for i in range(0,act_num):
    tf_id=i+1
    for j in range(0,int(op_per_act[i])):
        op_id += 1
        op_label='OP'+str(op_id)
        op_sid = j+1 # second id
        op_declaration='''Oa%(tf_id)i_%(op_sid)i~free,''' % locals()       
        out_file.write(op_declaration)

# polymerase binding site
pol_site_declaration='''pol_site~free''' % locals()
out_file.write(pol_site_declaration)         

# initial concentration
in_conc=''')       %(p_conc_init)s''' % locals()
out_file.write(in_conc) 
out_file.write('\n') 

out_file.write('end seed species')
out_file.write('\n') 
out_file.write('\n')

################################
# RULES FOR REACTION GENERATION
################################
out_file.write('begin reaction rules')
out_file.write('\n')

p_name='p'
# Competition between polymerase and TFs
# Binding-unbinding of active TFs to their operators: polymerase site must be free
prPattern=p_name
polSitePattern="pol_site~free"

# Simple binding (no cooperativity): alpha, beta 
tf_kind='repressor'
for i in range(0,rep_num):
#    print i, rep_cb[i], rep_a[i]
    id=i+1
    curr_tf=rep_a[i]
    if re.search('nc',rep_cb[i]):
        for j in range(0,int(op_per_rep[i])):
            op_id=j+1
            curr_op='Or'+str(id)+'_'+str(op_id)
            opPattern=curr_op+"~free"
            change=curr_op+"~taken_"+tf_kind
            kinetics="alpha"+str(id)+'_rep'+",beta"+str(id)+'_rep'
            rule_alpha_beta(prPattern,polSitePattern,opPattern,curr_tf,change,kinetics)

tf_kind='activator'
for i in range(0,act_num):
#    print i, act_cb[i]
    id=i+1
    curr_tf=act_a[i]
    if re.search('nc',act_cb[i]):
        for j in range(0,int(op_per_act[i])):
            op_id=j+1
            curr_op='Oa'+str(id)+'_'+str(op_id)
            opPattern=curr_op+"~free"
            change=curr_op+"~taken_"+tf_kind
            kinetics="alpha"+str(id)+'_act'+",beta"+str(id)+'_act'
            rule_alpha_beta(prPattern,polSitePattern,opPattern,curr_tf,change,kinetics)


# Cooperativity only: alpha_s (strong site), alpha_w (all the other sites, when the adjacent one is free), alpha_c (replaces alpha_w when the adjacent one is taken).
# The strong site has the lowest number for repressors and the highest for activators (the one with the lowest number is the closest to the TSS).
tf_kind='repressor'
for i in range(0,rep_num):
    if re.search('oc',rep_cb[i]):        
        id=i+1                                                      # independent of the other TFs
        curr_tf=rep_a[i]            
        # strong binding/unbinding to the first operator
        curr_op='Or'+str(id)+'_1'
        opPattern=curr_op+"~free"
        change=curr_op+"~taken_"+tf_kind
        kinetics="alpha"+str(id)+"_s_rep,beta"+str(id)+"_s_rep"
        rule_alpha_beta(prPattern,polSitePattern,opPattern,curr_tf,change,kinetics)
        # weak binding/unbinding to the other operators when the adjacent operators (to the right) is free
        for j in range (1,int(op_per_rep[i])):
            opPatternList=[]
            changeList=[]
            st_id=j+1
            curr_op='Or'+str(id)
            opPattern1=curr_op+"_"+str(st_id)+"~free" # binding site
            change1=curr_op+"_"+str(st_id)+"~taken_"+tf_kind
            rg_st = str(j)
            opPattern2=curr_op+"_"+rg_st+"~free" # adjacent free site 
            change2=curr_op+"_"+str(rg_st)+"~free" # stays free, but this has to be specified in the rule
            kinetics="alpha"+str(id)+"_w_rep,beta"+str(id)+"_w_rep"

            opPatternList.append(opPattern1)
            opPatternList.append(opPattern2)
            changeList.append(change1)
            changeList.append(change2)
            rule_alpha_beta_c(prPattern,polSitePattern,opPatternList,curr_tf,changeList,kinetics)
        #cooperative binding/unbinding to the other operators when the adjacent operator (to the right) is taken
        for j in range (1,int(op_per_rep[i])):
            opPatternList=[]
            changeList=[]
            st_id=j+1
            curr_op='Or'+str(id)
            opPattern1=curr_op+"_"+str(st_id)+"~free" # binding site
            change1=curr_op+"_"+str(st_id)+"~taken_"+tf_kind
            rg_st = str(j)
            opPattern2=curr_op+"_"+rg_st+"~taken_"+tf_kind # adjacent free taken 
            change2=curr_op+"_"+rg_st+"~taken_"+tf_kind
            kinetics="alpha"+str(id)+"_c_rep,beta"+str(id)+"_c_rep"

            opPatternList.append(opPattern1)
            opPatternList.append(opPattern2)
            changeList.append(change1)
            changeList.append(change2)                
            rule_alpha_beta_c(prPattern,polSitePattern,opPatternList,curr_tf,changeList,kinetics)

tf_kind='activator'
for i in range(0,act_num):
    if re.search('oc',act_cb[i]):        
        id=i+1                                                      # independent of the other TFs
        curr_tf=act_a[i]                        
        # strong binding/unbinding to the last operator
        curr_op='Oa'+str(id)+'_'+str(op_per_act[i])
        opPattern=curr_op+"~free"
        change=curr_op+"~taken_"+tf_kind
        kinetics="alpha"+str(id)+"_s_act,beta"+str(id)+"_s_act"
        rule_alpha_beta(prPattern,polSitePattern,opPattern,curr_tf,change,kinetics)
        # weak binding/unbinding to the other operators when the adjacent operators (to the left) is free
        for j in range (int(op_per_act[i])-1,0,-1):
            opPatternList=[]
            changeList=[]
            st_id=j
            curr_op='Oa'+str(id)
            opPattern1=curr_op+"_"+str(st_id)+"~free" # binding site
            change1=curr_op+"_"+str(st_id)+"~taken_"+tf_kind
            rg_st = str(j+1)
            opPattern2=curr_op+"_"+rg_st+"~free" # adjacent free site 
            change2=curr_op+"_"+rg_st+"~free" # adjacent site, stays free
            kinetics="alpha"+str(id)+"_w_act,beta"+str(id)+"_w_act"

            opPatternList.append(opPattern1)
            opPatternList.append(opPattern2)
            changeList.append(change1)
            changeList.append(change2)
            rule_alpha_beta_c(prPattern,polSitePattern,opPatternList,curr_tf,changeList,kinetics)
        # cooperative binding/unbinding to the other operators when the adjacent operator (to the left) is taken
        for j in range (int(op_per_act[i])-1,0,-1):
            opPatternList=[]
            changeList=[]
            st_id=j
            curr_op='Oa'+str(id)
            opPattern1=curr_op+"_"+str(st_id)+"~free" # binding site
            change1=curr_op+"_"+str(st_id)+"~taken_"+tf_kind
            rg_st = str(j+1)
            opPattern2=curr_op+"_"+rg_st+"~taken_"+tf_kind # adjacent taken site 
            change2=curr_op+"_"+rg_st+"~taken_"+tf_kind # adjacent site, stays taken
            kinetics="alpha"+str(id)+"_c_act,beta"+str(id)+"_c_act"

            opPatternList.append(opPattern1)
            opPatternList.append(opPattern2)
            changeList.append(change1)
            changeList.append(change2)
            rule_alpha_beta_c(prPattern,polSitePattern,opPatternList,curr_tf,changeList,kinetics)

# Hetero cooperativity: it means that all the operators of the two activators must be occupied to have polymerase binding the promoter
                    
# Chemicals + TF bound to the promoter: gamma
tf_kind='repressor'
for i in range(0,rep_num):
    if (re.search('Ra',rep[i]) and re.search('I',sg_rep[i])):
#        print "CHEMICAL"
        id=i+1
        curr_tf=rep[i]
        curr_tf=curr_tf.replace('a','i')
        for j in range(0,int(op_per_rep[i])):
            st_id=j+1
            curr_op='Or'+str(id)+'_'+str(st_id)
            curr_sg=sg_rep[i]
            prPattern=p_name
            opPattern=curr_op+"~taken_"+tf_kind
            polSitePattern="pol_site~free"
            change=curr_op+"~free"
            kinetics="gamma"+str(id)+"_rep"
            rule_gamma(curr_sg,prPattern,opPattern,polSitePattern,change,curr_tf,kinetics)

tf_kind='activator'
for i in range(0,act_num):        
    if (re.search('Aa',act[i]) and re.search('C',sg_act[i])):
#        print "CHEMICAL"
        id=i+1
        curr_tf=act[i]
        curr_tf=curr_tf.replace('a','i')
        for j in range(0,int(op_per_act[i])):
            st_id=j+1
            curr_op='Oa'+str(id)+'_'+str(st_id)
            curr_sg=sg_act[i]
            prPattern=p_name
            opPattern=curr_op+"~taken_"+tf_kind
            polSitePattern="pol_site~free"
            change=curr_op+"~free"
            kinetics="gamma"+str(id)+"_act"
            rule_gamma(curr_sg,prPattern,opPattern,polSitePattern,change,curr_tf,kinetics)


############################################
# RNA Polymerase-Promoter interactions
# Binding/unbinding: k1,k_1
############################################
prPattern=p_name
polSitePattern="pol_site~free"
change="pol_site~taken"
kinetics='k1,k_1'

## check if mutually exclusive binding with homo-coop activators (no hetero coop among them) is working properly
if tf_num == 0:     # RNA polymerase binding/unbinding to a constitutive promoter
    rule_RNApol_bu_simple(prPattern,polSitePattern,pol_free,change,kinetics)
else:
    opPatternR=[] 
    for i in range(0,rep_num):
        tf_id=i+1
        # All the operators hosting repressors must be free to let RNA polymerase bind the promoter.
        for j in range(0,int(op_per_rep[i])):
            st_id=j+1
            opPatternR.append("Or"+str(tf_id)+'_'+str(st_id)+"~free")
                
    
    # repressor only
    if rep_num == tf_num:
        rule_RNApol_bu(prPattern,polSitePattern,opPatternR,pol_free,change,kinetics)
    
    # rule: repressor free and mutually exclusive activators
    # when an activator interacts in a mutually exclusive way with other activators of the same species, only one is required to be bound to its operator site to let RNA polymerase bind the promoter.
    #opPatternList=[]
    if rep_num == 0:
        opPatternR=''
        
    for i in range(0,act_num):
        tf_id=i+1
        if act_cb[i] == 'nc':
            for j in range(0,int(op_per_act[i])):
                st_id=j+1
                opPatternA='Oa'+str(tf_id)+'_'+str(st_id)+"~taken_activator"
                rule_RNApol_bu_add(prPattern,polSitePattern,opPatternR,opPatternA,pol_free,change,kinetics)
    
        # rule: repressor free and homo cooperative activators
        if act_cb[i] == 'oc':
            opPatternOCoopA=[]
            for j in range(0,int(op_per_act[i])):
                st_id=j+1
                opPatternOCoopA.append('Oa'+str(tf_id)+'_'+str(st_id)+"~taken_activator")    
            opPatternList.append(opPatternOCoopA)   
            rule_RNApol_bu_l(prPattern,polSitePattern,opPatternR,opPatternOCoopA,pol_free,change,kinetics)
                

###############################
###############################
###############################

##########################
##########################
##########################


##########
# CHEMICALS + ACTIVATORS BOUND TO THE PROMOTER (gamma)
##########
# Corepressors acting on activators bound to the promoter when also RNA polymerase binds the DNA. Depending on the activators' number and interactions, RNA polymerase can get free
##########
prPattern=p_name
polSitePattern="pol_site~taken"
changePol="pol_site~free"      # not always

for i in range(0,act_num):
    tf_id=i+1
    if re.search('Aa',act[i]) and re.search('C',sg_act[i]):
        # cooperativity: RNA polymerase can be released when the activator bound to the rightmost operator (# 1). No other activator able to recrute polymerase must
        # be bound to its operator
        kinetics="gamma"+str(tf_id)+'_act'
        if act_cb[i] == 'oc': 
            curr_sig=sg_act[i]

            for j in range(0,int(op_per_act[i])):
                st_id=j+1
                opPattern1='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
                changeOp='Oa'+str(tf_id)+"_"+str(st_id)+"~free"
                a_free=act[i]
                a_free=re.sub('a','i',a_free)
                opPatternList=[]
                if j > 0:  # no matter the state of the other activation operators, polymerase is not released
                    rule_gamma_pol_stay_1op(curr_sig,prPattern,polSitePattern,opPattern1,a_free,changeOp,kinetics)
                elif j == 0 : # if no other activator around can keep polymerase on the DNA, polymerase is released
                    for k in range(0,act_num):
                        if k == i:
                            continue
                        otf_id=k+1
                        if act_cb[k] == 'oc':                            
                            opPattern='Oa'+str(otf_id)+"_1~free"
                            opPatternList.append(opPattern)
                        if act_cb[k] == 'nc':    
                            for l in range(0,int(op_per_act[k])):
                                ost_id=l+1
                                opPattern='Oa'+str(otf_id)+"_"+str(ost_id)+"~free"
                                opPatternList.append(opPattern)
                    rule_gamma_pol_free(curr_sig,prPattern,polSitePattern,opPattern1,opPatternList,a_free,changeOp,changePol,kinetics)                        
                
                    #opPattern1='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"    
                    for k in range(0,act_num): 
                        if k == i:
                            continue
                        otf_id=k+1
                        if act_cb[k] == 'oc': # if the first operator of another cooperative activator is bound, polymerase is not released                           
                            opPattern2='Oa'+str(otf_id)+"_1~taken_activator"
                            rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics)
                    
#                    opPattern1='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
                    for k in range(0,act_num): 
                        if k == i:
                            continue
                        otf_id=k+1
                        if act_cb[k] == 'nc': # if a single operator of a non-cooperative activator is bound, polymerase is not released
                            for l in range(0,int(op_per_act[k])):
                                ost_id=l+1
                                opPattern2='Oa'+str(otf_id)+"_"+str(ost_id)+"~taken_activator"
                                rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics)
            
        if act_cb[i] == 'nc': 
#            print "NOCOOOOOPPPPP"
            curr_sig=sg_act[i]

            for j in range(0,int(op_per_act[i])):
                st_id=j+1
                opPattern1='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
                changeOp='Oa'+str(tf_id)+"_"+str(st_id)+"~free"
                a_free=act[i]
                a_free=re.sub('a','i',a_free)
                opPatternList=[]
                # Polymerase is released if all the nc operators are free as well as the rightmost oc ones  
                # 1) all the operators where this TF binds must be free
                for k in range(0,int(op_per_act[i])):
                    if k==j:
                        continue
                    ost_id=k+1
                    opPattern='Oa'+str(tf_id)+"_"+str(ost_id)+"~free"
                    opPatternList.append(opPattern)
                    
                # 2) operators for other TFs
                for k in range(0,act_num):
                    if k == i:
                        continue
                    otf_id=k+1
                    
                    # A) all the rightmost ones must be free when coop
                    if act_cb[k] == 'oc':                            
                        opPattern='Oa'+str(otf_id)+"_1~free"
                        opPatternList.append(opPattern)
                        
                    # B) all the operators must be free when no-coop    
                    if act_cb[k] == 'nc':    
                        for l in range(0,int(op_per_act[k])):
                            ost_id=l+1
                            opPattern='Oa'+str(otf_id)+"_"+str(ost_id)+"~free"
                            opPatternList.append(opPattern)                    
                rule_gamma_pol_free(curr_sig,prPattern,polSitePattern,opPattern1,opPatternList,a_free,changeOp,changePol,kinetics)                        
                    
                # Polymerase is not released if another nc operator belonging to this TF is taken
                for k in range(0,int(op_per_act[i])):
                    if k==j:
                        continue
                    ost_id=k+1
                    opPattern2='Oa'+str(tf_id)+"_"+str(ost_id)+"~taken_activator"
                    rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics)

                # Polymerase is not released if another operator belonging to a different TF is taken
                for k in range(0,act_num): 
                    if k == i:
                        continue
                    otf_id=k+1
                    # 1) whatever NC operator is taken 
                    if act_cb[k] == 'nc':
                        for l in range(0,int(op_per_act[k])):
                            ost_id=l+1                    
                            opPattern2='Oa'+str(tf_id)+"_"+str(ost_id)+"~taken_activator"
            
                            rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics)

                    if act_cb[k] == 'oc':
                        # 2) a rightmost CO operator is taken
                        opPattern2='Oa'+str(otf_id)+"_1~taken_activator"
                        rule_gamma_pol_stay_2op(curr_sig,prPattern,polSitePattern,opPattern1,opPattern2,a_free,changeOp,kinetics)


########################
# DEGRADATION
#######################

# Polymerase Binding Site free
prPattern=p_name
polSitePattern="pol_site~free"

tf_kind='repressor'
for i in range(0,rep_num):
    id=i+1
    curr_tf=rep_a[i]
    productDeg=''
    if re.search('i',rep[i]):   
        productDeg=sg_rep[i] 

    for j in range(0,int(op_per_rep[i])):
        id_st=j+1
        curr_op='Or'+str(id)+'_'+str(id_st)    
        opPattern=curr_op+"~taken_"+tf_kind
        change=curr_op+"~free"
        kinetics="k_d"+str(id)+'_rep'
        rule_kd_nopol(prPattern,polSitePattern,opPattern,productDeg,change,kinetics)

tf_kind='activator'
for i in range(0,act_num):
    id=i+1
    curr_tf=act_a[i]
    productDeg=''
    if re.search('i',act[i]):   
        productDeg=sg_act[i] 

    for j in range(0,int(op_per_act[i])):
        id_st=j+1
        curr_op='Oa'+str(id)+'_'+str(id_st)    
        opPattern=curr_op+"~taken_"+tf_kind
        change=curr_op+"~free"
        kinetics="k_d"+str(id)+'_act'
        rule_kd_nopol(prPattern,polSitePattern,opPattern,productDeg,change,kinetics)


# Polymerase Binding Site taken 
prPattern=p_name
polSitePattern="pol_site~taken"
changePol="pol_site~free"      # not always

for i in range(0,act_num):
    tf_id=i+1
    # cooperativity: RNA polymerase can be released when the activator bound to the rightmost operator (# 1). No other activator able to recrute polymerase should
    # be bound to its operator
    if act_cb[i] == 'oc':
        productDeg=''
        if re.search('i',act[i]):   
            productDeg=sg_act[i] 

        kinetics="k_d"+str(tf_id)+'_act'

        for j in range(0,int(op_per_act[i])):
            st_id=j+1
            opPattern='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
            changeOp='Oa'+str(tf_id)+"_"+str(st_id)+"~free"

            opPatternList=[]
            if j > 0:  # no matter the state of the other activation operators, polymerase is not released
                # notice that polymerase is kept by another bound activator, not necessary to specify it, it comes from the states generation    
                rule_kd_pol_stay_1op(prPattern,polSitePattern,opPattern,productDeg,changeOp,kinetics)
            elif j == 0 : # if no other activator around can keep polymerase on the DNA, polymerase is released
                for k in range(0,act_num):
                    if k == i:
                        continue
                    otf_id=k+1
                    if act_cb[k] == 'oc':                            
                        opPattern1='Oa'+str(otf_id)+"_1~free"
                        opPatternList.append(opPattern1)
                    if act_cb[k] == 'nc':    
                        for l in range(0,int(op_per_act[k])):
                            ost_id=l+1
                            opPattern1='Oa'+str(otf_id)+"_"+str(ost_id)+"~free"
                            opPatternList.append(opPattern1)
                rule_kd_pol_free(prPattern,polSitePattern,opPattern,opPatternList,productDeg,changeOp,changePol,kinetics)                        
                    
                for k in range(0,act_num): 
#                    opPatternList=[]
                    if k == i:
                        continue
                    otf_id=k+1
                    if act_cb[k] == 'oc': # if the first operator of another cooperative activator is bound, polymerase is not released                           
                        opPattern2='Oa'+str(otf_id)+"_1~taken_activator"
                        rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPattern2,productDeg,changeOp,kinetics)
                
                for k in range(0,act_num): 
                    if k == i:
                        continue
                    otf_id=k+1
                    if act_cb[k] == 'nc': # if a single operator of a non-cooperative activator is bound, polymerase is not released
                        for l in range(0,int(op_per_act[k])):
                            ost_id=l+1
                            opPattern2='Oa'+str(otf_id)+"_"+str(ost_id)+"~taken_activator"
                            rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPattern2,productDeg,changeOp,kinetics)
    elif act_cb[i] == 'nc':
        productDeg=''
        if re.search('i',act[i]):   
            productDeg=sg_act[i] 

        kinetics="k_d"+str(tf_id)+'_act'

        for j in range(0,int(op_per_act[i])):
            st_id=j+1
            opPattern='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
            changeOp='Oa'+str(tf_id)+"_"+str(st_id)+"~free"

            opPatternList=[]
            for k in range(0,int(op_per_act[i])): # all the other operators where the same Act binds must be free
                ost_id=k+1
                if k == j:
                    continue
                opPatternO='Oa'+str(tf_id)+"_"+str(ost_id)+"~free"
                opPatternList.append(opPatternO)
                
            for k in range(0,act_num): 
                if k == i:
                    continue
                otf_id=k+1
                if act_cb[k] == 'oc': # the first operator of every other cooperative activator must be free                           
                    opPatternO='Oa'+str(otf_id)+"_1~free"
                    opPatternList.append(opPatternO)
                        
                if act_cb[k] == 'nc': # all the operators of every other non-cooperative activator must be free
                    for l in range(0,int(op_per_act[k])):
                        ost_id=l+1
                        opPatternO='Oa'+str(otf_id)+"_"+str(ost_id)+"~free"
                        opPatternList.append(opPatternO)
            # only in these configuration polymerase is released            
            rule_kd_pol_free(prPattern,polSitePattern,opPattern,opPatternList,productDeg,changeOp,changePol,kinetics)

            # in the following: activator degradation without releasing polymerase    
            for k in range(0,int(op_per_act[i])): # at least another operators where the same Act binds is taken
                ost_id=k+1
                if k == j:
                    continue
                opPatternO='Oa'+str(tf_id)+"_"+str(ost_id)+"~taken_activator"
                rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPatternO,productDeg,changeOp,kinetics)
                
            for k in range(0,act_num): 
                if k == i:
                    continue
                otf_id=k+1
                if act_cb[k] == 'oc': # the first operator of a cooperative activator is taken                           
                    opPatternO='Oa'+str(otf_id)+"_1~taken_activator"
                    rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPatternO,productDeg,changeOp,kinetics)
                        
                if act_cb[k] == 'nc': # one operator of another non-cooperative activator must be taken
                    for l in range(0,int(op_per_act[k])):
                        ost_id=l+1
                        opPatternO='Oa'+str(otf_id)+"_"+str(ost_id)+"~taken_activator"
                        rule_kd_pol_stay_2op(prPattern,polSitePattern,opPattern,opPatternO,productDeg,changeOp,kinetics)
            # only in these configuration polymerase is NOT released            

############################################
# PoPS_out generation (promoter clearing): k2
#############################################
prPattern=p_name
polSitePattern="pol_site~taken"
changePol="pol_site~free"      
kinetics="k2"

if tf_num == 0:
    rule_k2_const(prPattern,polSitePattern,changePol,kinetics)
else:
    # All the operators hosting repressors must be free
    opPatternList=[]
    for i in range(0,rep_num):
        tf_id=i+1
        for j in range(0,int(op_per_rep[i])):
            st_id=j+1
            opPatternR='Or'+str(tf_id)+"_"+str(st_id)+'~free'
            opPatternList.append(opPatternR)
    
    if act_num == 0:
        rule_k2(prPattern,polSitePattern,opPatternList,changePol,kinetics)
    
    # Polymerase Binding Site taken 
    for i in range(0,act_num):
        tf_id=i+1
        # cooperativity: RNA polymerase is bound if the rightmost operator (# 1) is taken. 
        if act_cb[i] == 'oc':
            opPatternA='Oa'+str(tf_id)+"_1~taken_activator"
            rule_k2_act(prPattern,polSitePattern,opPatternA,opPatternList,changePol,kinetics)
    
        # non-cooperativity: RNA polymerase is bound whwnever an operator is taken.
        if act_cb[i] == 'nc':    
            for l in range(0,int(op_per_act[i])):
                st_id=l+1
                opPatternA='Oa'+str(tf_id)+"_"+str(st_id)+"~taken_activator"
                rule_k2_act(prPattern,polSitePattern,opPatternA,opPatternList,changePol,kinetics)




#################################
# LEAKAGE 
################################
# We have leakage when at least one repressor is bound
prPattern=p_name
polSitePattern="pol_site~free"
#pol_cl_lk="pol_cl_lk"
kinetics="k2_lk"

for i in range(0,rep_num):
    tf_id=i+1
    for j in range(0,int(op_per_rep[i])):
        st_id=j+1
        opPattern='Or'+str(tf_id)+'_'+str(st_id)+'~taken_repressor'    
        rule_k2_lk(prPattern,polSitePattern,opPattern,pol_cl_lk,kinetics)

## or when some operators are free in case of promoters regulated by activators only
if rep_num == 0 and act_num !=0:
    opPatternList=[]
    for i in range(0,act_num):
        tf_id=i+1
        if act_cb[i] == 'nc': # non cooperativity: all the operators must be free
            for j in range(0,int(op_per_act[i])):
                st_id=j+1
                opPattern='Oa'+str(tf_id)+'_'+str(st_id)+'~free'
                opPatternList.append(opPattern)
        if act_cb[i] == 'oc': # cooperativity: only the right-most operator (#1) must be free
                st_id=1
                opPattern='Oa'+str(tf_id)+'_'+str(st_id)+'~free'
                opPatternList.append(opPattern)
                
    rule_k2_lk_ao(prPattern,polSitePattern,opPatternList,pol_cl_lk,kinetics)

out_file.write('\n')
out_file.write('end reaction rules')
out_file.write('\n')

#
out_file.write('generate_network({overwrite=>1})\n')
out_file.write('writeNET({})\n')
#
out_file.close()

# MDL file generation    
filename=promoter_name+'.mdl'
filename=filename.lower()
mdl_file=open(filename,'w')

#path_BNG="/Users/mariom/RuleBender/BioNetGen-2.2.0/"
#path_local="/Users/mariom/RuleBender-workspace/test/"
command=path_BNG+'BNG2.pl'+' '+path_local+fname

os.system(command)

filenet=promoter_name+'.net'
pnet=filenet
net_file=open(pnet)
print pnet
###########################
###
#######
######
############################
#species_dict={}
storage_intra=[]
adapter_flux=[]
reaction_dict={}

line=''
while line != 'end reactions':
    line=net_file.readline().rstrip('\r\n')
#    print 'LINE',line
    id_species=0
    if re.search('begin species',line):
#        print "HERE\n"
        while line != ('end species'):
        # DEFINING THE SPECIES: storage-intras and adapter-fluxes        
            line=net_file.readline().rstrip('\r\n')
            #print line
            line=line.lstrip()
            tmp=line.split(' ')
#            print tmp
            for i in range(0,len(tmp)):
                if re.search('^\d',tmp[i]) and tmp[i] != '0':
                    id_species=tmp[i]
#                    print 'ID_SPE',id_species
                    continue
                if re.search('\)$',tmp[i]):
                    if re.search('^p\(',tmp[i]):
                        tmp[i]=re.sub('_','',tmp[i])
                        tmp[i]=re.sub('\(','_',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        tmp[i]=re.sub('~','',tmp[i])
                        tmp[i]=re.sub(',','_',tmp[i])
                        storage_intra.append(tmp[i])
                        species_dict[id_species]=tmp[i]
                    elif re.search('Trash',tmp[i]):
                        species_dict[id_species]=tmp[i]
                        continue
                    elif re.search('KR',tmp[i]):
                        species_dict[id_species]=tmp[i]
                        continue                    
                    else:
                        tmp[i]=re.sub('\(','',tmp[i])
                        tmp[i]=re.sub('\)','',tmp[i])
                        adapter_flux.append(tmp[i])
                        species_dict[id_species]=tmp[i]
        #print species_dict
        #break
#            print line
        
    #print line
    if re.search('begin reactions',line):
        
        while line != ('end reactions'):
            line=net_file.readline().rstrip('\r\n')
            if line == 'end reactions':
                break
            line=line.lstrip()            #print line
            tmp=line.split(' ')
            r_num=tmp[0]
            reaction_dict[r_num]=Reaction(r_num)
            # Generalization: including the case of creation: KR() must be deleted both from educts and products
            # educts list generation
            reaction_dict[r_num].educts=tmp[1].split(',')
           
            to_del='' # looking for KR()
            for i in range(0,len(reaction_dict[r_num].educts)):
                c_key=reaction_dict[r_num].educts[i]
                if re.search('KR',species_dict[c_key]):
                    to_del=c_key
#                    print to_del
            if to_del != '':
                reaction_dict[r_num].educts.remove(to_del)
            
            # educts multiplicity
            for i in range(0,len(reaction_dict[r_num].educts)):
                c_val=reaction_dict[r_num].educts[i]
                mult=reaction_dict[r_num].educts.count(c_val)
                c_ed=species_dict[c_val]
                reaction_dict[r_num].educts_mult[c_ed]=mult
            # educts list without repeated elements
            reaction_dict[r_num].setEducts()
            
            # product list generation
            # removing Trash() and KR() from products
            tr_del=''
            kr_del=''
            reaction_dict[r_num].products=tmp[2].split(',')
            #tmp_products=tmp[2].split(',')

            for i in range(0,len(reaction_dict[r_num].products)):
                c_key=reaction_dict[r_num].products[i]
                if re.search('Trash',species_dict[c_key]):
                    tr_del=c_key
                if re.search('KR',species_dict[c_key]):
                    kr_del=c_key
            if tr_del != '':
                reaction_dict[r_num].products.remove(tr_del)
            if kr_del != '':
                reaction_dict[r_num].products.remove(kr_del)
#            reaction_dict[r_num].products=tmp[2].split(',')
            
            # products multiplicity      
            for i in range(0,len(reaction_dict[r_num].products)):
                c_val=reaction_dict[r_num].products[i]
                mult=reaction_dict[r_num].products.count(c_val)
                c_prod=species_dict[c_val]
                reaction_dict[r_num].products_mult[c_prod]=mult
            
            # products list without repeated elements
            reaction_dict[r_num].setProducts()

            reaction_dict[r_num].parameter=tmp[3]

            reaction_dict[r_num].setName()
            reaction_dict[r_num].setKinetics()
            reaction_dict[r_num].setStructure()
            reaction_dict[r_num].setType()
#            reaction_dict[r_num].print_r()
            reaction_dict[r_num].writeKinetics()
            reaction_dict[r_num].writeStructure()
            if reaction_dict[r_num].type != 'constant-rate-flux':
                reaction_dict[r_num].writeType()

lib_file.close()
#            lib_kinetics.append(reaction_dict[r_num].kinetics)
#            lib_structure.append(reaction_dict[r_num].structure)
#            lib_type.append(reaction_dict[r_num].type)

# Removing repeated elements
#lib_kinetics=list(set(lib_kinetics))
#lib_structure=list(set(lib_structure))
#lib_type=list(set(lib_type))

#print lib_kinetics
#print lib_structure
#print lib_type
            
#----------------
# ADAPTER-FLUXES' HASH
adapter_dict={}
adapter_term={}

if pol_cl_lk_flag == 'y':
    adapter_dict['pol_cl_lk']='pops_out_lk'
    adapter_term['pol_cl_lk']='in'
    
adapter_dict['pol_cl']='pops_out'
adapter_term['pol_cl']='in'

adapter_dict['pol_free']='pops_b'
adapter_term['pol_free']='out'

for i in range(0,rep_num):
    repre=rep[i]
    if re.search('a',repre):
        adapter_dict[repre]='faps_b_a_'+repre
        adapter_term[repre]='out'
        
        sig=sg_rep[i]
        if re.search('I',sig):
            adapter_dict[sig]='sips_b_'+sig
            adapter_term[sig]='out'
            
#            print 'RRRRR',repre
            repre_i=re.sub('a','i',repre)
#            print 'RRRRR',repre_i
            adapter_dict[repre_i]='faps_b_i_'+repre_i
            adapter_term[repre_i]='out'
    
    if re.search('i',repre):
        repre_a=rep_a[i]
        adapter_dict[repre_a]='faps_b_a_'+repre_a
        adapter_term[repre_a]='out'
        
        sig=sg_rep[i] # C
        adapter_dict[sig]='sips_b_'+sig
        adapter_term[sig]='out'
            
#        repre_i=rep[i]
#        adapter_dict[repre_i]='faps_b_i_'+repre_i
#        adapter_term[repre_i]='out'
            
for i in range(0,act_num):
    activ=act[i]
    if re.search('a',activ):
        adapter_dict[activ]='faps_b_a_'+activ
        adapter_term[activ]='out'
        
        sig=sg_act[i]
        if re.search('C',sig):
            adapter_dict[sig]='sips_b_'+sig
            adapter_term[sig]='out'
            
            activ_i=re.sub('a','i',activ)
            adapter_dict[activ_i]='faps_b_i_'+activ_i
            adapter_term[activ_i]='out'
    
    if re.search('i',activ):
        activ_a=act_a[i]
        adapter_dict[activ_a]='faps_b_a_'+activ_a
        adapter_term[activ_a]='out'
        
        sig=sg_act[i] # I
        adapter_dict[sig]='sips_b_'+sig
        adapter_term[sig]='out'
            
#        activ_i=act[i]
#        adapter_dict[activ]='faps_b_i_'+activ_i
#        adapter_term[activ]='out'
        
            
lim_reactions=int(r_num)+1

# INCIPIT
#lines='''(include "promot:kb;SignalTransd;libraries;reduced-library.mdl")
lines='''
(define-module
  :class "%(promoter_name)s"
  :super-classes ("module")
  :icon "promoter.png"
  :parameters(
''' %locals()
mdl_file.write(lines)

# Writing the parameters: kinetic parameters and their values
for i in range(1,int(lim_reactions)):
    name_r=reaction_dict[str(i)].name
    if re.search('pops',name_r):
        continue
    param=reaction_dict[str(i)].parameter
    mult=reaction_dict[str(i)].react_mult
    value_p=float(para_dict[param])*float(mult)
    value_s=str(value_p)
    if re.search('e',value_s):
        value_s=re.sub('e','d',value_s)
    flux=reaction_dict[str(i)].calcFlux()
    if re.search('k_s',name_r):
        lines='''  ("%(name_r)s.rate"
   :value "%(value_s)s")
  ("%(name_r)s.c0"
   :value "0.0")\n''' %locals()
    else:
        if compartment == 'n':
            lines='''  ("%(name_r)s.k1"
   :value "%(value_s)s")\n''' %locals()
            mdl_file.write(lines)
        else:
            lines='''  ("%(name_r)s.k1"
   :value "%(value_s)s")
  ("%(name_r)s.r"
   :value "parent.v*k1*%(flux)s") \n''' %locals()
            mdl_file.write(lines)

# Writing the storage-intra concentration (polb and the b-states)
# initial p_free concentration is here missing

# promoter with all the operators set to free
p_string='p'
# operators
op_id=0
for i in range(0,rep_num):
    tf_id=i+1
    for j in range(0,int(op_per_rep[i])):
        op_id += 1
        op_sid = j+1 # second id
        p_string += '_'
        op_string='Or'+str(tf_id)+str(op_sid)+'free'       
        p_string += op_string
        

op_id=0
for i in range(0,act_num):
    tf_id=i+1
    for j in range(0,int(op_per_act[i])):
        op_id += 1
        op_sid = j+1 # second id
        p_string += '_'
        op_string='Oa'+str(tf_id)+str(op_sid)+'free'       
        p_string += op_string

# polymerase binding site
p_string += '_'
pol_site_string='polsitefree'
p_string += pol_site_string

for i in range(0,len(storage_intra)):
    storagei=storage_intra[i]
#    print storagei, p_string, p_free
    if storagei != p_string:
        lines='''  ("%(storagei)s.c0"
       :value "0")\n''' %locals()
        mdl_file.write(lines)
    else:
        lines='''  ("%(storagei)s.c0"
       :value "%(p_free)s")\n''' %locals()
        mdl_file.write(lines)
    
mdl_file.write('  )\n')                
 
# Writing the terminals
lines='''  :terminals
  (("exc_pol"
    :is-eq-to "pops_b.in"
    :geometry-side "LEFT"
    :geometry-position "0.3")
   ("out_pol"
    :is-eq-to "pops_out.out"
    :geometry-side "RIGHT"
    :geometry-position "0.3")
'''  %locals()
mdl_file.write(lines)

if pol_cl_lk_flag == 'y':
    lines='''   ("out_pol_lk_%(promoter_name)s"
    :is-eq-to "pops_out_lk.out"
    :geometry-side "RIGHT"
    :geometry-position "0.7")
'''  %locals()
    mdl_file.write(lines)

for i in range(0,rep_num):
    repre=rep[i]
#    print rep[i]
    if re.search('a',repre):
        lines='''   ("exc_%(repre)s"
    :is-eq-to "faps_b_a_%(repre)s.in"
    :geometry-side "TOP"
    :geometry-position "0.5")
'''  %locals()
        mdl_file.write(lines)
      
        sig=sg_rep[i]
        if re.search('I',sig):
            lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.5")
'''  %locals()
            mdl_file.write(lines)
            
            repre_i=re.sub('a','i',repre)
            lines='''   ("exc_%(repre_i)s"
    :is-eq-to "faps_b_i_%(repre_i)s.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)
    
    if re.search('i',repre):
        repre_a=rep_a[i]
        lines='''   ("exc_%(repre_a)s"
    :is-eq-to "faps_b_a_%(repre_a)s.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
'''  %locals()
        mdl_file.write(lines)
      
        sig=sg_rep[i]
        if re.search('C',sig):
            lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)
            
#        repre_i=rep[i]
#        lines='''   ("exc_%(repre_i)s"
#    :is-eq-to "faps_b_i_%(repre_i)s.in"
#    :geometry-side "TOP"
#    :geometry-position "0.1")
#'''  %locals()
#        mdl_file.write(lines)

for i in range(0,act_num):
    activ=act[i]
#    print act[i]
    if re.search('a',activ):
        lines='''   ("exc_%(activ)s"
    :is-eq-to "faps_b_a_%(activ)s.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
'''  %locals()
        mdl_file.write(lines)
      
        sig=sg_act[i]
        if re.search('C',sig):
            lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)
            
            activ_i=re.sub('a','i',activ)
            lines='''   ("exc_%(activ_i)s"
    :is-eq-to "faps_b_i_%(activ_i)s.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)
    
    if re.search('i',activ):
        activ_a=act_a[i]
        lines='''   ("exc_%(activ_a)s"
    :is-eq-to "faps_b_a_%(activ_a)s.in"
    :geometry-side "TOP"
    :geometry-position "0.1")
'''  %locals()
        mdl_file.write(lines)
      
        sig=sg_act[i]
        if re.search('I',sig):
            lines='''   ("exc_%(sig)s"
    :is-eq-to "sips_b_%(sig)s.in"
    :geometry-side "BOTTOM"
    :geometry-position "0.1")
'''  %locals()
            mdl_file.write(lines)
            
#        activ_i=act[i]
#        lines='''   ("exc_%(activ_i)s"
#    :is-eq-to "faps_b_i_%(activ_i)s.in"
#    :geometry-side "TOP"
#    :geometry-position "0.1")
#'''  %locals()
#        mdl_file.write(lines)

mdl_file.write('   )\n')
   
# Writing the modules: adapter-fluxes, storage-intras, and reactions
mdl_file.write('  :modules(\n')
for key in adapter_dict:
    adapter=adapter_dict[key]
    lines='''   ("%(adapter)s"
    :is-a "adapter-flux")
'''  %locals()
    mdl_file.write(lines)
    
for i in range(0,len(storage_intra)):
    storage=storage_intra[i]
    lines='''   ("%(storage)s"
    :is-a "storage-intra")
'''  %locals()
    mdl_file.write(lines)

for i in range(1,int(lim_reactions)):
    name_r=reaction_dict[str(i)].name
    if re.search('pops',name_r):
        #flux_id=reaction_dict[str(i)].educts[0]
        #flux_spe=species_dict[flux_id]
        #reaction_dict[str(i)].name=flux_spe
        continue
    type_r=reaction_dict[str(i)].type
    lines='''   ("%(name_r)s"
    :is-a "%(type_r)s")
'''  %locals()
    mdl_file.write(lines)

mdl_file.write('   )\n')

# DICT num <-> letters
tm_rea={0:'a',1:'b',2:'c',3:'d',4:'e',5:'f',6:'g',7:'h'}


mdl_file.write('  :links(\n')

# Link generation: storage-intras
link_num=0
for i in range (0,len(storage_intra)):
    my_species=storage_intra[i]
    link=[]
    for j in range(1,int(lim_reactions)):
        for k in range(0,len(reaction_dict[str(j)].educts)):
            edu_id=reaction_dict[str(j)].educts[k]
            edu_name=species_dict[str(edu_id)]
            if my_species == edu_name:
                if re.search('pops',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+"."+adapter_term[reaction_dict[str(j)].name]+'"'
                else:
                    link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[k]+'"'
                link.append(link_s)
                #print link
        for k in range(0,len(reaction_dict[str(j)].products)):
            pro_id=reaction_dict[str(j)].products[k]
            pro_name=species_dict[str(pro_id)]
            index=len(reaction_dict[str(j)].educts)+k
            if my_species == pro_name:
                if re.search('pops',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+"."+adapter_term[reaction_dict[str(j)].name]+'"'
                elif re.search('k_s',reaction_dict[str(j)].name):
                    link_s='"'+reaction_dict[str(j)].name+".cf"    
                else:
                    link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[index]+'"'
                link.append(link_s)
    if len(link) > 0:
        link_num += 1
        link_id="link_"+str(link_num)     
        lines='''   ("%(link_id)s"
    :terminals("%(my_species)s.cf" '''  %locals()
        mdl_file.write(lines)
        for k in range(0,len(link)):
            mdl_file.write(link[k])
            if k < len(link)-1:
                mdl_file.write(' ')
        mdl_file.write('))\n')

# Link generation: adapter-fluxes
for key in adapter_dict:
    key_species=key
    my_species=adapter_dict[key]
    my_terminal=adapter_term[key]
    if re.search('pops_in',key):
        continue
    link=[]
    for j in range(1,int(lim_reactions)):
        for k in range(0,len(reaction_dict[str(j)].educts)):
            edu_id=reaction_dict[str(j)].educts[k]
            edu_name=species_dict[str(edu_id)]
            if key_species == edu_name:
                link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[k]+'"'
                link.append(link_s)
                
                #print link
        for k in range(0,len(reaction_dict[str(j)].products)):
            pro_id=reaction_dict[str(j)].products[k]
            pro_name=species_dict[str(pro_id)]
            index=len(reaction_dict[str(j)].educts)+k
            if key_species == pro_name:
                link_s='"'+reaction_dict[str(j)].name+"."+tm_rea[index]+'"'
                link.append(link_s)
                
    if len(link) > 0:
        link_num += 1
        link_id="link_"+str(link_num)     
        lines='''   ("%(link_id)s"
    :terminals("%(my_species)s.%(my_terminal)s" '''  %locals()
        mdl_file.write(lines)
        for k in range(0,len(link)):
            mdl_file.write(link[k])
            if k < len(link)-1:
                mdl_file.write(' ')
        mdl_file.write('))\n')

#Closing the MDL file
mdl_file.write('   )\n')
mdl_file.write(')\n')

