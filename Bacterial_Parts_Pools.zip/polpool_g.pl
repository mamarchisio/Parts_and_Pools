#! /usr/bin/perl
use strict;

my $i;
my $j;

# Polymerase pool builder.
# Promoter builder.
my $inp_file="polpool.inp";
open(IN,$inp_file);

$_=<IN>;
$_=<IN>;

my @par=();
while(<IN>){
   chop($_);
   $_ =~ s/^.+://;
   $_ =~ s/ //g;
   push(@par,$_);
}

my @def=(2.1e-6,'n');

my $pol_free;
# Setting pol_free value.
if($par[0] !~ /^\s*$/){
   $pol_free = $par[0];
}else{
   $pol_free = $def[0];
}

my $sm_flag;
# Setting pol_free value.
if($par[1] !~ /^\s*$/){
   $sm_flag = $par[1];
}else{
   $sm_flag = $def[1];
}

#########################################################################
# Checking parameters

if($sm_flag ne 'y' && $sm_flag ne 'n'){
     die "Connection with sumpol pools not properly set. \n";
}

#########################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

push(@species,"pol_free");
push(@storages,"pol_free");

push(@in_adapters,"pops_in");
$h_in_adapters{"pops_in"}="pol_free";

push(@in_adapters,"pops_b");
$h_in_adapters{"pops_b"}="pol_free";

# Opening the output file containing all the spacer information
my $outfile;
$outfile="polpool_reactions.txt";
open(OUT,">$outfile");

# Writing tfpool species in the output file
print OUT "Polpool \n";
print OUT "Connected to sumpol pools: $sm_flag \n";
print OUT "Free polymerase: $pol_free \n";
print "\n";
print OUT "Polpool species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Writing all the reactions on the output file
print OUT "Polpool reactions: \n";

my $key;
my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print "PINELLO: $key => $flux \n";
 # $flux =~ s/$\.out/ /;  
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}

close(OUT);
my @letters=('a','b','c','d','e','f','g');

######################################## Writins the MDL file
my $filename="polpool.mdl";
open (MDL,">$filename");

# Loading the libraries
print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"Polpool\"
  :super-classes (\"module\")
  :icon \"Polpool.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
$cc=$pol_free;

print MDL
"  (\"$storages[0].c0\"
   :value \"$cc\")
";

print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"in_pol\"
    :is-eq-to \"pops_in.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.9\")
   (\"exc_pol\"
    :is-eq-to \"pops_b.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.1\")
";

if($sm_flag eq 'y'){
}

print MDL 
"  )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
 print "IN_AD: $in_adapters[$i] \n";

print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

print MDL
"  ))
";
