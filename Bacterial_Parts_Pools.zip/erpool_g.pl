#! /usr/bin/perl
use strict;

my $i;
my $j;

# Enzymatic (Michaelis-Menten) reaction pool builder.
my $inp_file="erpool.inp";
open(IN,$inp_file);

$_=<IN>;
$_=<IN>;

my @par=();
while(<IN>){
   chop($_);
   $_ =~ s/^.+://;
   $_ =~ s/ //g;
   push(@par,$_);
}

my @def=("ER",'n',2.1e-6,1.0e-6,0.1,0.01,0.00116,0.00116,0.00116,'n');

my $pl_name;
# Setting pool name
if($par[0] !~ /^\s*$/){
   $pl_name = $par[0];
}else{
   $pl_name = $def[0];
}

my $su_flag;      
# Setting substrate-like input flag
if($par[1] !~ /^\s*$/){
   $su_flag = $par[1];
}else{
   $su_flag = $def[1];
}

my $su_free;
# Setting initial amount of substrate
if($par[2] !~ /^\s*$/){
   $su_free = $par[2];
}else{
   $su_free = $def[2];
}

my $k1e;
# Setting k1e Michaelis-Menten rate constant
if($par[3] !~ /^\s*$/){
   $k1e = $par[3];
}else{
   $k1e = $def[3];
}

my $k_1e;
# Setting k_1e Michaelis-Menten rate constant
if($par[4] !~ /^\s*$/){
   $k_1e = $par[4];
}else{
   $k_1e = $def[4];
}

my $k2e;
# Setting k2e Michaelis-Menten rate constant
if($par[5] !~ /^\s*$/){
   $k2e = $par[5];
}else{
   $k2e = $def[5];
}

my $k_de;
# Setting enzyme decay rate constant
if($par[6] !~ /^\s*$/){
   $k_de = $par[6];
}else{
   $k_de = $def[6];
}

my $k_ds;
# Setting substrate decay rate constant
if($par[7] !~ /^\s*$/){
   $k_ds = $par[7];
}else{
   $k_ds = $def[7];
}

my $k_des;
# Setting ES decay rate constant
if($par[8] !~ /^\s*$/){
   $k_des = $par[8];
}else{
   $k_des = $def[8];
}

my $comp_flag;
# Setting comp_flag
if($par[9] !~ /^\s*$/){
   $comp_flag = $par[9];
}else{
   $comp_flag = $def[9];
}


############################################################################
# Checking parameters 

if($su_flag ne 'y' && $su_flag ne 'n'){
	die "Use (y/n) for the presence of an incoming substrate flux. \n";
}

# Compartment flag
if($comp_flag ne 'n' && $comp_flag ne 'y'){
        die "Compartment presence must be properly specified. You wrote: Compart
ment:  $comp_flag \n";
}

############################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

# Enzyme
push(@species,"e");
push(@storages,"e");

push(@in_adapters,"enps_in");
$h_in_adapters{"enps_in"}="e";

# Substrate
push(@species,"s");
push(@storages,"s");

if($su_flag eq 'y'){
  push(@in_adapters,"sups_in");
  $h_in_adapters{"sups_in"}="s";
}

# Enzyme-substrate complex
push(@species,"es");
push(@storages,"es");

# Product
push(@species,"pro");
push(@out_adapters,"pro");
$h_out_adapters{"pro"}="props_out";

# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
    $h_species{$species[$i]}=$i;
}

# Opening the output file containing all the tfpool information
my $outfile;
$outfile=$pl_name."_reactions.txt";
open(OUT,">$outfile");

# Writing tfpool species in the output file
print OUT "$pl_name \n";
print OUT "Substrate input flux: $su_flag \n";
print OUT "Free substrate: $su_free \n";
print "\n";
print OUT "$pl_name species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Enzyme-substrate Michaelis-Menten reaction(s) 
push(@reactions,"k1e");  
$educts{$reactions[$#reactions]}=["e","s"]; 
$products{$reactions[$#reactions]}=["es"];
$values{$reactions[$#reactions]}=$k1e;	

push(@reactions,"k_1e");
$educts{$reactions[$#reactions]}=["es"];
$products{$reactions[$#reactions]}=["e","s"];
$values{$reactions[$#reactions]}=$k_1e;

push(@reactions,"k2e");
$educts{$reactions[$#reactions]}=["es"];
$products{$reactions[$#reactions]}=["e","pro"];
$values{$reactions[$#reactions]}=$k2e;      

# Decays 
push(@reactions,"k_de");
$educts{$reactions[$#reactions]}=["e"];
$products{$reactions[$#reactions]}=[];
$values{$reactions[$#reactions]}=$k_de;

push(@reactions,"k_ds");
$educts{$reactions[$#reactions]}=["s"];
$products{$reactions[$#reactions]}=[];
$values{$reactions[$#reactions]}=$k_ds;
 
push(@reactions,"k_des");
$educts{$reactions[$#reactions]}=["es"];
$products{$reactions[$#reactions]}=[];
$values{$reactions[$#reactions]}=$k_des;

# Writing all the reactions on the output file
print OUT "$pl_name reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print "PINELLO: $key => $flux \n";
 # $flux =~ s/$\.out/ /;  
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}

print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Checking the reactions
for($i=0;$i<scalar(@reactions); $i++){
  print "$reactions[$i] \n";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print "e$j \t $educts{$key}[$j] \n";
  }
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print "p$j \t $products{$key}[$j] \n";
  }
  print "------------------------- \n";
}

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
      $h_reactions{$reactions[$i]}=$i;
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    print "P: $letters[$counter] \n";
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }
}

print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$pl_name."_pool.mdl";
open (MDL,">$filename");

# Loading the libraries
print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$pl_name\_pool\"
  :super-classes (\"module\")
  :icon \"Tfpool.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
    if($storages[$i] eq "s"){
      $cc=$su_free;
    }else{
      $cc=0.0;
    }

print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

if($comp_flag eq 'y'){
        for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1*";
                for($j=0; $j<scalar(@{$educts{$reactions[$i]}}); $j++){
print MDL "$letters[$j].c";
                        if($j+1<scalar(@{$educts{$reactions[$i]}})){
print MDL "*";
                        }else{
print MDL "\")
";
                        }
                }
        }
}

for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"in_en\"
    :is-eq-to \"enps_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.5\")
";

if($su_flag eq 'y'){
print MDL 
"   (\"in_su\"
    :is-eq-to \"sups_in.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.5\")
";
}

print MDL
"   (\"out_pro\"
    :is-eq-to \"props_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.5\")
";

print MDL 
"   )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

foreach $key (keys %h_out_adapters){
  print "H_OUT_AD: $key \t $h_out_adapters{$key} \n";
print MDL 
"   (\"$h_out_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
 print "IN_AD: $in_adapters[$i] \n";

print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    if($reactions[$i] eq "delta"){
      $cl="trans2c-fi2a_r";
    }elsif($reactions[$i] eq "epsilon"){
      $cl="trans2b-fi1_r";
    }	
    $class{$reactions[$i]}=$cl;
#  print "$reactions[$i] \t $cl \n";
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
#      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$storages[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
#	print "pinello \n";
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@out_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_out_adapters{$out_adapters[$i]}.in\""; # always IN terminal
    print "A: $out_adapters[$i] \n";
    foreach $key (keys %h_reactions){ # fictitious reactions
      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){
	print "LAEAK: $key \t $h_in_adapters{$key} \t $out_adapters[$i] \n";
        if($h_in_adapters{$key} eq $h_out_adapters{$out_adapters[$i]}){
print MDL " \"$key.out\"";
        }
    }
print MDL "))
";
    $c_lk++;
}

print MDL
"  ))
";

# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}

