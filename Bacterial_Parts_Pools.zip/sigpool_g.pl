#! /usr/bin/perl
use strict;

my $i;
my $j;

# Signal pool builder.

my $inp_file="sigpool.inp";
open(IN,$inp_file);

$_=<IN>;
$_=<IN>;

my @par=();
while(<IN>){
   chop($_);
   $_ =~ s/^.+://;
   $_ =~ s/ //g;
   push(@par,$_);
}

my @def=("Sig",'n',0.0e0,1e9,3.21e-5,'n');

my $sg;
# Setting the signal name.
if($par[0] !~ /^\s*$/){
   $sg = $par[0];
}else{
   $sg = $def[0];
}

my $in_flag;
# Setting in_flag: 'y', the signal comes from another part; 'n', otherwise.
if($par[1] !~ /^\s*$/){
   $in_flag = $par[1];
}else{
   $in_flag = $def[1];
}

my $s_free;
# Setting s_free value.
if($par[2] !~ /^\s*$/){
   $s_free = $par[2];
}else{
   $s_free = $def[2];
}

my $k_s;
# Setting k_s value.
if($par[3] !~ /^\s*$/){
   $k_s = $par[3];
}else{
   $k_s = $def[3];
}

my $k_d;
# Setting k_d value.
if($par[4] !~ /^\s*$/){
   $k_d = $par[4];
}else{
   $k_d = $def[4];
}

my $comp_flag;
# Setting comp_flag
if($par[5] !~ /^\s*$/){
   $comp_flag = $par[5];
}else{
   $comp_flag = $def[5];
}


##################################################################
# Checking the parameters

if($in_flag ne 'y' && $in_flag ne 'n'){
  die "Please, specify if the signal pool is connected or not to a signal source (part). \n";
}

# Compartment flag
if($comp_flag ne 'n' && $comp_flag ne 'y'){
        die "Compartment presence must be properly specified. You wrote: Compart
ment:  $comp_flag \n";
}

##################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

push(@species,"s_free");
push(@storages,"s_free");

push(@in_adapters,"sips_b"); 
$h_in_adapters{"sips_b"}="s_free";

if($in_flag eq 'y'){
  push(@in_adapters,"sips_in");
  $h_in_adapters{"sips_in"}="s_free";
}

# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
    $h_species{$species[$i]}=$i;
}

# Opening the output file containing all the tfpool information
my $outfile;
$outfile=$sg."_reactions.txt";
open(OUT,">$outfile");

# Writing tfpool species in the output file
print OUT "$sg \n";
print OUT "Connected to an input source: $sg \n";
print "\n";
print OUT "$sg species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Signal decay
push(@reactions,"k_d");  
$educts{$reactions[$#reactions]}=["s_free"]; 
$products{$reactions[$#reactions]}=[];
$values{$reactions[$#reactions]}=$k_d;	

# Signal generation
if($in_flag eq 'n'){
  push(@reactions,"k_s");
  $educts{$reactions[$#reactions]}=[];
  $products{$reactions[$#reactions]}=["s_free"];
  $values{$reactions[$#reactions]}=$k_s;
}

# Writing all the reactions on the output file
print OUT "$sg reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print "PINELLO: $key => $flux \n";
 # $flux =~ s/$\.out/ /;  
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}

print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Checking the reactions
for($i=0;$i<scalar(@reactions); $i++){
  print "$reactions[$i] \n";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print "e$j \t $educts{$key}[$j] \n";
  }
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print "p$j \t $products{$key}[$j] \n";
  }
  print "------------------------- \n";
}

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
      $h_reactions{$reactions[$i]}=$i;
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    print "P: $letters[$counter] \n";
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }
}

print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$sg."_pool.mdl";
open (MDL,">$filename");

# Loading the libraries
print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$sg\_pool\"
  :super-classes (\"module\")
  :icon \"Sigpool.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
    if($storages[$i] eq "s_free"){
      $cc=$s_free;
    }else{
      $cc=0.0;
    }
print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

if($comp_flag eq 'y'){
        for($i=0;$i<scalar(@reactions);$i++){
		if($reactions[$i] eq "k_s"){   # signal production, this has to be checked, what is the proper rate?
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1\")
";	
#			next;
		}else{
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1*";
                for($j=0; $j<scalar(@{$educts{$reactions[$i]}}); $j++){
print MDL "$letters[$j].c";
                        if($j+1<scalar(@{$educts{$reactions[$i]}})){
print MDL "*";
                        }else{
print MDL "\")
";
                        }
                }
		}
        }
}


for($i=0;$i<scalar(@reactions);$i++){
if($reactions[$i] eq "k_s"){
print MDL
"  (\"$reactions[$i].rate\"
   :value \"$values{$reactions[$i]}\")
  (\"$reactions[$i].c0\"
   :value \"0.0\")
";
}else{
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
}

print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"exc_sig\"
    :is-eq-to \"sips_b.in\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.1\")
";

if($in_flag eq 'y'){
print MDL
"    (\"in_sg\"
    :is-eq-to \"sips_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.1\")
";
}

print MDL 
"   )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

foreach $key (keys %h_out_adapters){
  print "H_OUT_AD: $key \t $h_out_adapters{$key} \n";
print MDL 
"  (\"$h_out_adapters{$key}\"
   :is-a \"adapter-flux\")
";
}

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
 print "IN_AD: $in_adapters[$i] \n";

print MDL
"  (\"$in_adapters[$i]\"
    :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"$storages[$i]\"
   :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    if($reactions[$i] eq "k_s"){
      $cl="constant-rate-flux";
    }	
    $class{$reactions[$i]}=$cl;
#  print "$reactions[$i] \t $cl \n";
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
      if($key eq "k_s"){
	if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.cf\"";
        }
      }else{
         if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
         }
      }
    }
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@out_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_out_adapters{$out_adapters[$i]}.in\""; # always IN terminal
    print "A: $out_adapters[$i] \n";
    foreach $key (keys %h_reactions){ # fictitious reactions
      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){
	print "LAEAK: $key \t $h_in_adapters{$key} \t $out_adapters[$i] \n";
        if($h_in_adapters{$key} eq $h_out_adapters{$out_adapters[$i]}){
print MDL " \"$key.out\"";
        }
    }
print MDL "))
";
    $c_lk++;
}

print MDL
"  ))
";

# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}

