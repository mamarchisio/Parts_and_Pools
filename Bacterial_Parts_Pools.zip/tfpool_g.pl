#! /usr/bin/perl
use strict;

my $i;
my $j;

# Transcription factor pool builder.
my $inp_file="tfpool.inp";
open(IN,$inp_file);

$_=<IN>;
$_=<IN>;

my @par=();
while(<IN>){
   chop($_);
   $_ =~ s/^.+://;
   $_ =~ s/ //g;
   push(@par,$_);
}

my @def=("Tfd",'m','a','n',0.0,0.00116,1e9,10,1e6,1e-3,'n');

my $tf;
# Setting the tf name.
if($par[0] !~ /^\s*$/){
   $tf = $par[0];
}else{
   $tf = $def[0];
}

my $type;
# Setting the tf type
if($par[1] !~ /^\s*$/){
   $type = $par[1];
}else{
   $type = $def[1];
}

my $state;
# Setting the tf state: active/inactive
if($par[2] !~ /^\s*$/){
   $state = $par[2];
}else{
   $state = $def[2];
}

my $sg_flag;
# Setting signal flag
if($par[3] !~ /^\s*$/){
   $sg_flag = $par[3];
   }else{
   $sg_flag = $def[3];
}

my $tf_free;
# Setting tf_free value.
if($par[4] !~ /^\s*$/){
   $tf_free = $par[4];
   }else{
   $tf_free = $def[4];
}

my $k_d;
# Setting k_d value.
if($par[5] !~ /^\s*$/){
   $k_d = $par[5];
}else{
   $k_d = $def[5];
}

my $delta;
# Setting delta value.
if($par[6] !~ /^\s*$/){
   $delta = $par[6];
}else{
   $delta = $def[6];
}

my $epsilon;
# Setting epsilon value.
if($par[7] !~ /^\s*$/){
   $epsilon = $par[7];
}else{
   $epsilon = $def[7];
}

my $lambda;
# Setting lambda
if($par[8] !~ /^\s*$/){
   $lambda = $par[8];
   }else{
   $lambda = $def[8];
}

my $mu;
# Setting mu
if($par[9] !~ /^\s*$/){
   $mu = $par[9];
   }else{
   $mu = $def[9];
}

my $comp_flag;
# Setting comp_flag
if($par[10] !~ /^\s*$/){
   $comp_flag = $par[10];
}else{
   $comp_flag = $def[10];
}


##########################################################################
# Checking parameters

if($type ne 'm' && $type ne 'd'){
	die "An incorrect transcription factor type has been specified. \n";
}

if($state ne 'a' && $state ne 'i'){
  	die "An incorrect state has been specified. \n";
}

if($sg_flag ne 'y' && $sg_flag ne 'n'){
        die "Use y/n to specify if signals interact with transcription factors. \n";
}

if($state eq 'i' && $sg_flag eq 'n'){
 die "Error: inactive TFs require signals. \n";
}

# Compartment flag
if($comp_flag ne 'n' && $comp_flag ne 'y'){
        die "Compartment presence must be properly specified. You wrote: Compart
ment:  $comp_flag \n";
}


####################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes
my @b_adapters=(); # contains exchanged signal carriers


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 
my %h_b_adapters=(); # associates each "b" adapter to the corresponding species/adapter-flux

if($type eq 'm'){
    # Active monomers
    push(@species,"fm_a");
    push(@storages,"fm_a");

    push(@in_adapters,"faps_a_b");            # b flux, but an in_adapter is required
    $h_in_adapters{"faps_a_b"}="fm_a";

    if($state eq 'a'){				# state of the free, incoming factors
      push(@in_adapters,"faps_a_in");
      $h_in_adapters{"faps_a_in"}="fm_a";	    
      
      if($sg_flag eq 'y'){
        push(@in_adapters,"faps_i_b");          # pseudo b flux, but an in_adapter is required
        $h_in_adapters{"faps_i_b"}="fm_i";	# tf can be inactivate inside a promoter and then come back to the pool
      }		
    }

    if($state eq 'i'){
      push(@in_adapters,"faps_i_in");		# factors are inactive when produced
      $h_in_adapters{"faps_i_in"}="fm_i";
    }    

    if($sg_flag eq 'y'){
      # Inactive monomers
      push(@species,"fm_i");
      push(@storages,"fm_i");
      
      # Signals
      push(@species, "s");
      push(@b_adapters, "s");
      $h_b_adapters{"s"}="sips_b";
    }	
}    
    
if($type eq 'd'){
    # Monomers
    push(@species,"fm");
    push(@storages,"fm");    

    push(@in_adapters,"faps_in");			# free, incoming monomers
    $h_in_adapters{"faps_in"}="fm";
      
    # Active dimers
    push(@species,"fd_a");
    push(@storages,"fd_a");

    push(@in_adapters,"faps_a_b");
    $h_in_adapters{"faps_a_b"}="fd_a";
  
    if($state eq 'a'){
      if($sg_flag eq 'y'){
  	push(@in_adapters,"faps_i_b"); 	
	$h_in_adapters{"faps_i_b"}="fd_i";
      }
    }		

    if($sg_flag eq 'y'){
      # Inactive dimers  
      push(@species,"fd_i");
      push(@storages,"fd_i");
  
      # Signals
      push(@species, "s");
      push(@b_adapters, "s");
      $h_b_adapters{"s"}="sips_b"; 
    }
}	
	
# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
    $h_species{$species[$i]}=$i;
}

# Opening the output file containing all the tfpool information
my $outfile;
$outfile=$tf."_reactions.txt";
open(OUT,">$outfile");

# Writing tfpool species in the output file
print OUT "$tf \n";
print OUT "TF type: $type \n";
print OUT "Free TF state: $state \n";
print OUT "Signals: $sg_flag \n";
print OUT "Initial concentration: $tf_free \n";
print "\n";
print OUT "$tf species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Monomer decay
if($type eq 'd'){
  push(@reactions,"kd_m");  
  $educts{$reactions[$#reactions]}=["fm"]; 
  $products{$reactions[$#reactions]}=[];
  $values{$reactions[$#reactions]}=$k_d;	
}

if($type eq 'm'){
  if($state eq 'a'){ 	
    push(@reactions,"kd_a");
    $educts{$reactions[$#reactions]}=["fm_a"];
    $products{$reactions[$#reactions]}=[];
    $values{$reactions[$#reactions]}=$k_d;

    if($sg_flag eq 'y'){
      push(@reactions,"kd_i");
      $educts{$reactions[$#reactions]}=["fm_i"];
      $products{$reactions[$#reactions]}=["s"];
      $values{$reactions[$#reactions]}=$k_d;      
    }
  }
 
  if($state eq 'i'){
    push(@reactions,"kd_a");
    $educts{$reactions[$#reactions]}=["fm_a"];
    $products{$reactions[$#reactions]}=["s"];
    $values{$reactions[$#reactions]}=$k_d;

    push(@reactions,"kd_i");
    $educts{$reactions[$#reactions]}=["fm_i"];
    $products{$reactions[$#reactions]}=[];
    $values{$reactions[$#reactions]}=$k_d;
  } 
}
  
# Dimer decay
if($type eq 'd'){
  if($state eq 'a'){
    push(@reactions,"kd_a");
    $educts{$reactions[$#reactions]}=["fd_a"];
    $products{$reactions[$#reactions]}=[];
    $values{$reactions[$#reactions]}=$k_d;

    if($sg_flag eq 'y'){
      push(@reactions,"kd_i");
      $educts{$reactions[$#reactions]}=["fd_i"];
      $products{$reactions[$#reactions]}=["s"];
      $values{$reactions[$#reactions]}=$k_d;
    }
  }

  if($state eq 'i'){
    push(@reactions,"kd_a");
    $educts{$reactions[$#reactions]}=["fd_a"];
    $products{$reactions[$#reactions]}=["s"];
    $values{$reactions[$#reactions]}=$k_d;

    push(@reactions,"kd_i");
    $educts{$reactions[$#reactions]}=["fd_i"];
    $products{$reactions[$#reactions]}=[];
    $values{$reactions[$#reactions]}=$k_d;
  }
}

# Chemicals-proteins interaction  
if($sg_flag eq 'y'){
  push(@reactions,"lambda");
    if($type eq 'm'){
      if($state eq 'a'){ 
        $educts{$reactions[$#reactions]}=["fm_a","s"];
        $products{$reactions[$#reactions]}=["fm_i"];
      }else{	
        $educts{$reactions[$#reactions]}=["fm_i","s"];
        $products{$reactions[$#reactions]}=["fm_a"];
     }
    }else{
      if($state eq 'a'){
        $educts{$reactions[$#reactions]}=["fd_a","s"];
        $products{$reactions[$#reactions]}=["fd_i"];
      }else{
        $educts{$reactions[$#reactions]}=["fd_i","s"];
        $products{$reactions[$#reactions]}=["fd_a"];
     }
   }
  $values{$reactions[$#reactions]}=$lambda;

  push(@reactions,"mu");
    if($type eq 'm'){
      if($state eq 'a'){
        $educts{$reactions[$#reactions]}=["fm_i"];
        $products{$reactions[$#reactions]}=["fm_a","s"];
      }else{
        $educts{$reactions[$#reactions]}=["fm_a"];
        $products{$reactions[$#reactions]}=["fm_i","s"];
     }
    }else{
      if($state eq 'a'){
        $educts{$reactions[$#reactions]}=["fd_i"];
        $products{$reactions[$#reactions]}=["fd_a","s"];
      }else{
        $educts{$reactions[$#reactions]}=["fd_a"];
        $products{$reactions[$#reactions]}=["fd_i","s"];
     }
   }
  $values{$reactions[$#reactions]}=$mu;
}

# Dimerization
if($type eq 'd'){
  push(@reactions,"delta");
  if($state eq 'a'){
    $educts{$reactions[$#reactions]}=["fm"];	# *2
    $products{$reactions[$#reactions]}=["fd_a"];
  }else{
    $educts{$reactions[$#reactions]}=["fm"];    # *2
    $products{$reactions[$#reactions]}=["fd_i"];
  }
  $values{$reactions[$#reactions]}=$delta;

  push(@reactions,"epsilon");
  if($state eq 'a'){
    $educts{$reactions[$#reactions]}=["fd_a"];  
    $products{$reactions[$#reactions]}=["fm"]; # *2
  }else{
    $educts{$reactions[$#reactions]}=["fd_i"];
    $products{$reactions[$#reactions]}=["fm"]; # *2
  }
  $values{$reactions[$#reactions]}=$epsilon;
}

# Writing all the reactions on the output file
print OUT "$tf reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print "PINELLO: $key => $flux \n";
 # $flux =~ s/$\.out/ /;  
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}

print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Checking the reactions
for($i=0;$i<scalar(@reactions); $i++){
  print "$reactions[$i] \n";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print "e$j \t $educts{$key}[$j] \n";
  }
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print "p$j \t $products{$key}[$j] \n";
  }
  print "------------------------- \n";
}

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
      $h_reactions{$reactions[$i]}=$i;
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    print "P: $letters[$counter] \n";
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }
}

print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$tf."_pool.mdl";
open (MDL,">$filename");

# Loading the libraries
print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$tf\_pool\"
  :super-classes (\"module\")
  :icon \"Tfpool.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
    print "species: $storages[$i] \n";
    if($type eq 'd'){
        if($storages[$i] eq "fm"){
           $cc=$tf_free;
        }else{
           $cc=0.0;
        }  
   }elsif($type eq 'm'){ 
        if($storages[$i] eq "fm_a"){
           $cc=$tf_free;
        }else{
           $cc=0.0;
        }
   }

print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

if($comp_flag eq 'y'){
        for($i=0;$i<scalar(@reactions);$i++){
		if($reactions[$i] eq "delta"){   # correction for the dimerization
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1*a.c^2\")
";	
		}else{
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1*";
                for($j=0; $j<scalar(@{$educts{$reactions[$i]}}); $j++){
print MDL "$letters[$j].c";
                        if($j+1<scalar(@{$educts{$reactions[$i]}})){
print MDL "*";
                        }else{
print MDL "\")
";
                        }
                }
		}
        }
}


for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"in_tf\"
";
if($type eq 'm' && $state eq 'a'){
print MDL 
"    :is-eq-to \"faps_a_in.in\"
";
}elsif($type eq 'm' && $state eq 'i'){
print MDL
"    :is-eq-to \"faps_i_in.in\"
";
}elsif($type eq 'd'){
print MDL
"    :is-eq-to \"faps_in.in\"
";
}
print MDL
"    :geometry-side \"BOTTOM\"
    :geometry-position \"0.3\")
";

if($sg_flag eq 'y'){
print MDL
"    (\"exc_sg\"
    :is-eq-to \"sips_b.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.7\")
";
}

print MDL 
"   (\"exc_tf_a\"
    :is-eq-to \"faps_a_b.in\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.2\")
";

if($state eq 'a' && $sg_flag eq 'y'){
print MDL
"   (\"exc_tf_i\"
    :is-eq-to \"faps_i_b.in\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.8\")
";
}

print MDL 
"   )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

foreach $key (keys %h_out_adapters){
  print "H_OUT_AD: $key \t $h_out_adapters{$key} \n";
print MDL 
"   (\"$h_out_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
 print "IN_AD: $in_adapters[$i] \n";

print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

#b adapters
foreach $key (keys %h_b_adapters){
  my $apt = $h_b_adapters{$key};
print MDL
"   (\"$h_b_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    if($reactions[$i] eq "delta"){
      $cl="trans2p-fi2a_r";
    }elsif($reactions[$i] eq "epsilon"){
      $cl="trans2b-fi1b_r";
    }	
    $class{$reactions[$i]}=$cl;
#  print "$reactions[$i] \t $cl \n";
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
#      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$storages[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
#	print "pinello \n";
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@out_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_out_adapters{$out_adapters[$i]}.in\""; # always IN terminal
    print "A: $out_adapters[$i] \n";
    foreach $key (keys %h_reactions){ # fictitious reactions
      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){
	print "LAEAK: $key \t $h_in_adapters{$key} \t $out_adapters[$i] \n";
        if($h_in_adapters{$key} eq $h_out_adapters{$out_adapters[$i]}){
print MDL " \"$key.out\"";
        }
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@b_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_b_adapters{$b_adapters[$i]}.out\""; # always OUT terminal
    print "A: $b_adapters[$i] \n";
    foreach $key (keys %h_reactions){ # fictitious reactions
      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$b_adapters[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$b_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$b_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }

print MDL "))
";
    $c_lk++;
}

print MDL
"  ))
";

# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}

