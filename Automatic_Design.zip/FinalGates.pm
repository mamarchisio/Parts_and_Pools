#! /usr/bin/perl
use strict;
our @sol_class;
our $solu;


sub final_gate{
my $name = $_[0];
my $pro;
my $rbs;
my $srna;
my $cod;
my $ter;
my $plk='n';   # pol lk
my $rlk='n';   # rib lk 

my $srna_f=0;

# MIXED SOLUTIONS
if($name eq "or1A_yes1i_f"){
	$pro="pAaor";
	$plk='y';
	$rbs="riandl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "or1A_not1c_f"){
        $pro="pAaor";
        $plk='y';
        $rbs="rcnotl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "or1A_and2ii_f"){
        $pro="pAaor";
        $plk='y';
        $rbs="riiandl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "or1A_nor2cc_f"){
        $pro="pAaor";
        $plk='y';
        $rbs="rccnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nand2RR_yes1i_f"){
        $pro="pRaRanand";
        $plk='y';
        $rbs="riandl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nand2RR_not1c_f"){
        $pro="pRaRanand";
        $plk='y';
        $rbs="rcnotl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nand2RR_and2ii_f"){
        $pro="pRaRanand";
        $plk='y';
        $rbs="riiandl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nand2RR_nor2cc_f"){
        $pro="pRaRanand";
        $plk='y';
        $rbs="rccnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}
########################################

# YES0 gate --> particular case
if($name eq "yes0"){
        $pro="p0";
        $rbs="r0";
        $cod="tf";
        $ter="te";
}

# NOT gates; final layer; 1 input
if($name eq "not1R_f"){
	if($sol_class[$solu] eq "disj OR-NOR" || $sol_class[$solu] eq "single"|| $sol_class[$solu] eq "disj"){ # CORRECTION 23/11/10
		$pro="pRanotfon";
		$plk='y';
	}elsif($sol_class[$solu] eq "disj NOR-(N)AND"){
		$pro="pRanotfna";
		$plk='y';
	}
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

if($name eq "not1l_f"){
	if($sol_class[$solu] eq "disj OR-NOR" || $sol_class[$solu] eq "single" || $sol_class[$solu] eq "disj"){
		$pro="p0fon";
	}elsif($sol_class[$solu] eq "disj NOR-(N)AND"){
		$pro="p0fna";
	}
	$rbs="rlnotf";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "not1R_k"){		# seven clauses; two free RBSs; first subset
	$pro="pRanot_s";
	$plk='y';
	$srna="s0l";
	$ter="tesl";

	$srna_f=1;
}

# NOR gates; (single) final layer; 1 input
if($name eq "nor1R_f"){
	$pro="pRanor";
	$plk='y';
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

if($name eq "nor1l_f"){
	$pro="p0";
	$rbs="rlnot";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor1c_f"){
        $pro="p0";
        $rbs="rcnot";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}


# OR gates; (single) final layer; 1 inputs
if($name eq "or1A_f"){
	$pro="pAaor";
	$plk='y';
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

if($name eq "or1k_f"){
	$pro="p0";
	$rbs="rkyes";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

# OR gates; 2 inputs
if($name eq "or2AA_f"){
        $pro="pAaAaor";
	$plk='y';
        $rbs="r0l";
        $cod="fp";
        $ter="te";
}

if($name eq "or2AA_R"){
	$pro="pAaAaor";
	$plk='y';
	$rbs="r0l";
	$cod="tf";
	$ter="te";
}

if($name eq "or2AA_l"){
	$pro="pAaAaor_s";
	$plk='y';
	$srna="s0l";
	$ter="tesl";

	$srna_f=1;
}

# NAND gate; 2 inputs
if($name eq "nand2RR_f"){
	$pro="pRaRanand";
	$plk='y';
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

# NOR gates; 2 inputs
if($name eq "nor2RR_f"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

if($name eq "nor2RR_A" || $name eq "nor2RR_R"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="r0l";
	$cod="tf";
	$ter="te";
}

if($name eq "nor2RR_k" || $name eq "nor2RR_l"){
	$pro="pRaRanor_s";
	$plk='y';
	$srna="s0l";
	$ter="tesl";

	$srna_f=1;
}

if($name eq "nor2Rl_f"){
	$pro="pRanor";
	$plk='y';
	$rbs="rlnorl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor2Rl_A" || $name eq "nor2Rl_R"){
	$pro="pRanor";
	$plk='y';
	$rbs="rlnorl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "nor2ll_f"){
	$pro="p0";
	$rbs="rllnor";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor2ll_A" || $name eq "nor2ll_R"){
	$pro="p0";
	$rbs="rllnor";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "nor2Rc_f"){
        $pro="pRanor";
        $plk='y';
        $rbs="rcnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nor2lc_f"){
        $pro="p0";
        $plk='n';
        $rbs="rclnor";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nor2cc_f"){
        $pro="p0";
        $plk='n';
        $rbs="rccnor";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

# NOR gates; 3 inputs
if($name eq "nor3RRl_f"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="rlnorl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor3RRl_A" || $name eq "nor3RRl_R"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="rlnorl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "nor3Rll_f"){
	$pro="pRanor";
	$plk='y';
	$rbs="rllnorl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor3Rll_A" || $name eq "nor3Rll_R"){
	$pro="pRanor";
	$plk='y';
	$rbs="rllnorl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "nor3Rcc_f"){
        $pro="pRanor";
        $plk='y';
        $rbs="rccnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

if($name eq "nor3Ricc_f"){
        $pro="pRinor";
        $plk='y';
        $rbs="rccnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}


# NOR gates; 4 inputs.
if($name eq "nor4RRll_f"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="rllnorl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "nor4RRll_A" || $name eq "nor4RRll_R"){
	$pro="pRaRanor";
	$plk='y';
	$rbs="rllnorl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "nor4RiRicc_f"){
        $pro="pRiRinor";
        $plk='y';
        $rbs="rccnorl";
        $rlk='y';
        $cod="fpl";
        $ter="te";
}

# AND gates; 2 inputs
if($name eq "and2AA_f"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="r0l";
	$cod="fp";
	$ter="te";
}

if($name eq "and2AA_A" || $name eq "and2AA_R"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="r0l";
	$cod="tf";
	$ter="te";
}

if($name eq "and2AA_k" || $name eq "and2AA_l"){
	$pro="pAaAaand_s";
	$plk='y';
	$srna="s0l";
	$ter="tesl";

	$srna_f=1;
}

if($name eq "and2Ak_f"){
	$pro="pAaand";
	$plk='y';
	$rbs="rkandl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "and2Ak_A" || $name eq "and2Ak_R"){
	$pro="pAaand";
	$plk='y';
	$rbs="rkandl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "and2kk_f"){
	$pro="p0";
	$rbs="rkkand";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "and2kk_A" || $name eq "and2kk_R"){
	$pro="p0";
	$rbs="rkkand";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

# AND gates; 3 inputs
if($name eq "and3AAk_f"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="rkandl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "and3AAk_A" || $name eq "and3AAk_R"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="rkandl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

if($name eq "and3Akk_f"){
	$pro="pAaand";
	$plk='y';
	$rbs="rkkandl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "and3Akk_A" || $name eq "and3Akk_R"){
	$pro="pAaand";
	$plk='y';
	$rbs="rkkandl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}

# AND gates; 4 inputs.
if($name eq "and4AAkk_f"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="rkkandl";
	$rlk='y';
	$cod="fpl";
	$ter="te";
}

if($name eq "and4AAkk_A" || $name eq "and4AAkk_R"){
	$pro="pAaAaand";
	$plk='y';
	$rbs="rkkandl";
	$rlk='y';
	$cod="tfl";
	$ter="te";
}


gen_prom($pro);
if($srna_f == 0){
   	gen_rbs($rbs,$plk);
        gen_cod($cod,$rlk);
	gen_ter($ter,'n');
}else{
        gen_srna($srna,$plk);
	gen_ter($ter,$plk);
}
#gen_ter($ter,$plk);

if($srna_f == 0){
      	design_long($name,$pro,$rbs,$cod,$ter);
}else{
       	design_short($name,$pro,$srna,$ter);
}


}
1;
		
