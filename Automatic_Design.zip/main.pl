#! /usr/bin/perl
use strict;
use Scheme;
use Karnaugh;
use CalcInput;
use CalcSingle;
use CalcDisjNA;
use CalcDisjON;
use CalcInternal;
use Ranking;
use SingleLiteralsPOS;
use SingleLiteralsSOP;
use Mixed;

my $i;
my $j;
my $k;
my $l;
my $i0;
my $i1;
my $i2;
my $i3;
my $i4;
my $i5;
my $i6;
my $i7;
my $ws;
my $ns;

my $tag;		# total assignments
my %sph;		# signals-parts hash
my @s_deg;		# signal degeneracy - for input layer calculation

my @let=('A','B','C','D');
our @fm_list=();
my @s_list=("POS","SOP");

open(IN,"input.inp");
my @sa=();
my @truth2=();
my @truth3=();
my @truth4=();

################## Reading the input
<IN>;
<IN>;
<IN>;
$ws=<IN>;
chop($ws);
$ws =~ s/(Input|signals|\(2\/4\)|:|\s)//g;
$ns=$ws;
if ($ns < 2 || $ns > 4 ){
	die "Invalid input signal number ($ns). \n";
}

for($i=0;$i<6;$i++){
	<IN>;
}

for($i=0;$i<4;$i++){
	$_=<IN>;
	chop($_);
	@sa=split(/:/,$_);
	if($ns == 2){
		if($sa[1] != 0 && $sa[1] != 1){
			die "Invalid logic value. \n";
		}
	}
	$truth2[$i]=$sa[1];
}


for($i=0;$i<4;$i++){
	<IN>;
}

for($i=0;$i<8;$i++){
	$_=<IN>;
	chop($_);
	@sa=split(/:/,$_);
	if($ns == 3){
		if($sa[1] != 0 && $sa[1] != 1){
			die "Invalid logic value. \n";
		}
	}
	$truth3[$i]=$sa[1];
}

for($i=0;$i<3;$i++){
	<IN>;
}

for($i=0;$i<16;$i++){
	$_=<IN>;
	chop($_);
	@sa=split(/:/,$_);
	if($ns == 4){
		if($sa[1] != 0 && $sa[1] != 1){
			die "Invalid logic value. \n";
		}
	}
	$truth4[$i]=$sa[1];
}
####################### end of reading

# Generating the logic formulas
for($i=0; $i<2; $i++){
	if($ns == 2){
		two_kv(\@truth2,$s_list[$i]);
	}elsif($ns == 3){
		three_kv(\@truth3,$s_list[$i]);
	}elsif($ns == 4){
		four_kv(\@truth4,$s_list[$i]);
	}
}

#------------------------------------------------------
# Vector for layers and solution construction
our @num_in=();		
our @num_cl=();		
our @sol_cl=();
our @sol_num_in=();
our @type_s=();		
our @sol_class=();	
our @input_l=();	
our @reg_fac=();		
our @signals=();

our @gene_n=();		
our @free_rbs=(); 	

our @out_int=();	 
our @int_lay=();	
our @first_f=();	
our @second_f=();	

our @sol_prm=();		
our @sol_rbs=();		

our @score_s=();
our @leak_p=();		
our @lg_cl=();		
our @sign_s=();		
our @sign;
                                     
our @sg=();		
our @nsg=();		
our @asg=();
my @input_c;	
our @final_c;
my @prm;		
my @rbs;		

our @common=();         # array of negated inputs that share a pool
our $common_flag='n';
our @co_sig=();
our @co_sig_cs=();
#--------------------------------------------------

our $sk;
my $fm;
our $s_kind;
our $sl;
my $s_as;
our $ca;
my $cc=0;		# counter-final-configurations
my $cc_t=0;		# temporary counter
my $free=0;		# number of free RBS in a given internal layer configuration
our @i_as=();
our @v_cl=(); 		# vector of clauses
my @mat_cl=();
my $sl_flag;        # single literals flag; becomes 'y' when a signal has to be sent directly to the final gate
my $csl;
$sl=0;                  # Initialization of the solution number
for($sk=0; $sk<2; $sk++){ 
	$s_kind=$s_list[$sk];
	$fm=$fm_list[$sk];
	$sl_flag = 'n';      
	$csl=0;
	
	print "LOOP: $sk \t $s_kind \n";
	### Clause matrix construction
	if($s_kind eq "POS"){
		@v_cl=split(/\*/,$fm_list[$sk]);
	}else{
		@v_cl=split(/\+/,$fm_list[$sk]);
	}
	$num_cl[$sk]=scalar(@v_cl);
	
	for($i=0; $i<$num_cl[$sk]; $i++){
		$v_cl[$i] =~ s/[()]//g;
	}
	
	my @tv=();
	if($s_kind eq "POS"){
		for($i=0; $i<$num_cl[$sk]; $i++){
			@tv=split(/\+/,$v_cl[$i]);
			my @otv=sort @tv; 
			@tv=@otv;
			$lg_cl[$i]=scalar(@tv);
			for($j=0; $j<scalar(@tv); $j++){
				$mat_cl[$i][$j]=$tv[$j];
			}	
		}
	}else{
		for($i=0; $i<$num_cl[$sk]; $i++){
			@tv=split(/\*/,$v_cl[$i]);
			$lg_cl[$i]=scalar(@tv);		
			for($j=0; $j<scalar(@tv); $j++){
				$mat_cl[$i][$j]=$tv[$j];
			}	
		}		
	}		
	
	# Checking clause length
	for($i=0; $i<$num_cl[$sk]; $i++){
	  if($s_kind eq "POS" && $lg_cl[$i] == 1 && $v_cl[$i] =~/[ABCD]/){
	      $sl_flag = 'y';      
	      $csl++;
	  }

	  if($s_kind eq "SOP" && $lg_cl[$i] == 1 && $v_cl[$i] =~/[ABCD]/){
	      $sl_flag = 'y';      
	      $csl++;
	  }

	}

	if($sl_flag eq 'y'){# && $csl <= 2){
	  if($s_kind eq "POS"){
	    single_literals_POS();
	  }else{
	    single_literals_SOP();
	  }
	}
	
	$sl_flag = 'n';

	# checking for mixed solutions
	if($s_kind eq "POS"){
	  if($num_cl[$sk] == 2){
	    my @so_lg=sort {$a <=> $b} @lg_cl;
	    if($so_lg[0] == 1 && $so_lg[1] == 2){
	      my $lit;
	      my $two;
	      for(my $i;$i<$num_cl[$sk];$i++){
		if($lg_cl[$i] == 1){
		  $lit=$v_cl[$i];
		}else{
		  $two=$v_cl[$i];
		}
	      }
	      my @two_sp=split(/\+/,$two);
	      if(($two_sp[0] =~ /[abcd]/ && $two_sp[1] =~ /[abcd]/) || ($two_sp[0] =~ /[ABCD]/ && $two_sp[1] =~ /[ABCD]/)){
		if($two !~ /$lit/){
		  mixed_solution();
		}
	      }
	    }
	  }

	  if($num_cl[$sk] == 3){
	    my @so_lg=sort {$a <=> $b} @lg_cl;
	    if($so_lg[0] == 1 && $so_lg[1] == 1 && $so_lg[2] == 2){
	      my $lit1="";
	      my $lit2="";
	      my $two="";
	      for(my $i;$i<$num_cl[$sk];$i++){
		if($lg_cl[$i] == 1 && $lit1 eq ""){
		  $lit1=$v_cl[$i];
		}elsif($lg_cl[$i] == 1 && $lit1 ne ""){
		  $lit2=$v_cl[$i];
		}elsif($lg_cl[$i] == 2){
		  $two=$v_cl[$i];
		}
	      }
	      my @two_sp=split(/\+/,$two);
	      if(($two_sp[0] =~ /[abcd]/ && $two_sp[1] =~ /[abcd]/) || ($two_sp[0] =~ /[ABCD]/ && $two_sp[1] =~ /[ABCD]/)){
		if(($lit1 =~ /[abcd]/ && $lit2 =~ /[abcd]/) || ($lit1 =~ /[ABCD]/ && $lit2 =~ /[ABCD]/)){
		  if($two !~ /$lit1/ && $two !~ /$lit2/){
		    mixed_solution();	
		  }
		}
	      }
	    }
	  }
	}
   if($sl_flag eq 'n'){ 
	@sg=();
	@nsg=();
	@asg=();
        @num_in=();	
	# Constructing asg - all signals vectors
	if($fm =~/[a]/){
		push(@asg,'a');
	}

	if($fm =~/[b]/){
        	push(@asg,'b');
	}
	
	if($fm =~/[c]/){
        	push(@asg,'c');
	}

	if($fm =~/[d]/){
        	push(@asg,'d');
	}

	if($fm =~/[A]/){
        	push(@asg,'A');
	}

	if($fm =~/[B]/){
        	push(@asg,'B');
	}
	
	if($fm =~/[C]/){
        	push(@asg,'C');
	}

	if($fm =~/[D]/){
        	push(@asg,'D');
	}

	# Counting the number of input signals
	if($fm =~/[aA]/){
        	$num_in[$sk]++;
		push(@sg,'a');
		push(@nsg,'A');
	}

	if($fm =~/[bB]/){
        	$num_in[$sk]++;
		push(@sg,'b');
		push(@nsg,'B');
	}

	if($fm =~/[cC]/){
        	$num_in[$sk]++;
		push(@sg,'c');
		push(@nsg,'C');

	}

	if($fm =~/[dD]/){
        	$num_in[$sk]++;
		push(@sg,'d');
		push(@nsg,'D');
	}


        # Check if the the negated signals are present only once (for POS only)
        if($s_kind eq "POS"){
                my @su_cl=(); # total number of clauses where a negated signal appears
                my @wh_cl=(); # labels of the (last) clause where a negated signal appears
                for($i=0; $i<$num_cl[$sk]; $i++){
                        for($j=0; $j<$lg_cl[$i]; $j++){
                                if($mat_cl[$i][$j] eq 'A'){
                                        $su_cl[0]++;
                                        $wh_cl[0]=$i;
                                }
                                if($mat_cl[$i][$j] eq 'B'){
                                        $su_cl[1]++;
                                        $wh_cl[1]=$i;
                                }
                                if($mat_cl[$i][$j] eq 'C'){
                                        $su_cl[2]++;
                                        $wh_cl[2]=$i;
                                }
                                if($mat_cl[$i][$j] eq 'D'){
                                        $su_cl[3]++;
                                        $wh_cl[3]=$i;
                                }
                        }
                }
		
		my %hle=('a' => 0, 'b' => 1, 'c' => 2, 'd' => 3);	
		my $clau=0;
		@common=();
		my $str;
		my $rstr; # reordered string
		my $co=0;
		my $refe=\@common;
		lj0: for($j=0; $j<4; $j++){
			if($j>0){
				$co=ch_common($let[$j],$refe);
			}
			if($co == 1){
				$co=0;
				next lj0;
			}
			$str="_";
			if($su_cl[$j] == 1){
				$clau=$wh_cl[$j];
				ljj:for(my $jj=$j+1; $jj<4; $jj++){
					if($su_cl[$jj] == 1 && $wh_cl[$jj] == $clau){
                                                if(length($str)<2){             
                                                        $str.=$let[$jj];
                                                }else{
                                                        next ljj;
                                                }                               
					}else{
						next ljj;	
					}
				}
				if($str ne '_'){
					$str.=$let[$j];
                                	$str =~ s/^_//;
					$rstr=reorder($str);
                                	push(@common,$rstr);

				}	
                        }else{
				next lj0;
			}
		}

		if(scalar(@common) > 0){
			$common_flag = 'y';
			for($j=0; $j<scalar(@common); $j++){
				my @tmpa=split(//,$common[$j]);
				for($k=0; $k<scalar(@tmpa); $k++){
					for($i=0; $i<scalar(@sg); $i++){
						if($sg[$i] eq lc($tmpa[$k])){
							$co_sig_cs[$j][$k]=$i;
							$co_sig[$j][$k]=$hle{$sg[$i]};
						}
					}
				}
			}
		}

}

	# SIGN matrix initialization
	for($i=0; $i<$num_in[$sk]; $i++){
		for($j=0; $j<2; $j++){			
			$sign[$i][$j]=0; 
		}
	}

	# SIGN matrix construction
	for($i=0; $i<$num_in[$sk]; $i++){
        	for($j=0; $j<$num_cl[$sk]; $j++){
                	for($k=0; $k<$lg_cl[$j]; $k++){
                        	if($sg[$i] eq $mat_cl[$j][$k]){
                                	$sign[$i][0]++;
                        	}

                        	if($nsg[$i] eq $mat_cl[$j][$k]){
                                	$sign[$i][1]++;
                        	}
                	}
        	}
	}

	# First assignment enumeration
	$ca=0;				# counter-assignment
	if($asg[0] ne ""){
	  for($i0=0; $i0<2; $i0++){
		if($asg[1] ne ""){
			for($i1=0; $i1<2; $i1++){
				if($asg[2] ne ""){
					for($i2=0; $i2<2; $i2++){
						if($asg[3] ne ""){	
							for($i3=0; $i3<2; $i3++){
								if($asg[4] ne ""){
									for($i4=0; $i4<2; $i4++){
										if($asg[5] ne ""){	
											for($i5=0; $i5<2; $i5++){
												if($asg[6] ne ""){
													for($i6=0; $i6<2; $i6++){	
														if($asg[7] ne ""){
															for($i7=0; $i7<2; $i7++){
																$s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6,$i7";	
																f_as($ca,$s_as);
																$ca++;		
															}							
														}else{
														
															$s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6";	
															f_as($ca,$s_as);
															$ca++;
														}	
													}	
												}else{
													$s_as="$i0,$i1,$i2,$i3,$i4,$i5";	
													f_as($ca,$s_as);
													$ca++;
												}
											}
										}else{
											$s_as="$i0,$i1,$i2,$i3,$i4";	
											f_as($ca,$s_as);
											$ca++;
										}	
									}	
								}else{
									$s_as="$i0,$i1,$i2,$i3";	
									f_as($ca,$s_as);
									$ca++;
								}
							}
						}else{
							$s_as="$i0,$i1,$i2";	
							f_as($ca,$s_as);
							$ca++;
						}
					}
				}else{
					$s_as="$i0,$i1";	
					f_as($ca,$s_as);
					$ca++;
				}
			}
		}else{
			$s_as="$i0";	
			f_as($ca,$s_as);
			$ca++;
		}
	  }	
	}

	$tag=2**scalar(@asg);

        # Calculating the input layer degeneracy
        @s_deg=();
        for($i=0; $i<$num_in[$sk]; $i++){
                if($sign[$i][0] == 0){
                        $s_deg[$i] = 2;
                }else{
			$s_deg[$i] = 1;
		}
        }
	
	# Finding the internal layer possible configurations
	my $cit=0;	# counter-internal
	my @deg_il;	# vector containing all the possible input layers associated with a signal

#   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   ta_l:for($i=0; $i<$tag; $i++){
		$prm[$cit]=();
		$rbs[$cit]=();

		#### initialize  $gene_n and  @reg_fac !!!!!!!!!!!!!!!!!!! see above
		# hash: signal--> part. Here signals are distributed to the promoters 	 
		for($j=0; $j<scalar(@asg); $j++){
			if($i_as[$i][$j] == 0){
				$sph{$asg[$j]}='p';
			}else{
				$sph{$asg[$j]}='r';
			}
		}
		
		for($j=0; $j<$num_cl[$sk]; $j++){
			for($k=0; $k<$lg_cl[$j]; $k++){
				if($sph{$mat_cl[$j][$k]} eq 'p'){
					if(length($prm[$cit][$j]) < 2){
						$prm[$cit][$j] .= $mat_cl[$j][$k];
					}else{
						next ta_l;
					}
				}else{
					if(length($rbs[$cit][$j]) < 2){
						$rbs[$cit][$j] .= $mat_cl[$j][$k];
					}else{
						next ta_l;
					}
				}
			}
		}

		# Insert: pool contraction
		if($common_flag eq 'y' && $s_kind eq "POS"){
			for($j=0; $j<$num_cl[$sk]; $j++){
				for($k=0; $k<scalar(@common); $k++){
					if($prm[$cit][$j] eq $common[$k]){
						$prm[$cit][$j] = $let[$co_sig[$k][0]];
						last;
					}
					if($rbs[$cit][$j] eq $common[$k]){
                                                $rbs[$cit][$j] = $let[$co_sig[$k][0]];
						last;
                                        }
     				}		
			}		
		}
		
		if($fm eq "(A+B+C+D)"){
			if($rbs[$cit][0] eq 'CD'){
				$rbs[$cit][0] = "C";
			}
                        if($prm[$cit][0] eq 'CD'){
                                $prm[$cit][0] = "C";
                        }
			
		} 

		$free = count_free($cit,\@rbs);		# Calculating the number of free RBS for the just found internal layer
		
		# Calculating the input layer(s) associated with the current internal layer
		@deg_il=all_inp(\%sph);		# degenerate-input-layers vector
		@input_c=();			# vector containing all the possible (up to 16) input layer configurations
		@input_c=inp_config(\@s_deg,\@deg_il);
		# Calculating the final layers associated with the current internal layer
		$cc_t=final_layer($s_kind,$free);			# start filling up the @final_c vector
		$cc=$cc_t;
		if($num_cl[$sk] > 3){
			if($free < 5){
				$cc_t=final_nor_and($s_kind,$free,$cc); 	# filling up the @final_c vector with the nor-and scheme(s)
				$cc=$cc_t;
			}
		}
		if($num_cl[$sk] > 2){
			if($free < 3){
				$cc_t=final_or_nor($s_kind,$free,$cc);		# filling up the @final_c vector with the or-nor scheme(s)
				$cc=$cc_t;
			}
		}

	      	for($j=0;$j<scalar(@input_c);$j++){
			for($k=0;$k<$cc+1;$k++){
				# Vector initialization
				$type_s[$sl] = $s_kind;
				$out_int[$sl]="";
               			$gene_n[$sl]=0;
	               		$leak_p[$sl]=0;
			        for(my $jj=0;$jj<4;$jj++){
	                       		$reg_fac[$sl][$jj]=0;
               			}
				###
				for($l=0;$l<$num_in[$sk];$l++){		
					$input_l[$sl][$l]=$input_c[$j][$l];
				}
				for(my $l=0;$l<$num_in[$sk];$l++){
				  $signals[$sl][$l]=$sg[$l];
				}

				il_cost($s_kind,$sl);

                       		for($l=0; $l<$num_cl[$sk]; $l++){
                               		$sol_prm[$sl][$l] = $prm[$cit][$l];
                               		$sol_rbs[$sl][$l] = $rbs[$cit][$l];
				}
				$free_rbs[$sl]=$free;
				$sol_num_in[$sl]=$num_in[$sk];
				$sol_cl[$sl]=$num_cl[$sk];
				$sol_class[$sl]=$final_c[$k][0];
				$out_int[$sl]=$final_c[$k][1];		
				#Reordering out_int				
				re_out_int($sl);	
				$first_f[$sl]=$final_c[$k][2];									
				$second_f[$sl]=$final_c[$k][3];
				$gene_n[$sl] += $final_c[$k][4];
				$leak_p[$sl] = $final_c[$k][5];
				$reg_fac[$sl][0] += $final_c[$k][6];
				$reg_fac[$sl][1] += $final_c[$k][7];			
				$reg_fac[$sl][2] += $final_c[$k][8];
				$reg_fac[$sl][3] += $final_c[$k][9];	
				for(my $ii=0; $ii<$num_in[$sk];$ii++){
					for(my $jj=0; $jj<2; $jj++){
						$sign_s[$sl][$ii][$jj] = $sign[$ii][$jj];
					}
				}				
				internal_layer($s_kind,$sl);
				score_sol($sl);
				$sl++;	
			}	
		}
                 				
		$cit++;
	} # end loop $tag
      } # end if sl_flag eq 'n'
} #end loop $sk

printsol($sl);
ranking_sol($sl);

my $loes;
my $ung;

        print "Insert solution number: \n";
        $loes = <STDIN>;
	chop($loes);
        $ung = $loes-1;
        circuit_scheme($ung);

`./put_together.pl`;

#------------------------------------------------


sub printas{
my $ve=$_[0];
my $ca=$_[1];
my $j=0;
	
	for($i=0; $i<$ca; $i++){
			print "$i \t";
		for($j=0; $j<8; $j++){
			print "$i_as[$i][$j] ";
		}
		print "\n";
	}
}
#-----------------------------------------------


sub f_as{
my $ca=$_[0];
my $s_as=$_[1];

my $i;
my $dm;
my @v_as;
@v_as=split(/,/,$s_as);
$dm=scalar(@v_as);
	for($i=0; $i<$dm; $i++){
		$i_as[$ca][$i]=$v_as[$i];
	}
}
#-----------------------------------------------


sub count_free{
my $it=$_[0];
my $rbs=$_[1];
my $free=0;
my $i;

        for($i=0; $i<$num_cl[$sk]; $i++){
                if(${rbs}[$it][$i] eq ""){
                        $free++;
                }
        }
	return($free);
}
#-----------------------------------------------

sub ch_common{
my $le=$_[0];
my @arr=@{$_[1]};
my $i;
my $check=0;

	for($i=0; $i<scalar(@arr); $i++){
		if(@arr[$i] =~ /$le/){
			$check=1;
			last;
		}
	}	
	return($check);
}
#-----------------------------------------------
sub reorder{
my $str=$_[0];
my $rstr="";

	my @sarr=split('',$str);
	my @rarr=sort @sarr;
	print"RARR: @rarr \n";	

	for(my $i=0; $i<scalar(@rarr); $i++){
		$rstr .= $rarr[$i];
	} 
	return($rstr);
}
#-----------------------------------------------
