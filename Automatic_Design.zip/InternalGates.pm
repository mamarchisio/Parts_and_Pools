#! /usr/bin/perl 
use strict;
use PartsMaker;
use DevicesDesigner;

sub internal_not{
my $i = $_[0];		# gate/clause number
my @inout=();
my $pro;	
my $rbs="";
my $srna="";
my $cod="";
my $ter;
my $srna_f=0;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $solu;
my $plk='n';   # pol lk
my $rlk='n';   # rib lk 

	my $gate=$int_lay[$solu][$i];
	@inout=split(/_/,$gate);

	if($sol_prm[$solu][$i] eq ""){	# constructing the not promoter
		$pro="p0";
		$plk='n';
	}elsif($sol_prm[$solu][$i] =~ /[abcd]/){
		$pro="pRinot";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD]/){
		$pro="pRanot";
		$plk='y';
	}

	if($inout[1] =~ /R/ || $inout[1] =~ /S/ || $inout[1] =~ /A/ || $inout[1] =~ /f/){    # an RBS is present
	    if($plk eq 'n'){
		if($sol_rbs[$solu][$i] eq ""){
			$rbs="r0";
			$rlk='n';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd]/){
			$rbs="rcnot";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD]/){
			$rbs="rlnot";
			$rlk='y';
		}
	    }else{
                if($sol_rbs[$solu][$i] eq ""){
                        $rbs="r0l";
                        $rlk='n';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd]/){
                        $rbs="rcnotl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD]/){
                        $rbs="rlnotl";
                        $rlk='y';
                }
	    }

		if($inout[1] =~ /f/){
			if($rlk eq 'n'){
				$cod="fp";
			}else{
				$cod="fpl";
			}
		}elsif($inout[1] =~ /R/ || $inout[1] =~ /A/ || $inout[1] =~ /S/){
			if($rlk eq 'n'){
				$cod="tf";
			}else{
				$cod="tfl";
			}
		}
		
		$ter="te";		
	}


	if($inout[1] =~ /l/ || $inout[1] =~ /o/ || $inout[1] =~ /k/ || $inout[1] =~ /e/){
            if($plk eq 'n'){
		$pro .= "_s";
		$srna="s0";
		$ter="tes";
		$srna_f=1;
	    }else{
                $pro .= "_s";
                $srna="s0l";
                $ter="tesl";
                $srna_f=1;
	    }
	}

	gen_prom($pro);
	if($srna_f == 0){
		gen_rbs($rbs,$plk);
		gen_cod($cod,$rlk);
		gen_ter($ter,'n');
	}else{
		gen_srna($srna,$plk);
		gen_ter($ter,$plk);
	}
#	gen_ter($ter,$plk);

	if($srna_f == 0){
		design_long($gate,$pro,$rbs,$cod,$ter);
	}else{
		design_short($gate,$pro,$srna,$ter);
	}	
		
}
#--------------------------------------------------------------------------


sub internal_nor{
my $i = $_[0];		# gate/clause number
my @inout=();
my $pro;	
my $rbs="";
my $srna="";
my $cod="";
my $ter;
my $srna_f=0;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $solu;
my $plk='n';   # pol lk
my $rlk='n';   # rib lk 

	my $gate=$int_lay[$solu][$i];
	@inout=split(/_/,$gate);

	if($sol_prm[$solu][$i] eq ""){		# constructing the nor promoter
		$pro="p0";
		$plk='n';
	}elsif($sol_prm[$solu][$i] =~ /[abcd]/ && $sol_prm[$solu][$i] !~ /[abcd][abcd]/ && $sol_prm[$solu][$i] !~ /[abcd][ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][abcd]/){
		$pro="pRinor";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_prm[$solu][$i] !~ /[abcd][ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][abcd]/){
		$pro="pRanor";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[abcd][abcd]/){
		$pro="pRiRinor";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[abcd][ABCD]/ || $sol_prm[$solu][$i] =~ /[ABCD][abcd]/){
		$pro="pRiRanor";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD][ABCD]/){
		$pro="pRaRanor";
		$plk='y';
	}


	if($inout[1] =~ /R/ || $inout[1] =~ /S/ || $inout[1] =~ /A/ || $inout[1] =~ /f/){	# an RBS is present
	   if($plk eq 'n'){
		if($sol_rbs[$solu][$i] eq ""){
			$rbs="r0";
			$rlk='n';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/ ){
			$rbs="rcnor";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
			$rbs="rlnor";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd][abcd]/){
			$rbs="rccnor";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd][ABCD]/ || $sol_rbs[$solu][$i] =~ /[ABCD][abcd]/){
			$rbs="rclnor";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD][ABCD]/){
			$rbs="rllnor";
			$rlk='y';
		}
	    }else{
               if($sol_rbs[$solu][$i] eq ""){
                        $rbs="r0l";
                        $rlk='n';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/ ){
                        $rbs="rcnorl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
                        $rbs="rlnorl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd][abcd]/){
                        $rbs="rccnorl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd][ABCD]/ || $sol_rbs[$solu][$i] =~ /[ABCD][abcd]/){
                        $rbs="rclnorl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD][ABCD]/){
                        $rbs="rllnorl";
                        $rlk='y';
                }
	     }
		# cod type determination		
		if($inout[1] =~ /f/){
                        if($rlk eq 'n'){
                                $cod="fp";
                        }else{
                                $cod="fpl";
                        }
		}elsif($inout[1] =~ /R/ || $inout[1] =~ /S/ || $inout[1] =~ /A/){
                        if($rlk eq 'n'){
                                $cod="tf";
                        }else{
                                $cod="tfl";
                        }
		}
		
		$ter="te";		
	}

	if($inout[1] =~ /l/ || $inout[1] =~ /o/  || $inout[1] =~ /k/){	# a sRNA is present
	   if($plk eq 'n'){
                $pro .= "_s";
		$srna="s0";
		$ter="tes";
		$srna_f=1;
	   }else{
	        $pro .= "_s";
                $srna="s0l";
                $ter="tesl";
                $srna_f=1;
	   }
	}


	gen_prom($pro);
	if($srna_f == 0){
		gen_rbs($rbs,$plk);
		gen_cod($cod,$rlk);
		gen_ter($ter,'n');
	}else{
		gen_srna($srna,$plk);
		gen_ter($ter,$plk);
	}
#	gen_ter($ter,$plk);

	if($srna_f == 0){
		design_long($gate,$pro,$rbs,$cod,$ter);
	}else{
		design_short($gate,$pro,$srna,$ter);
	}	
}		
#--------------------------------------------------------------------------


sub internal_yes{
my $i = $_[0];		# gate/clause number
my @inout=();
my $pro;	
my $rbs="";
my $srna="";
my $cod="";
my $ter;
my $srna_f=0;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $solu;
my $plk='n';   # pol lk
my $rlk='n';   # rib lk 

	my $gate=$int_lay[$solu][$i];
	@inout=split(/_/,$gate);

	if($sol_prm[$solu][$i] eq ""){	# constructing the yes promoter
		$pro="p0";
		$plk='n';
	}elsif($sol_prm[$solu][$i] =~ /[abcd]/){
		$pro="pAiyes";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD]/){
		$pro="pAayes";
		$plk='y';
	}

	if($inout[1] =~ /R/ || $inout[1] =~ /S/ || $inout[1] =~ /A/ || $inout[1] =~ /B/ ||$inout[1] =~ /f/){    # an RBS is present
	   if($plk eq 'n'){
		if($sol_rbs[$solu][$i] eq ""){
			$rbs="r0";
			$rlk='n';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd]/ ){
			$rbs="riyes";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD]/){
			$rbs="rkyes";
			$rlk='y';
		}
	   }else{
                if($sol_rbs[$solu][$i] eq ""){
                        $rbs="r0l";
                        $rlk='n';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd]/ ){
                        $rbs="riyesl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD]/){
                        $rbs="rkyesl";
                        $rlk='y';
		}
	    }
		if($inout[1] =~ /f/){
			if($rlk eq 'n'){
                                $cod="fp";
                        }else{
                                $cod="fpl";
                        }
		}elsif($inout[1] =~ /R/ || $inout[1] =~ /A/ || $inout[1] =~ /S/ || $inout[1] =~ /B/){
			if($rlk eq 'n'){
                                $cod="tf";
                        }else{
                                $cod="tfl";
                        }
		}
		$ter="te";		
       }


	if($inout[1] =~ /l/ || $inout[1] =~ /o/ || $inout[1] =~ /k/){
	   if($plk eq 'n'){
                $pro .= "_s";
		$srna="s0";
		$ter="tes";
		$srna_f=1;
	   }else{
                $pro .= "_s";
                $srna="s0l";
                $ter="tesl";
                $srna_f=1;
	   }
	}

	gen_prom($pro);
	if($srna_f == 0){
		gen_rbs($rbs,$plk);
		gen_cod($cod,$rlk);
		gen_ter($ter,'n');
	}else{
		gen_srna($srna,$plk);
		gen_ter($ter,$plk);
	}
#	gen_ter($ter,$plk);

	if($srna_f == 0){
		design_long($gate,$pro,$rbs,$cod,$ter);
	}else{
		design_short($gate,$pro,$srna,$ter);
	}	
		
}
#--------------------------------------------------------------------------


sub internal_and{
my $i = $_[0];		# gate/clause number
my @inout=();
my $pro;	
my $rbs="";
my $srna="";
my $cod="";
my $ter;
my $srna_f=0;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $solu;
my $plk='n';   # pol lk
my $rlk='n';   # rib lk 

	my $gate=$int_lay[$solu][$i];
	@inout=split(/_/,$gate);

	if($sol_prm[$solu][$i] eq ""){		# constructing the and promoter
		$pro="p0";
		$plk='n';
	}elsif($sol_prm[$solu][$i] =~ /[abcd]/ && $sol_prm[$solu][$i] !~ /[abcd][abcd]/ && $sol_prm[$solu][$i] !~ /[abcd][ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][abcd]/){
		$pro="pAiand";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_prm[$solu][$i] !~ /[abcd][ABCD]/ && $sol_prm[$solu][$i] !~ /[ABCD][abcd]/){
		$pro="pAaand";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[abcd][abcd]/){
		$pro="pAiAiand";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[abcd][ABCD]/ || $sol_prm[$solu][$i] =~ /[ABCD][abcd]/){
		$pro="pAiAaand";
		$plk='y';
	}elsif($sol_prm[$solu][$i] =~ /[ABCD][ABCD]/){
		$pro="pAaAaand";
		$plk='y';
	}


	if($inout[1] =~ /R/ || $inout[1] =~ /S/ || $inout[1] =~ /A/ || $inout[1] =~ /B/ || $inout[1] =~ /f/){	# an RBS is present
	   if($plk eq 'n'){
		if($sol_rbs[$solu][$i] eq ""){
			$rbs="r0";
			$rlk='n';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
			$rbs="riand";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
			$rbs="rkand";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd][abcd]/){
			$rbs="riiand";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[abcd][ABCD]/ || $sol_rbs[$solu][$i] =~ /[ABCD][abcd]/){
			$rbs="rikand";
			$rlk='y';
		}elsif($sol_rbs[$solu][$i] =~ /[ABCD][ABCD]/){
			$rbs="rkkand";
			$rlk='y';
		}
	  }else{
               if($sol_rbs[$solu][$i] eq ""){
                        $rbs="r0l";
                        $rlk='n';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][abcd]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
                        $rbs="riandl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][ABCD]/ && $sol_rbs[$solu][$i] !~ /[abcd][ABCD]/ && $sol_rbs[$solu][$i] !~ /[ABCD][abcd]/){
                        $rbs="rkandl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd][abcd]/){
                        $rbs="riiandl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[abcd][ABCD]/ || $sol_rbs[$solu][$i] =~ /[ABCD][abcd]/){
                        $rbs="rikandl";
                        $rlk='y';
                }elsif($sol_rbs[$solu][$i] =~ /[ABCD][ABCD]/){
                        $rbs="rkkandl";
                        $rlk='y';
                }
	  }
		# cod type determination		
		if($inout[1] =~ /f/){
                        if($rlk eq 'n'){
                                $cod="fp";
                        }else{
                                $cod="fpl";
                        }
		}elsif($inout[1] =~ /R/ || $inout[1] =~ /A/ || $inout[1] =~ /S/ || $inout[1] =~ /B/){
                        if($rlk eq 'n'){
                                $cod="tf";
                        }else{
                                $cod="tfl";
                        }
		}
		
		$ter="te";		
	}

	if($inout[1] =~ /l/ || $inout[1] =~ /o/ || $inout[1] =~ /k/){	# a sRNA is present
	  if($plk eq 'n'){
                $pro .= "_s";
		$srna="s0";
		$ter="tes";
		$srna_f=1;
	  }else{
                $pro .= "_s";
                $srna="s0l";
                $ter="tesl";
                $srna_f=1;
          }
	}


	gen_prom($pro);
	if($srna_f == 0){
		gen_rbs($rbs,$plk);
		gen_cod($cod,$rlk);
		gen_ter($ter,'n');
	}else{
		gen_srna($srna,$plk);
		gen_ter($ter,$plk);
	}
#	gen_ter($ter,$plk);

	if($srna_f == 0){
		design_long($gate,$pro,$rbs,$cod,$ter);
	}else{
		design_short($gate,$pro,$srna,$ter);
	}	
}
#--------------------------------------------------------------------------
		
1;
