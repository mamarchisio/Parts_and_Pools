#! /usr/bin/perl 
use strict;
use PrintKmp; 


sub two_kv{
my $truth=$_[0];
my $st=$_[1];

our @fm_list;
my @kmp=();
 
 
# Writing the Karnaugh table
 
$kmp[0][0]=${$truth}[0];
$kmp[0][1]=${$truth}[1];
$kmp[1][0]=${$truth}[2];
$kmp[1][1]=${$truth}[3];
 
my $nr=2;
my $nc=2;
my $i;
my $j;
my $k;
my $cs=0;
my $cd;
my $fm="";
my $sy;
 
if($st eq "POS"){
	$sy=0;
}else{
	$sy=1;
}
 
# Checking for trivial solution
r4_l:for($i=0; $i<$nr; $i++){
	c4_l:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			last r4_l;
		}else{
			$cs++;
		}
	}
}

if($cs == 4){
	$fm .= "1";
        print "$fm \n";
        die "trivial solution found";        
}

####################################### 
# Looking for single literals
# Two $sy in a row
r2_l:for($i=0; $i<$nr; $i++){
	$j=0;
	$cd=0;
	if($kmp[$i][$j] != $sy){
		if($kmp[$i][$j] == 2){
			$cd++;
		}else{
			next r2_l;
		}			
	}
	if($kmp[$i][$j+1] != $sy){
		if($kmp[$i][$j+1] == 2){
			$cd++;
		}else{
			next r2_l;
		}			
	}
	if($cd == 2){
		next r2_l;
	}else{
		if($i == 0){
			if($st eq "POS"){
				$fm .= "*(a)";
			}else{
				$fm .= "+(A)";
			}
		}elsif($i == 1){
			if($st eq "POS"){
				$fm .= "*(A)";
			}else{
				$fm .= "+(a)";
			}
		}
		for($k=0; $k<$nc; $k++){
			$kmp[$i][$k] = 2;
		}
	}
}

####################################### 
# Two $sy in a column
$i=0;
c2_l:for($j=0; $j<$nc; $j++){
	$cd=0;
	if($kmp[$i][$j] != $sy){
		if($kmp[$i][$j] == 2){
			$cd++;
		}else{
			next c2_l;                
		}
	}
	if($kmp[$i+1][$j] != $sy){
		if($kmp[$i+1][$j] == 2){
			$cd++;
		}else{
			next c2_l;      
		}
	}
	if($cd == 2){
		next cb_l;
	}else{
		if($j == 0){
			if($st eq "POS"){
				$fm .= "*(b)";							
			}else{
				$fm .= "+(B)";
			}
	   	}elsif($j == 1){
			if($st eq "POS"){
				$fm .= "*(B)";							
			}else{
				$fm .= "+(b)";
			}
		}
		for($k=0; $k<$nr; $k++){
			$kmp[$k][$j] = 2;
		}
	}
}
 
##################################################

# Looking for two-literal clauses
r1_l:for($i=0;$i<$nr;$i++){
	c1_l:for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == $sy){
			if($i == 0){
				if($st eq "POS"){
                                        $fm .= "*(a";                      
				}else{
					$fm .= "+(A";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(A";
				}else{
					$fm .= "+(a";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+b)";							
				}else{
					$fm .= "*B)";
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+B)";							
				}else{
					$fm .= "*b)";
				}
			}
		}
	}
}

# Reconstructing the initial kmp
for($i=0;$i<$nr;$i++){
	for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == 2){
			$kmp[$i][$j] = $sy;					
		}
	}
}
 
$fm =~ s/^[\*\+]//;

if($fm eq ""){
	$fm="0";
	print "$fm \n";
	die "trivial solution found.";
}
 
print "Formula: $fm \n";
push(@fm_list,$fm);  
}
#--------------------------------------------------------------


sub three_kv{
my $truth=$_[0];
my $st=$_[1];

our @fm_list;
my @kmp=();
 
 
# Writing the Karnaugh table
 
$kmp[0][0]=${$truth}[0];
$kmp[0][1]=${$truth}[1];
$kmp[0][2]=${$truth}[4];
$kmp[0][3]=${$truth}[2];
$kmp[1][0]=${$truth}[3];
$kmp[1][1]=${$truth}[5];
$kmp[1][2]=${$truth}[7];
$kmp[1][3]=${$truth}[6];
 
$kmp[0][4]=$kmp[0][0];	# extension
$kmp[1][4]=$kmp[1][0];	# extension
 
 
my $nr=2;
my $nc=4;
my $i;
my $j;
my $k;
my $cs=0;
my $cd;
my $fm="";
my $sy;
 
if($st eq "POS"){
	$sy=0;
}else{
	$sy=1;
}
 
# Checking for trivial solution
r8_l:for($i=0; $i<$nr; $i++){
	c8_l:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			last r8_l;
		}else{
			$cs++;
		}
	}
}

if($cs == 8){
	$fm .= "1";
        print "$fm \n";
        die "trivial solution found";        
}

####################################### 
# Checking for single literals
# Four $sy in a row
r4a_l:for($i=0; $i<$nr; $i++){
	$cs=0;
	c4a_l:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			next r4a_l;
		}else{
			$cs++;
		}
	      }		
	if($cs == 4){
		if($i == 0){
			if($st eq "POS"){
				$fm .= "*(a)";
			}else{
				$fm .= "+(A)";
			}			
		}else{
			if($st eq "POS"){
				$fm .= "*(A)";
			}else{
				$fm .= "+(a)";
			}
		}
		for($k=0; $k<$nc; $k++){
			$kmp[$i][$k] = 2;
		}		 		
	}
}
 
# Modifying the borders
if($kmp[0][0] == 2){
	$kmp[0][4] = 2;
}
 
if($kmp[1][0] == 2){
	$kmp[1][4] = 2;
}

####################################### 
# Four $sy in a square
# Four possibilities along the 0th row
$i=0;
c4b_l:for($j=0; $j<$nc; $j++){
	$cd=0;
	if($kmp[$i][$j] != $sy){
		if($kmp[$i][$j] == 2){
			$cd++;
		}else{
			next c4b_l;
		}
	}
	if($kmp[$i+1][$j] != $sy){ 
		if($kmp[$i+1][$j] == 2){
			$cd++;
		}else{
			next c4b_l;
		}
	}
	if($kmp[$i][$j+1] != $sy){ 
		if($kmp[$i][$j+1] == 2){
			$cd++;
		}else{
			next c4b_l;
		}
	}
	if($kmp[$i+1][$j+1] != $sy){
		if($kmp[$i+1][$j+1] == 2){
			$cd++;
		}else{
			next c4b_l;
		}
	}
	if($cd == 4){
		next c4b_l;
	}else{
	   if($j == 0){
		if($st eq "POS"){
			$fm .= "*(b)";
		}else{
			$fm .= "+(B)";
		}
		$kmp[0][4] = 2;
		$kmp[1][4] = 2;				
	   }elsif($j == 1){
		if($st eq "POS"){
			$fm .= "*(C)";
		}else{
			$fm .= "+(c)";
	   	}				
	   }elsif($j == 2){
		if($st eq "POS"){
			$fm .= "*(B)";
		}else{
			$fm .= "+(b)";
		}				
	   }elsif($j == 3){
		if($st eq "POS"){
			$fm .= "*(c)";
		}else{
			$fm .= "+(C)";
		}	
		$kmp[0][0] = 2;
		$kmp[1][0] = 2;			
	   }
	   $kmp[$i][$j] = 2;
	   $kmp[$i+1][$j] = 2;	
	   $kmp[$i][$j+1] = 2;
	   $kmp[$i+1][$j+1] = 2;
	}
}

####################################
######-----------------------------

# Looking for two-literal clauses
# Two disjoint $sy in a row
r2_ls:for($i=0; $i<$nr; $i++){
	c2a_ls:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			next c2a_ls;
		}
		if($kmp[$i][$j+1] != $sy){
			next c2a_ls;
		}
			if($i == 0){
				if($st eq "POS"){
					$fm .= "*(a";
				}else{
					$fm .= "+(A";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(A";
				}else{
					$fm .= "+(a";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+b)";							
				}else{
					$fm .= "*B)";
				}
				if($i == 0){	
					$kmp[0][4] = 2;
				}else{
					$kmp[1][4] = 2;
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+C)";							
				}else{
					$fm .= "*c)";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "+B)";							
				}else{
					$fm .= "*b)";
				}
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "+c)";							
				}else{
					$fm .= "*C)";
				}
				if($i == 0){	
					$kmp[0][0] = 2;
				}else{
					$kmp[1][0] = 2;
				}
			}
			$kmp[$i][$j] = 2;
			$kmp[$i][$j+1] = 2;				
	}
}
######----------------------------
# Two disjoint $sy in a column
$i=0;
c2bs_l:for($j=0; $j<$nc; $j++){
	if($kmp[$i][$j] != $sy){
		next c2bs_l;                
	}
	if($kmp[$i+1][$j] != $sy){
		next c2bs_l;      
	}
		if($j == 0){
			if($st eq "POS"){
				$fm .= "*(b+c)";							
			}else{
				$fm .= "+(B*C)";
			}
	   	}elsif($j == 1){
			if($st eq "POS"){
				$fm .= "*(b+C)";							
			}else{
				$fm .= "+(B*c)";
			}
		}elsif($j == 2){
			if($st eq "POS"){
				$fm .= "*(B+C)";							
			}else{
				$fm .= "+(b*c)";
			}
	   	}elsif($j == 3){
			if($st eq "POS"){
				$fm .= "*(B+c)";							
			}else{
				$fm .= "+(b*C)";
			}
		}
		$kmp[$i][$j] = 2;
		$kmp[$i+1][$j] = 2;			
}
 
#####----------------------------

# Looking for two-literal clauses
# Two $sy in a row
r2_l:for($i=0; $i<$nr; $i++){
	c2a_l:for($j=0; $j<$nc; $j++){
		$cd=0;
		if($kmp[$i][$j] != $sy){
			if($kmp[$i][$j] == 2){
				$cd++;
			}else{
				next c2a_l;
			}			
		}
		if($kmp[$i][$j+1] != $sy){
			if($kmp[$i][$j+1] == 2){
				$cd++;
			}else{
				next c2a_l;
			}			
		}
		if($cd == 2){
			next c2a_l;
		}else{
			if($i == 0){
				if($st eq "POS"){
					$fm .= "*(a";
				}else{
					$fm .= "+(A";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(A";
				}else{
					$fm .= "+(a";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+b)";							
				}else{
					$fm .= "*B)";
				}
				if($i == 0){	
					$kmp[0][4] = 2;
				}else{
					$kmp[1][4] = 2;
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+C)";							
				}else{
					$fm .= "*c)";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "+B)";							
				}else{
					$fm .= "*b)";
				}
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "+c)";							
				}else{
					$fm .= "*C)";
				}
				if($i == 0){	
					$kmp[0][0] = 2;
				}else{
					$kmp[1][0] = 2;
				}
			}
			$kmp[$i][$j] = 2;
			$kmp[$i][$j+1] = 2;				
		}	
	}
}

####################################### 
# Two $sy in a column
$i=0;
c2b_l:for($j=0; $j<$nc; $j++){
	$cd=0;
	if($kmp[$i][$j] != $sy){
		if($kmp[$i][$j] == 2){
			$cd++;
		}else{
			next c2b_l;                
		}
	}
	if($kmp[$i+1][$j] != $sy){
		if($kmp[$i+1][$j] == 2){
			$cd++;
		}else{
			next c2b_l;      
		}
	}
	if($cd == 2){
		next c2b_l;
	}else{
		if($j == 0){
			if($st eq "POS"){
				$fm .= "*(b+c)";							
			}else{
				$fm .= "+(B*C)";
			}
	   	}elsif($j == 1){
			if($st eq "POS"){
				$fm .= "*(b+C)";							
			}else{
				$fm .= "+(B*c)";
			}
		}elsif($j == 2){
			if($st eq "POS"){
				$fm .= "*(B+C)";							
			}else{
				$fm .= "+(b*c)";
			}
	   	}elsif($j == 3){
			if($st eq "POS"){
				$fm .= "*(B+c)";							
			}else{
				$fm .= "+(b*C)";
			}
		}
		$kmp[$i][$j] = 2;
		$kmp[$i+1][$j] = 2;			
	}
}
 
##################################################

# Looking for three-literal clauses
r1_l:for($i=0;$i<$nr;$i++){
	c1_l:for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == $sy){
			if($i == 0){
				if($st eq "POS"){
                                        $fm .= "*(a";                      
				}else{
					$fm .= "+(A";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(A";
				}else{
					$fm .= "+(a";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+b+c)";							
				}else{
					$fm .= "*B*C)";
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+b+C)";							
				}else{
					$fm .= "*B*c)";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "+B+C)";							
				}else{
					$fm .= "*b*c)";
				}
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "+B+c)";							
				}else{
					$fm .= "*b*C)";
				}
			}
		}
	}
}

# Reconstructing the initial kmp
for($i=0;$i<$nr;$i++){
	for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == 2){
			$kmp[$i][$j] = $sy;					
		}
	}
}
 
$kmp[0][4]==$kmp[0][0];
$kmp[1][4]==$kmp[1][0];
 
$fm =~ s/^[\*\+]//;

if($fm eq ""){
        $fm="0";
        print "$fm \n";
        die "trivial solution found.";
}

 
print "Formula: $fm \n";
push(@fm_list,$fm);
}
#--------------------------------------------------------------------- 


sub four_kv{ 
my $truth=$_[0];
my $st=$_[1];

our @fm_list;
my @kmp=(); 
 
# Writing the Karnaugh table 
$kmp[0][0]=${$truth}[0];
$kmp[0][1]=${$truth}[1]; 
$kmp[0][2]=${$truth}[5];
$kmp[0][3]=${$truth}[2]; 
$kmp[1][0]=${$truth}[3]; 
$kmp[1][1]=${$truth}[6];
$kmp[1][2]=${$truth}[11];
$kmp[1][3]=${$truth}[8];
$kmp[2][0]=${$truth}[10];
$kmp[2][1]=${$truth}[13];
$kmp[2][2]=${$truth}[15];
$kmp[2][3]=${$truth}[14];
$kmp[3][0]=${$truth}[4];
$kmp[3][1]=${$truth}[7];
$kmp[3][2]=${$truth}[12];
$kmp[3][3]=${$truth}[9];
 
$kmp[0][4]=$kmp[0][0];	# extension
$kmp[1][4]=$kmp[1][0];	# extension
$kmp[2][4]=$kmp[2][0];	# extension
$kmp[3][4]=$kmp[3][0];	# extension
$kmp[4][0]=$kmp[0][0];	# extension
$kmp[4][1]=$kmp[0][1];	# extension
$kmp[4][2]=$kmp[0][2];	# extension
$kmp[4][3]=$kmp[0][3];	# extension
$kmp[4][4]=$kmp[0][0];	# extension

my $nr=4;
my $nc=4;
my $i;
my $j;
my $k;
my $cs=0;		# Symbol counter
my $cd;			# "Due" counter
my $fm="";
my $sy;

#printkm($nr,$nc,\@kmp);
 
if($st eq "POS"){
	$sy=0;
}else{
	$sy=1;
}
 
# Checking for trivial solution
r16_l:for($i=0; $i<$nr; $i++){
	c16_l:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			last r16_l;
		}else{
			$cs++;
		}
	}
}
 
if($cs == 16){
	$fm .= "1";
        print "$fm \n";
        die "trivial solution found";        
}
################################################## 
# Checking for single literals
# Eight signals on two rows
r8_l:for($i=0;$i<$nr;$i++){
	$cs=0;
	$cd=0;
	c8_l:for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] != $sy){
			if($kmp[$i][$j] == 2){
				$cd++;
			}else{
				next r8_l;
			}
		}else{
			$cs++;
		}
		if($kmp[$i+1][$j] != $sy){
			if($kmp[$i+1][$j] == 2){
				$cd++;
			}else{
				next r8_l;
			}
		}else{
			$cs++;
		}
		if($cd == 8){
			next r8_l;
		}
		if($cs + $cd == 8){
			if($i == 0){
				if($st eq "POS"){
					$fm .= "*(a)";
				}else{
					$fm .= "+(A)";
				}
				for($k=0; $k<$nc; $k++){					
					$kmp[4][$k] = 2;
				}
				$kmp[0][4] = 2;
				$kmp[1][4] = 2;
				$kmp[4][4] = 2;			
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(B)";
				}else{
					$fm .= "+(b)";
				}
				$kmp[1][4] = 2;
				$kmp[2][4] = 2;			
			}elsif($i == 2){
				if($st eq "POS"){
					$fm .= "*(A)";
				}else{
					$fm .= "+(a)";
				}
				$kmp[2][4] = 2;
				$kmp[3][4] = 2;
			}elsif($i == 3){
				if($st eq "POS"){
					$fm .= "*(b)";
				}else{
					$fm .= "+(B)";
				}
				for($k=0; $k<$nc; $k++){					
					$kmp[0][$k] = 2;
				}
				$kmp[0][4] = 2;
				$kmp[3][4] = 2;
				$kmp[4][4] = 2;					
			}
			for($k=0; $k<$nc; $k++){
				$kmp[$i][$k] = 2;
				$kmp[$i+1][$k] = 2;
			}
		}	
	}
}

####################################################################
### Eight signals on two columns
c8b_l:for($j=0;$j<$nc;$j++){
	$cs=0;
	$cd=0;
	r8b_l:for($i=0;$i<$nr;$i++){
		if($kmp[$i][$j] != $sy){
			if($kmp[$i][$j] == 2){
				$cd++;
			}else{
				next c8b_l;
			}
		}else{
			$cs++;
		}
		if($kmp[$i][$j+1] != $sy){
			if($kmp[$i][$j+1] == 2){
				$cd++;
			}else{
				next c8b_l;
			}
		}else{
			$cs++;
		}
		if($cd == 8){
			next c8b_l;
		}
		if($cs + $cd == 8){
			if($j == 0){
				if($st eq "POS"){
					$fm .= "*(c)";
				}else{
					$fm .= "+(C)";
				}
				for($k=0; $k<$nr; $k++){					
					$kmp[$k][4] = 2;
				}
				$kmp[4][0] = 2;
				$kmp[4][1] = 2;
				$kmp[4][4] = 2;			
			}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(D)";
				}else{
					$fm .= "+(d)";
				}
				$kmp[4][1] = 2;
				$kmp[4][2] = 2;			
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(C)";
				}else{
					$fm .= "+(c)";
				}
				$kmp[4][2] = 2;
				$kmp[4][3] = 2;
			}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(d)";
				}else{
					$fm .= "+(D)";
				}
				for($k=0; $k<$nc; $k++){					
					$kmp[$k][0] = 2;
				}	
				$kmp[4][0] = 2;
				$kmp[4][3] = 2;
				$kmp[4][4] = 2;					
			}
			for($k=0; $k<$nr; $k++){
				$kmp[$k][$j] = 2;
				$kmp[$k][$j+1] = 2;
			}
		}	
	}
}

################################################################ 

###### Checking for two-literal clauses
#### Four $sy in a row
r4a_l:for($i=0; $i<$nr; $i++){
	$cs=0;
	$cd=0;
	c4a_l:for($j=0; $j<$nc; $j++){
			if($kmp[$i][$j] != $sy){
				if($kmp[$i][$j] == 2){
					$cd++;
				}else{					
					next r4a_l;
				}
			}else{
				$cs++;
			}
			if($cd == 4){
				next r4a_l;
			}
			if($cs + $cd == 4){
			   if($i == 0){
				if($st eq "POS"){
					$fm .= "*(a+b)";
				}else{
					$fm .= "+(A*B)";
				}
				for($k=0;$ k<$nc; $k++){					
					$kmp[4][$k] = 2;
				}
				$kmp[0][4] = 2;
				$kmp[4][4] = 2;				
			   }elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(a+B)";
				}else{
					$fm .= "+(A*b)";
				}
				$kmp[1][4] = 2;
			   }elsif($i == 2){
				if($st eq "POS"){
					$fm .= "*(A+B)";
				}else{
					$fm .= "+(a*b)";
				}
				$kmp[2][4] = 2;
			   }elsif($i == 3){
				if($st eq "POS"){
					$fm .= "*(A+b)";
				}else{
					$fm .= "+(a*B)";
				}
				$kmp[3][4] = 2;
			   }
			   for($k=0; $k<$nc; $k++){
				$kmp[$i][$k] = 2;
			   }		 
			}		
	}
}

############################################# 
#### Four $sy in a column
c4b_l:for($j=0; $j<$nc; $j++){
	$cs=0;
	$cd=0;
	r4b_l:for($i=0; $i<$nr; $i++){
			if($kmp[$i][$j] != $sy){
				if($kmp[$i][$j] == 2){
					$cd++;
				}else{					
					next c4b_l;
				}
			}else{	
				$cs++;
			}
			if($cd == 4){
				next c4b_l;
			}
			if($cs + $cd == 4){
				if($j == 0){
					if($st eq "POS"){
						$fm .= "*(c+d)";
					}else{
						$fm .= "+(C*D)";
					}
					for($k=0; $k<$nr; $k++){
						$kmp[$k][4] = 2;
					}					
					$kmp[4][0] = 2;
					$kmp[4][4] = 2;			
				}elsif($j == 1){
					if($st eq "POS"){
						$fm .= "*(c+D)";
					}else{
						$fm .= "+(C*D)";
					}
					$kmp[4][1] = 2;
				}elsif($j == 2){
					if($st eq "POS"){
						$fm .= "*(C+D)";
					}else{
						$fm .= "+(c*d)";
					}
					$kmp[4][2] = 2;
				}elsif($j == 3){
					if($st eq "POS"){
						$fm .= "*(C+d)";
					}else{
						$fm .= "+(c*D)";
					}
					$kmp[4][3] = 2;
				}
				for($k=0; $k<$nr; $k++){
					$kmp[$k][$j] = 2;
				}		 		
			}
	}
}

#####################################################################
# Four $sy in a square
# Four possibilities along each row
r4c_l:for($i=0; $i<$nr; $i++){
  c4c_l:for($j=0; $j<$nc; $j++){
	$cd=0;
	if($kmp[$i][$j] != $sy){
		if($kmp[$i][$j] == 2){
			$cd++;
		}else{
			next c4c_l;
		}
	}
	if($kmp[$i+1][$j] != $sy){ 
		if($kmp[$i+1][$j] == 2){
			$cd++;
		}else{
			next c4c_l;
		}
	}
	if($kmp[$i][$j+1] != $sy){ 
		if($kmp[$i][$j+1] == 2){
			$cd++;
		}else{
			next c4c_l;
		}
	}
	if($kmp[$i+1][$j+1] != $sy){
		if($kmp[$i+1][$j+1] == 2){
			$cd++;
		}else{
			next c4c_l;
		}
	}
	if($cd == 4){
		next c4c_l;
	}else{
		if($i == 0){	   	
	   		if($j == 0){
				if($st eq "POS"){
					$fm .= "*(a+c)";
				}else{
					$fm .= "+(A*C)";
				}
				$kmp[0][4] = 2;
				$kmp[1][4] = 2;				
				$kmp[4][0] = 2;
				$kmp[4][1] = 2;
				$kmp[4][4] = 2;
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(a+D)";
				}else{
					$fm .= "+(A*d)";
	   			}				
	   		}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(a+C)";
				}else{
					$fm .= "+(A*c)";
				}				
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(a+d)";
				}else{
					$fm .= "+(A*D)";
				}
				$kmp[0][0] = 2;
				$kmp[4][4] = 2;
				$kmp[1][0] = 2;
			}				
	     }elsif($i == 1){
	   		if($j == 0){
				if($st eq "POS"){
					$fm .= "*(B+c)";
				}else{
					$fm .= "+(b*C)";
				}
				$kmp[1][4] = 2;
				$kmp[2][4] = 2;
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(B+D)";
				}else{
					$fm .= "+(b*d)";
	   			}				
	   		}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(B+C)";
				}else{
					$fm .= "+(b*c)";
				}				
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(B+d)";
				}else{
					$fm .= "+(b*D)";
				}
				$kmp[1][0] = 2;
				$kmp[2][0] = 2;
			}				
	     }elsif($i == 2){
	   		if($j == 0){
				if($st eq "POS"){
					$fm .= "*(A+c)";
				}else{
					$fm .= "+(a*C)";
				}
				$kmp[2][4] = 2;
				$kmp[3][4] = 2;
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(A+D)";
				}else{
					$fm .= "+(a*d)";
	   			}				
	   		}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(A+C)";
				}else{
					$fm .= "+(a*c)";
				}				
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(A+d)";
				}else{
					$fm .= "+(a*D)";
				}
				$kmp[1][0] = 2;
				$kmp[2][0] = 2;
			}
	     }elsif($i == 3){
	   		if($j == 0){
				if($st eq "POS"){
					$fm .= "*(b+c)";
				}else{
					$fm .= "+(B*C)";
				}
				$kmp[0][0] = 2;
				$kmp[0][1] = 2;
				$kmp[3][4] = 2;
				$kmp[4][4] = 2;
				$kmp[0][4] = 2;
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(b+D)";
				}else{
					$fm .= "+(B*d)";
	   			}
				$kmp[0][1] = 2;
				$kmp[0][2] = 2;				
	   		}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(b+C)";
				}else{
					$fm .= "+(B*c)";
				}
				$kmp[0][2] = 2;
				$kmp[0][3] = 2;				
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(b+d)";
				}else{
					$fm .= "+(B*D)";
				}
				$kmp[3][0] = 2;
				$kmp[4][0] = 2;
				$kmp[0][3] = 2;
				$kmp[0][4] = 2;
				$kmp[0][0] = 2;
			}
	     }		       
	   $kmp[$i][$j] = 2;
	   $kmp[$i+1][$j] = 2;	
	   $kmp[$i][$j+1] = 2;
	   $kmp[$i+1][$j+1] = 2;
	}	            
  }
}

###################################################### 
# Looking for three-literal clauses
# Isolated pairs
###-----------------------------------------------

# Two disjuncted $sy in a row
r2_ls:for($i=0; $i<$nr; $i++){
	c2_ls:for($j=0; $j<$nc; $j++){
		if($kmp[$i][$j] != $sy){
			next c2_ls
		}
		if($kmp[$i][$j+1] != $sy){
			next c2_ls;
		}

		if($i == 0){
			if($st eq "POS"){
				$fm .= "*(a+b";
			}else{
				$fm .= "+(A*B";
			}
		}elsif($i == 1){
			if($st eq "POS"){
				$fm .= "*(a+B";
			}else{
				$fm .= "+(A*b";
			}
		}elsif($i == 2){
			if($st eq "POS"){
				$fm .= "*(A+B";
			}else{
				$fm .= "+(a*b";
			}
		}elsif($i == 3){
			if($st eq "POS"){
				$fm .= "*(A+b";
			}else{
				$fm .= "+(a*B";
			}
		}
		if($j == 0){
			if($st eq "POS"){
				$fm .= "+c)";							
			}else{
				$fm .= "*C)";
			}
			if($i == 0){
				$kmp[0][4] = 2;
				$kmp[4][0] = 2;
				$kmp[4][1] = 2;
				$kmp[4][4] = 2;	
			}elsif($i == 1){
				$kmp[1][4] = 2;	
			}elsif($i == 2){
				$kmp[2][4] = 2;	
			}elsif($i == 3){
				$kmp[3][4] = 2;	
			}
	   	}elsif($j == 1){
			if($st eq "POS"){
				$fm .= "+D)";							
			}else{
				$fm .= "*d)";
			}
			if($i == 0){
				$kmp[4][1] = 2;
				$kmp[4][2] = 2;
			}
		}elsif($j == 2){
			if($st eq "POS"){
				$fm .= "+C)";							
			}else{
				$fm .= "*c)";
			}
                        if($i == 0){
                        	$kmp[4][2] = 2;
                              	$kmp[4][3] = 2;
                      	}
	   	}elsif($j == 3){
			if($st eq "POS"){
				$fm .= "+d)";							
			}else{
				$fm .= "*D)";
			}
			if($i == 0){
				$kmp[0][0] = 2;
				$kmp[4][0] = 2;
				$kmp[4][3] = 2;
				$kmp[4][4] = 2;	
			}elsif($i == 1){
				$kmp[1][0] = 2;	
			}elsif($i == 2){
				$kmp[2][0] = 2;	
			}elsif($i == 3){
				$kmp[3][0] = 2;	
			}
		}
		$kmp[$i][$j] = 2;
		$kmp[$i][$j+1] = 2;	
	}
}
###----------------------------------------------

# Two disjuncted $sy in a column
c2b_ls:for($j=0; $j<$nc; $j++){
	r2b_ls:for($i=0; $i<$nc; $i++){
		if($kmp[$i][$j] != $sy){
			next r2b_ls;
		}
		if($kmp[$i+1][$j] != $sy){
			next r2b_ls;
		}			
	
			if($j == 0){
				if($st eq "POS"){
					$fm .= "*(c+d";
				}else{
					$fm .= "+(C*D";
				}
			}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(c+D";
				}else{
					$fm .= "+(C*d";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(C+D";
				}else{
					$fm .= "+(c*d";
				}
			}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(C+d";
				}else{
					$fm .= "+(c*D";
				}
			}

			if($i == 0){
				if($st eq "POS"){
					$fm .= "+a)";							
				}else{
					$fm .= "*A)";
				}
				if($j == 0){
					$kmp[0][4] = 2;
					$kmp[1][4] = 2;
					$kmp[4][0] = 2;
					$kmp[4][4] = 2;		
				}elsif($j == 1){
					$kmp[4][1] = 2;
				}elsif($j == 2){
					$kmp[4][2] = 2;
				}elsif($j == 3){
					$kmp[4][3] = 2;
				}
	   		}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "+B)";							
				}else{
					$fm .= "*b)";
				}
				if($j == 0){
					$kmp[1][4] = 2;
					$kmp[2][4] = 2;		
				}				
			}elsif($i == 2){
				if($st eq "POS"){
					$fm .= "+A)";							
				}else{
					$fm .= "*a)";
				}
				if($j == 0){
					$kmp[2][4] = 2;
					$kmp[3][4] = 2;		
				}				
	   		}elsif($i == 3){
				if($st eq "POS"){
					$fm .= "+b)";							
				}else{
					$fm .= "*B)";
				}
				if($j == 0){
					$kmp[3][4] = 2;
					$kmp[4][4] = 2;
					$kmp[0][0] = 2;
					$kmp[0][4] = 2;	
				}elsif($j == 1){
					$kmp[0][1] = 2;	
				}elsif($j == 2){
					$kmp[0][2] = 2;	
				}elsif($j == 3){
					$kmp[0][3] = 2;	
				}
			}
			$kmp[$i][$j] = 2;
			$kmp[$i+1][$j] = 2;				
	}
}

###----------------------------------------------

# Two $sy in a row
r2_l:for($i=0; $i<$nr; $i++){
	c2_l:for($j=0; $j<$nc; $j++){
		$cd=0;
		if($kmp[$i][$j] != $sy){
			if($kmp[$i][$j] == 2){
				$cd++;
			}else{
				next c2_l;
			}			
		}
		if($kmp[$i][$j+1] != $sy){
			if($kmp[$i][$j+1] == 2){
				$cd++;
			}else{
				next c2_l;
			}			
		}
		if($cd == 2){
			next c2_l;
		}else{
			if($i == 0){
				if($st eq "POS"){
					$fm .= "*(a+b";
				}else{
					$fm .= "+(A*B";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(a+B";
				}else{
					$fm .= "+(A*b";
				}
			}elsif($i == 2){
				if($st eq "POS"){
					$fm .= "*(A+B";
				}else{
					$fm .= "+(a*b";
				}
			}elsif($i == 3){
				if($st eq "POS"){
					$fm .= "*(A+b";
				}else{
					$fm .= "+(a*B";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+c)";							
				}else{
					$fm .= "*C)";
				}
				if($i == 0){
					$kmp[0][4] = 2;
					$kmp[4][0] = 2;
					$kmp[4][1] = 2;
					$kmp[4][4] = 2;	
				}elsif($i == 1){
					$kmp[1][4] = 2;	
				}elsif($i == 2){
					$kmp[2][4] = 2;	
				}elsif($i == 3){
					$kmp[3][4] = 2;	
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+D)";							
				}else{
					$fm .= "*d)";
				}
				if($i == 0){
					$kmp[4][1] = 2;
					$kmp[4][2] = 2;
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "+C)";							
				}else{
					$fm .= "*c)";
				}
                                if($i == 0){
                                        $kmp[4][2] = 2;
                                        $kmp[4][3] = 2;
                                }
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "+d)";							
				}else{
					$fm .= "*D)";
				}
				if($i == 0){
					$kmp[0][0] = 2;
					$kmp[4][0] = 2;
					$kmp[4][3] = 2;
					$kmp[4][4] = 2;	
				}elsif($i == 1){
					$kmp[1][0] = 2;	
				}elsif($i == 2){
					$kmp[2][0] = 2;	
				}elsif($i == 3){
					$kmp[3][0] = 2;	
				}
			}
			$kmp[$i][$j] = 2;
			$kmp[$i][$j+1] = 2;				
		}	
	}
}
############################################
# Two $sy in a column
c2b_l:for($j=0; $j<$nc; $j++){
	r2b_l:for($i=0; $i<$nc; $i++){
		$cd=0;
		if($kmp[$i][$j] != $sy){
			if($kmp[$i][$j] == 2){
				$cd++;
			}else{
				next r2b_l;
			}			
		}
		if($kmp[$i+1][$j] != $sy){
			if($kmp[$i+1][$j] == 2){
				$cd++;
			}else{
				next r2b_l;
			}			
		}
		if($cd == 2){
			next r2b_l;
		}else{
			if($j == 0){
				if($st eq "POS"){
					$fm .= "*(c+d";
				}else{
					$fm .= "+(C*D";
				}
			}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "*(c+D";
				}else{
					$fm .= "+(C*d";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "*(C+D";
				}else{
					$fm .= "+(c*d";
				}
			}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "*(C+d";
				}else{
					$fm .= "+(c*D";
				}
			}

			if($i == 0){
				if($st eq "POS"){
					$fm .= "+a)";							
				}else{
					$fm .= "*A)";
				}
				if($j == 0){
					$kmp[0][4] = 2;
					$kmp[1][4] = 2;
					$kmp[4][0] = 2;
					$kmp[4][4] = 2;		
				}elsif($j == 1){
					$kmp[4][1] = 2;
				}elsif($j == 2){
					$kmp[4][2] = 2;
				}elsif($j == 3){
					$kmp[4][3] = 2;
				}
	   		}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "+B)";							
				}else{
					$fm .= "*b)";
				}
				if($j == 0){
					$kmp[1][4] = 2;
					$kmp[2][4] = 2;		
				}				
			}elsif($i == 2){
				if($st eq "POS"){
					$fm .= "+A)";							
				}else{
					$fm .= "*a)";
				}
				if($j == 0){
					$kmp[2][4] = 2;
					$kmp[3][4] = 2;		
				}				
	   		}elsif($i == 3){
				if($st eq "POS"){
					$fm .= "+b)";							
				}else{
					$fm .= "*B)";
				}
				if($j == 0){
					$kmp[3][4] = 2;
					$kmp[4][4] = 2;
					$kmp[0][0] = 2;
					$kmp[0][4] = 2;	
				}elsif($j == 1){
					$kmp[0][1] = 2;	
				}elsif($j == 2){
					$kmp[0][2] = 2;	
				}elsif($j == 3){
					$kmp[0][3] = 2;	
				}
			}
			$kmp[$i][$j] = 2;
			$kmp[$i+1][$j] = 2;				
		}	
	}
}

################################################################ 
# Looking for four-literal clauses
r1_l:for($i=0;$i<$nr;$i++){
	c1_l:for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == $sy){
			if($i == 0){
				if($st eq "POS"){
                              $fm .= "*(a+b";                      
				}else{
					$fm .= "+(A*B";
				}
			}elsif($i == 1){
				if($st eq "POS"){
					$fm .= "*(a+B";
				}else{
					$fm .= "+(A*b";
				}
			}elsif($i == 2){
				if($st eq "POS"){
					$fm .= "*(A+B";
				}else{
					$fm .= "+(a*b";
				}
			}elsif($i == 3){
				if($st eq "POS"){
					$fm .= "*(A+b";
				}else{
					$fm .= "+(a*B";
				}
			}
			if($j == 0){
				if($st eq "POS"){
					$fm .= "+c+d)";							
				}else{
					$fm .= "*C*D)";
				}
	   		}elsif($j == 1){
				if($st eq "POS"){
					$fm .= "+c+D)";							
				}else{
					$fm .= "*C*d)";
				}
			}elsif($j == 2){
				if($st eq "POS"){
					$fm .= "+C+D)";							
				}else{
					$fm .= "*c*d)";
				}
	   		}elsif($j == 3){
				if($st eq "POS"){
					$fm .= "+C+d)";							
				}else{
					$fm .= "*c*D)";
				}
			}
		}
	}
}

##########################################
# Reconstructing the initial kmp
for($i=0;$i<$nr;$i++){
	for($j=0;$j<$nc;$j++){
		if($kmp[$i][$j] == 2){
			$kmp[$i][$j] = $sy;					
		}
	}
}
 
$kmp[0][4]=$kmp[0][0];	# extension
$kmp[1][4]=$kmp[1][0];	# extension
$kmp[2][4]=$kmp[2][0];	# extension
$kmp[3][4]=$kmp[3][0];	# extension
$kmp[4][0]=$kmp[0][0];	# extension
$kmp[4][1]=$kmp[0][1];	# extension
$kmp[4][2]=$kmp[0][2];	# extension
$kmp[4][3]=$kmp[0][3];	# extension
$kmp[4][4]=$kmp[0][0];	# extension
 
$fm =~ s/^[\*\+]//;
if($fm eq ""){
        $fm="0";
        print "$fm \n";
        die "trivial solution found.";
}


print "Formula: $fm \n";
push(@fm_list,$fm);
}
#------------------------------------------ 


1;
