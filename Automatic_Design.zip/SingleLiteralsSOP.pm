#! /usr/bin/perl
use strict;
use CalcInput_slSOP;
use CalcSingle_slSOP;
use CalcInternal_slSOP;

our $sl;                # solution number
our $sk;                # solution kind (POS or SOP)
our $s_kind;
our @fm_list=();        # Boolean formulae
our @lg_cl=();		# Clauses' length
our @num_cl=();		# Clauses' number
our @v_cl=(); 		# vector of clauses
our @num_in=();         # input number 
our @sg=();		# positive signals
our @nsg=();		# negated signals
our @sign;              # sign matrix
our $ca;                # counter assignment
our @type_s=();
our @out_int=();
our @gene_n=();
our @leak_p=();
our @reg_fac=();
our @input_l=();
our @sol_cl=();
our @sol_num_in=();
our @sol_class=();	
our @free_rbs=(); 	
our @int_lay=();	
our @first_f=();	
our @second_f=();	
our @sol_prm=();		
our @sol_rbs=();		
our @score_s=();
our @sign_s=();
our @final_c;
our @signals;

our @sg_plus=();        # positive single literals 
our @sg_min=();         # negative single literals
our @asg=();            # other signals
our @i_as=();           # integer assignment 
our @rbs;
our $fm_plus;
our $fm_min;
our @sg_to_final=();

sub single_literals_SOP{
my $fm=$fm_list[$sk];   # current formula
my $i0;
my $i1;
my $i2;
my $i3;
my $i4;
my $i5;
my $i6;
my $i7;
my $s_as;               # string (partial) assignment   
my $tag;		# total assignments
my @s_deg;		# signal degeneracy - for input layer calculation
my @prm;		# 
my @input_c;
my @deg_il;	        # vector containing all the possible input layers associated with a signal
my %sph;		# signals-parts hash
my $cc=0;		# counter-final-configurations
my $cc_t=0;		# temporary counter
my $free=0;		# number of free RBS in a given internal layer configuration

# this is a particular case when the SOP formula contains a single literal: in most cases an internal YES gate can be avoided and the input gate output (Aa) can be sent directly to the final gate

# Filling up the sg_to_final vector
for(my $i=0;$i<$num_cl[$sk]; $i++){
  if($lg_cl[$i] == 1 && $v_cl[$i] =~ /[abcd]/){
    push(@sg_plus,$v_cl[$i]);
    $fm_plus .=$v_cl[$i].'-';
  }
  if($lg_cl[$i] == 1 && $v_cl[$i] =~ /[ABCD]/){
    push(@sg_min,$v_cl[$i]);
    $fm_min .=$v_cl[$i].'-';
  }
}
@sg_to_final=@sg_min;

@sg=();
@nsg=();
@asg=();
# Constructing asg 
if($fm =~/[a]/){
  push(@asg,'a');
}

if($fm =~/[b]/){
  push(@asg,'b');
}

if($fm =~/[c]/){
  push(@asg,'c');
}

if($fm =~/[d]/){
  push(@asg,'d');
}

if($fm =~/[A]/){
  push(@asg,'A');
}

if($fm =~/[B]/){
  push(@asg,'B');
}

if($fm =~/[C]/){
  push(@asg,'C');
}

if($fm =~/[D]/){
  push(@asg,'D');
}

print @asg, "\n";
# Counting the number of input signals - signals to the final gate are also considered here
if($fm =~/[aA]/){
  $num_in[$sk]++;
  push(@sg,'a');
  push(@nsg,'A');
}

if($fm =~/[bB]/){
  $num_in[$sk]++;
  push(@sg,'b');
  push(@nsg,'B');
}

if($fm =~/[cC]/){
  $num_in[$sk]++;
  push(@sg,'c');
  push(@nsg,'C');
  
}

if($fm =~/[dD]/){
  $num_in[$sk]++;
  push(@sg,'d');
  push(@nsg,'D');
}

# SIGN matrix initialization
for(my $i=0; $i<$num_in[$sk]; $i++){
  for(my $j=0; $j<2; $j++){			
    $sign[$i][$j]=0; 
  }
}

# SIGN matrix construction
for(my $i=0; $i<$num_in[$sk]; $i++){
  for(my $j=0; $j<$num_in[$sk]; $j++){
      if($v_cl[$j] =~ /$sg[$i]/){
	$sign[$i][0]++;
      }
      
      if($v_cl[$j] =~ /$nsg[$i]/){
	$sign[$i][1]++;
      }
    }
}

for(my $i=0; $i<$num_in[$sk]; $i++){         # negated sigle literal have now degeneracy 1
  for(my $j=0; $j<scalar(@sg_min); $j++){
    if($sg_min[$j] =~ /$nsg[$i]/){
      $sign[$i][0]++;
    }
  }
}

# Assignment enumeration
$ca=0;				# counter-assignment

if($asg[0] ne ""){
  for($i0=0; $i0<2; $i0++){
    if($asg[1] ne ""){
      for($i1=0; $i1<2; $i1++){
	if($asg[2] ne ""){
	  for($i2=0; $i2<2; $i2++){
	    if($asg[3] ne ""){	
	      for($i3=0; $i3<2; $i3++){
		if($asg[4] ne ""){
		  for($i4=0; $i4<2; $i4++){
		    if($asg[5] ne ""){	
		      for($i5=0; $i5<2; $i5++){
			if($asg[6] ne ""){
			  for($i6=0; $i6<2; $i6++){	
			    if($asg[7] ne ""){
			      for($i7=0; $i7<2; $i7++){
				$s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6,$i7";	
				f_as_sop($ca,$s_as);
				$ca++;		
			      }							
			    }else{			      
			      $s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6";	
			      f_as_sop($ca,$s_as);
			      $ca++;
			    }	
			  }	
			}else{
			  $s_as="$i0,$i1,$i2,$i3,$i4,$i5";	
			  f_as_sop($ca,$s_as);
			  $ca++;
			}
		      }
		    }else{
		      $s_as="$i0,$i1,$i2,$i3,$i4";	
		      f_as_sop($ca,$s_as);
		      $ca++;
		    }	
		  }	
		}else{
		  $s_as="$i0,$i1,$i2,$i3";	
		  f_as_sop($ca,$s_as);
		  $ca++;
		}
	      }
	    }else{
	      $s_as="$i0,$i1,$i2";	
	      f_as_sop($ca,$s_as);
	      $ca++;
	    }
	  }
	}else{
	  $s_as="$i0,$i1";	
	  f_as_sop($ca,$s_as);
	  $ca++;
	}
      }
    }else{
      $s_as="$i0";	
      f_as_sop($ca,$s_as);
      $ca++;
    }
  }	
}

printas_sop(\@i_as,$ca);

$tag=2**scalar(@asg);

# Calculating the input layer degeneracy
@s_deg=();
for(my $i=0; $i<$num_in[$sk]; $i++){
  if($sign[$i][0] == 0){
    $s_deg[$i] = 2;
  }else{
    $s_deg[$i] = 1;
  }
}
	
### Clause matrix construction (@mat)
my @mat=();
my @tv=();

for(my $i=0; $i<$num_in[$sk]; $i++){
    @tv=split(/\*/,$v_cl[$i]);
    for(my $j=0; $j<$lg_cl[$i]; $j++){
      $mat[$i][$j]=$tv[$j];
    }	
}

my $cit=0;	# counter-internal

# tag loop
ta_l:for(my $i=0; $i<$tag; $i++){   
  $prm[$cit]=();
  $rbs[$cit]=();

#  hash: signal--> part
  my $dim=scalar(@asg);

# Removing wrong assignments for single literals
  for(my $j=0; $j<$dim; $j++){
    if($i_as[$i][$j] == 0 && $fm_plus =~/$asg[$j]/){ # no positive literals on the promoter
      next ta_l;
    }
    if($i_as[$i][$j] == 1 && $fm_min =~/$asg[$j]/){  # no negative literals on the RBS
      next ta_l;
    }
  }
  for(my $j=0; $j<$dim; $j++){
    if($i_as[$i][$j] == 0){
      $sph{$asg[$j]}='p';
    }else{
      $sph{$asg[$j]}='r';
    }
  }
  
  for(my $j=0; $j<$num_in[$sk]; $j++){
    for(my $k=0; $k<$lg_cl[$j]; $k++){
     if($sph{$mat[$j][$k]} eq 'p'){
	if(length($prm[$cit][$j]) < 2){
	  $prm[$cit][$j] .= $mat[$j][$k];
	}else{
	  next ta_l;
	}
      }else{
	if(length($rbs[$cit][$j]) < 2){
	  $rbs[$cit][$j] .= $mat[$j][$k];
	}else{
	  next ta_l;
	}
      }
    }
  }
 
  $free = count_free_sop($cit,\@rbs);		# Calculating the number of free RBS for the just found internal layer
		
  # Calculating the input layer(s) associated with the current internal layer
  @deg_il=all_inp_slSOP(\%sph);	 	        # degenerate-input-layers vector
  for(my $i=0;$i<$num_in[$sk];$i++){
    for(my $j=0; $j<4; $j++){
    }
  }

  @input_c=();			                # vector containing all the possible (up to 16) input layer configurations
  @input_c=inp_config_slSOP(\@s_deg,\@deg_il);

  # Calculating the final layers associated with the current internal layer
  $cc_t=final_layer_slSOP($free);		# start filling up the @final_c vector 
  $cc=$cc_t;

  for(my $j=0;$j<scalar(@input_c);$j++){
    for(my $k=0;$k<$cc+1;$k++){
      # Vector initialization
      $type_s[$sl] = $s_kind;
      $out_int[$sl]="";
      $gene_n[$sl]=0;
      $leak_p[$sl]=0;
      for(my $jj=0;$jj<4;$jj++){
	$reg_fac[$sl][$jj]=0;
      }

      for(my $l=0;$l<$num_in[$sk];$l++){		
	$input_l[$sl][$l]=$input_c[$j][$l];
      }
      for(my $l=0;$l<$num_in[$sk];$l++){
	$signals[$sl][$l]=$sg[$l];
      }

      il_cost_slSOP($s_kind,$sl);
      

      for(my $l=0; $l<$num_in[$sk]; $l++){
	$sol_prm[$sl][$l] = $prm[$cit][$l];
	$sol_rbs[$sl][$l] = $rbs[$cit][$l];
      }
      $free_rbs[$sl]=$free;
      $sol_num_in[$sl]=$num_in[$sk];
      $sol_cl[$sl]=scalar(@v_cl);
      $sol_class[$sl]=$final_c[$k][0];
      $out_int[$sl]=$final_c[$k][1];		
      #Reordering out_int				
      re_out_int_slSOP($sl);	
      $first_f[$sl]=$final_c[$k][2];				
      $second_f[$sl]=$final_c[$k][3];
      $gene_n[$sl] += $final_c[$k][4];
      $leak_p[$sl] = $final_c[$k][5];
      $reg_fac[$sl][0] += $final_c[$k][6];
      $reg_fac[$sl][1] += $final_c[$k][7];			
      $reg_fac[$sl][2] += $final_c[$k][8];
      $reg_fac[$sl][3] += $final_c[$k][9];	
      for(my $ii=0; $ii<$num_in[$sk];$ii++){
	for(my $jj=0; $jj<2; $jj++){
	  $sign_s[$sl][$ii][$jj] = $sign[$ii][$jj];
	}
      }				
      internal_layer_slSOP($s_kind,$sl);
      score_sol($sl);
      $sl++;	
    }	
  }
  
  if(0){
  if(scalar(@input_c) == 0){
      $type_s[$sl] = $s_kind;
      $out_int[$sl]="";
      $gene_n[$sl]=0;
      $leak_p[$sl]=0;

      
      $free_rbs[$sl]=$free;
      $sol_num_in[$sl]=$num_in[$sk];
      $sol_cl[$sl]=$num_in[$sk];
      $sol_class[$sl]=$final_c[0][0];
      $out_int[$sl]=$final_c[0][1];		
      #Reordering out_int				
      re_out_int_slPOS($sl);	
      $first_f[$sl]=$final_c[0][2];				
      $second_f[$sl]=$final_c[0][3];
      $gene_n[$sl] += $final_c[0][4];
      $leak_p[$sl] = $final_c[0][5];
      $reg_fac[$sl][0] += $final_c[0][6];
      $reg_fac[$sl][1] += $final_c[0][7];			
      $reg_fac[$sl][2] += $final_c[0][8];
      $reg_fac[$sl][3] += $final_c[0][9];	
      for(my $ii=0; $ii<$num_in[$sk];$ii++){
	for(my $jj=0; $jj<2; $jj++){
	  $sign_s[$sl][$ii][$jj] = $sign[$ii][$jj];
	}
      }				
      internal_layer_slPOS($s_kind,$sl);
      score_sol($sl);
      $sl++;	
    }	
    }

  $cit++;
} # end loop $tag


}
#-----------------------------------------------


sub f_as_sop{
  my $ca=$_[0];
  my $s_as=$_[1];

  my $dm;
  my @v_as;

  @v_as=split(/,/,$s_as);
  $dm=scalar(@v_as);
  for(my $i=0; $i<$dm; $i++){
    $i_as[$ca][$i]=$v_as[$i];
  }
}
#-----------------------------------------------


sub printas_sop{
my $ve=$_[0];
my $ca=$_[1];
	for(my $i=0; $i<$ca; $i++){
			print "$i \t";
		for(my $j=0; $j<8; $j++){
			print "$i_as[$i][$j] ";
		}
		print "\n";
	}
}
#-----------------------------------------------
sub count_free_sop{
my $it=$_[0];
my $rbs=$_[1];
my $free=0;
my $i;
        for($i=0; $i<$num_in[$sk]; $i++){
                if(${rbs}[$it][$i] eq ""){
                        $free++;
                }
        }
	return($free);
}
#-----------------------------------------------






1;
