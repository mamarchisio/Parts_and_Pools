#! /usr/bin/perl
use strict;
use CalcSingle_Mixed;
use CalcInput_Mixed;

our $sl;                # solution number
our $sk;                # solution kind (POS or SOP)
our $s_kind;
our @fm_list=();        # Boolean formulae
our @lg_cl=();		# Clauses' length
our @num_cl=();		# Clauses' number
our @v_cl=(); 		# vector of clauses
our @num_in=();         # input number 
our @sg=();		# positive signals
our @nsg=();		# negated signals
our @sign;              # sign matrix
our $ca;                # counter assignment
our @type_s=();
our @out_int=();
our @gene_n=();
our @leak_p=();
our @reg_fac=();
our @input_l=();
our @sol_cl=();
our @sol_num_in=();
our @sol_class=();	
our @free_rbs=(); 	
our @first_f=();
our @second_f=();	
our @sol_prm=();		
our @sol_rbs=();		
our @score_s=();
our @sign_s=();
our @final_c;
our @signals;

our @sg_plus=();        # positive single literals 
our @sg_min=();         # negative single literals
our @asg=();            # other signals
our @i_as=();           # integer assignment 
our @rbs;
our $fm_plus;
our $fm_min;
our @lts=();
our $two;        	# means two literals

sub mixed_solution{
my $fm=$fm_list[$sk];   # current formula
my $s_as;               # string (partial) assignment   
my $tag;		# total assignments
my @s_deg;		# signal degeneracy - for input layer calculation
my @prm;		# 
my @input_c;
my @deg_il;	        # vector containing all the possible input layers associated with a signal
my %sph;		# signals-parts hash
my $cc=0;		# counter-final-configurations
my $cc_t=0;		# temporary counter
my $free=0;		# number of free RBS in a given internal layer configuration

# this is a particular case for POS formulae like (a+b)*c 

# Separing single literals from the OR/NAND clause
for(my $i=0;$i<$num_cl[$sk]; $i++){
  if($lg_cl[$i] == 1){
    push(@lts,$v_cl[$i]);
  }else{
    $two=$v_cl[$i];
  }
}

# signals to promoter: chemicals sent to the RBS of the input gate and the TF to the promoter of the final gate
my @si_pro=();

@si_pro=split(/\+/,$two);

@sg=();
@nsg=();
@asg=();
# Constructing asg 
# Assignment enumeration
$ca=0;				# unique assignment

# signals in $two bind the RBS of input gates producing TF for the final gate's promoter
push(@asg,$si_pro[0]);
$i_as[0][0]=1;
push(@asg,$si_pro[1]);
$i_as[0][1]=1;

# single literals are sent to the final gate's RBS; they can be either inducers or corepressors
push(@asg,$lts[0]);
$i_as[0][2]=1;
if($lts[1] ne ""){
  push(@asg,$lts[1]);
  $i_as[0][3]=1;
}

print @asg, "\n";
@num_in=();
# Counting the number of input signals - signals to the final gate are also considered here
if($fm =~/[aA]/){
  $num_in[$sk]++;
  push(@sg,'a');
  push(@nsg,'A');
}

if($fm =~/[bB]/){
  $num_in[$sk]++;
  push(@sg,'b');
  push(@nsg,'B');
}

if($fm =~/[cC]/){
  $num_in[$sk]++;
  push(@sg,'c');
  push(@nsg,'C');
  
}

if($fm =~/[dD]/){
  $num_in[$sk]++;
  push(@sg,'d');
  push(@nsg,'D');
}

$tag=1;

# tag loop
ta_l:for(my $i=0; $i<$tag; $i++){   
  $prm[0]=();
  $rbs[0]=();

#  hash: signal--> part
#  my $dim=scalar(@sg_to_final)+scalar(@asg);
  my $dim=scalar(@asg);

  for(my $j=0; $j<2; $j++){
    $prm[0][$j]="";
    $rbs[0][$j]=$si_pro[$j];
  }    
  
  # Calculating the input layer(s) associated with the current internal layer
  input_layer_mixed($sl);			                # no internal gates in mixed solutions

  # Calculating the final layer 
  $cc_t=final_layer_mixed();		# start filling up the @final_c vector 
  $cc=$cc_t;

  # Vector initialization
  $type_s[$sl] = $s_kind;
  $out_int[$sl]="";
  $gene_n[$sl]=0;
  $leak_p[$sl]=0;
  

  for(my $l=0; $l<2; $l++){
    $sol_prm[$sl][$l] = $prm[0][$l];
    $sol_rbs[$sl][$l] = $rbs[0][$l];
  }

  $free_rbs[$sl]=0;
  $sol_num_in[$sl]=$num_in[$sk];
  $sol_cl[$sl]=$num_cl[$sk];
  $sol_class[$sl]=$final_c[$cc][0];
  $out_int[$sl]=$final_c[$cc][1];		
  
  $first_f[$sl]=$final_c[$cc][2];				
  $second_f[$sl]=$final_c[$cc][3];
  $gene_n[$sl] += $final_c[$cc][4];
  $leak_p[$sl] = $final_c[$cc][5];
  $reg_fac[$sl][0] += $final_c[$cc][6];
  $reg_fac[$sl][1] += $final_c[$cc][7];			
  $reg_fac[$sl][2] += $final_c[$cc][8];
  $reg_fac[$sl][3] += $final_c[$cc][9];	
  score_sol($sl);
  $sl++;	

} # end loop $tag


}


1;
