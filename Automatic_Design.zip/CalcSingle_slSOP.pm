#! /usr/bin/perl
use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
our @num_cl;
our @final_c;
our @sg_min;
our $int_gates;

# final_c - columns (each row is a possible configuration)
# 0: single/disj
# 1: out_int
# 2: first_f
# 3: second_f
# 4: gene_n
# 5: leak_p
# 6: (A)
# 7: (R)
# 8: (k)
# 9: (l)


sub final_layer_slSOP{
my $s_kind=$_[0];		# solution kind
my $free=$_[1];			# number of free RBSs
my $cc=0;			# configuration-counter, first entry in @final_c; 
my $i;
my $qt;
my $re;
my $u_cl;
my $d_cl;
my $t_cl;
my $q_cl;
my $df;

# $cc must be equal to 0
$int_gates=$num_cl[$sk]-scalar(@sg_min);
######### Single solutions
initl($cc);
### case 1) The same TF is produced by every gate. Always possible
$final_c[$cc][0] = "compact";		 
for($i=0; $i<$int_gates; $i++){
  $final_c[$cc][1] .= "A";
}
$final_c[$cc][2] = "";
$final_c[$cc][3] = "or1A_f";		
$final_c[$cc][4] = $int_gates+1;
$final_c[$cc][5] = 1;
$final_c[$cc][6]++;
	
return($cc);
}
#----------------------------------------------------------------------------------------


sub initl{
my $cc=$_[0];
my $i;
	$final_c[$cc][1]="";
	for($i=6; $i<10; $i++){
		$final_c[$cc][$i] = 0;
	}
}
#----------------------------------------

1;

