#! /usr/bin/perl
use strict;
our @fm_list;
our @sol_cl;
our @sg;
our @reg_fac;
our @score_s;
our @gene_n;
our @free_rbs;
our @type_s;
our @sol_class;
our @input_l;
our @int_lay;
our @sol_prm;
our @sol_rbs;
our @leak_p;
our @out_int;
our @first_f;
our @second_f;
our @sol_num_in;
our @sign_s;
our @signals;
our @lts;
our @sg_to_final;

sub score_sol{
my $sl=$_[0];
my $sc;
my $an;
my $san;
my $rn;
my $srn;
my $kn;	
my $ln;
	if($reg_fac[$sl][0] > 0){
		$an=$reg_fac[$sl][0]-1;
		$san=2**$an;	
	}else{
		$san=0;
	}

	if($reg_fac[$sl][1] > 0){
		$rn=$reg_fac[$sl][1]-1;
		$srn=2**$rn;
	}else{
		$srn=0;
	}

	$kn=$reg_fac[$sl][2];
	$ln=$reg_fac[$sl][3];
	
	$sc=$san+$srn+$kn+$ln;

	$score_s[$sl]=$sc;

}
#----------------------------------------------------------------------


sub ranking_sol{
my $sl=$_[0];

my @rk_sco=();
my @s_sco=();
my $p_sol;
my $i;

my $filename="solutions.txt";
	
	open(OUT,">>$filename");

	# sort numerically ascending
	@s_sco = sort {$a <=> $b} @score_s;
	ranking(\@s_sco, \@score_s, $sl, \@rk_sco);
	

	############
	my @c_rk_sco=@rk_sco;

	my $sc=0;
	my $dsc;
	my @dis=();
	
	for($i=0; $i<$sl; $i++){
		if($s_sco[$i] != $sc){
			$sc=$s_sco[$i];
			if($i > 0){
				push(@dis,$dsc);
			}
			$dsc=1;
		}else{
			$dsc++;
		}
	}
	push(@dis,$dsc);	

	my $j;
	my @new_rk_sco=();
	my @nu_ge=();
       	my @s_nu_ge=();
        my @rk_nu_ge=();
	my $en;
	for($i=0;$i<scalar(@dis);$i++){
		@nu_ge=();
		@s_nu_ge=();
		@rk_nu_ge=();
		for($j=0;$j<$dis[$i];$j++){
			$nu_ge[$j]=$gene_n[$c_rk_sco[$j]];
		}
		@s_nu_ge = sort {$a <=> $b} @nu_ge;
		ranking(\@s_nu_ge, \@nu_ge, $dis[$i], \@rk_nu_ge);		
	
		for($j=0;$j<$dis[$i];$j++){
			$en=$rk_nu_ge[$j];
			push(@new_rk_sco,$c_rk_sco[$en]);
		}
		
		for($j=0;$j<$dis[$i];$j++){
			shift(@c_rk_sco);
		}

	}

	@rk_sco=@new_rk_sco; 
	###############################################
	
	print "SOLUTION RANKING \n";
	for($i=0; $i<$sl; $i++){
		$p_sol=$rk_sco[$i];
		print $i+1,") Solution ",$p_sol+1,"\t\t score: $score_s[$p_sol] \t gene number: $gene_n[$p_sol] \t RF-single: $leak_p[$p_sol] \t free rbss: $free_rbs[$p_sol] \t type: $type_s[$p_sol] \t class: $sol_class[$p_sol] \n";
	}
	print "\n";
	
	print  OUT "SOLUTION RANKING \n";
	for($i=0; $i<$sl; $i++){
		$p_sol=$rk_sco[$i];
		print OUT $i+1,") Solution ",$p_sol+1,"\t\t score: $score_s[$p_sol] \t gene number: $gene_n[$p_sol] \t RF-single: $leak_p[$p_sol] \t free rbss: $free_rbs[$p_sol] \t type: $type_s[$p_sol] \t class: $sol_class[$p_sol] \n";
	}
	close(OUT);
}
#----------------------------------------------------------------------


sub ranking{
my $s_v=$_[0];
my $i_v=$_[1];
my $n_l=$_[2];
my $r_c=$_[3];
my $i;
my $val;
my $ctr;
my $k;
my $j;

for($i=0; $i<$n_l; $i++){
        $val=${$s_v}[$i];
        for($j=0; $j<$n_l; $j++){
                $ctr=0;
                if(${$i_v}[$j] == $val){
                        for($k=0; $k<$i; $k++){
                                if(${$r_c}[$k] == $j){
                                        $ctr=1;
                                        last;
                                }
                        }
                        if($ctr == 1){
                                next;
                        }else{
                                ${$r_c}[$i]=$j;
                                last;
                        }
                }
        }
}

}
#----------------------------------------------------------------------


sub printsol{
my $sl=$_[0];

my $i;
my $free;
my $filename="solutions.txt";
my $j;
my @r_f=('A','R','k','l');
	open(OUT,">$filename");
	
	for($i=0; $i<2; $i++){
		print OUT "$fm_list[$i] \n";
	}
	print OUT "\n";	
	print OUT "SOLUTIONS \n";
	print OUT "--------------------------------------------\n";
	print OUT "\n";
	for($i=0; $i<$sl; $i++){
		print OUT "Solution ", $i+1, "\n";
		print OUT "Type: $type_s[$i] \n";
		print OUT "Class: $sol_class[$i] \n";
		print OUT "Clause Number: $sol_cl[$i] \n";
        	print OUT "Free RBSs: $free_rbs[$i] \n";
		print OUT "Gene number: $gene_n[$i] \n";
		print OUT "Score: $score_s[$i] \n";
		print OUT "RF-single: $leak_p[$i] \n";
        	print OUT "promoters:\n";
		for($j=0; $j<$sol_cl[$i]; $j++){
        		print OUT "$j \t $sol_prm[$i][$j] \n";
		}
        	print OUT "rbss: \n";
		for($j=0; $j<$sol_cl[$i]; $j++){
        		print OUT "$j \t $sol_rbs[$i][$j] \n";
		}
		print OUT "\n";
		print OUT "Input layer \n";
		my $dim;
		for($j=0; $j<scalar(@sg); $j++){
			print OUT "$signals[$i][$j] \t $input_l[$i][$j] \n";
                }
		print OUT "\n";
		print OUT "Internal layer \n";
		for($j=0; $j<$sol_cl[$i]; $j++){
        		print OUT "$j \t $int_lay[$i][$j] \n";
		}
		print OUT "\n";
		print OUT "Output internal layer: \t $out_int[$i] \n";
		print OUT "\n";
		print OUT "Final layer \n";
		print OUT "first gate set: \t $first_f[$i] \n";
		print OUT "second gate set: \t $second_f[$i] \n";
		print OUT "\n";

		if($sol_class[$i] eq "mixed"){
		  print OUT "Signals to the final gate: ";
		  for(my $k=0; $k<scalar(@lts);$k++){
		    print OUT lc($lts[$k]);
		  }
		  print OUT "\n";
		}

		if($sol_class[$i] eq "compact"){
		  print OUT "Signals to the final gate: ";
		  for(my $k=0; $k<scalar(@sg_to_final);$k++){
		    print OUT "$sg_to_final[$k] ";
		  }
		  print OUT "\n";
		  print OUT "\n";
		}


		for($j=0; $j<scalar(@r_f); $j++){
			print OUT "$r_f[$j] \t $reg_fac[$i][$j] \n";
                }
		print OUT "\n";
		print OUT "--------------------------------------------\n";
		print OUT "\n";
	}
	close(OUT);
}
#----------------------------------------------------------------------


1;
