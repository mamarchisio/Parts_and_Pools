#! /usr/bin/perl
use strict;
use PartsMaker;
use DevicesDesigner;

sub input_gate{
my $name = $_[0];
my $s_type= $_[1];
my $pro1;
my $rbs1;
my $cod1;
my $ter1;
my $pro2;
my $rbs2;
my $cod2;
my $ter2;
my $pro3;
my $rbs3;
my $cod3;
my $ter3;
my $srna2;
my $srna3;

# MIXED SOLUTION
if($name eq "yes1i"){
        $pro1="p0";
        $rbs1="riyes";
        $cod1="tfl";
        $ter1="te";

        gen_prom($pro1);
        gen_rbs($rbs1,'n');
        gen_cod($cod1,'y');
        gen_ter($ter1,'n');
        design_long($name,$pro1,$rbs1,$cod1,$ter1);
}

if($name eq "not1c"){
        $pro1="p0";
        $rbs1="rcnot";
        $cod1="tfl";
        $ter1="te";

        gen_prom($pro1);
        gen_rbs($rbs1,'n');
        gen_cod($cod1,'y');
        gen_ter($ter1,'n');
        design_long($name,$pro1,$rbs1,$cod1,$ter1);
}


# YES gate, the only which requires one gene
if($name eq "yes0"){
	$pro1="p0yes0";
	$rbs1="r0";
	$cod1="tf";
	$ter1="te";
	
	gen_prom($pro1);
   	gen_rbs($rbs1,'n');
        gen_cod($cod1,'n');
	gen_ter($ter1,'n');
	design_long($name,$pro1,$rbs1,$cod1,$ter1);
}


# POS input gates
if($s_type eq "POS"){
# NOT gates; two genes
	if($name eq "not0"){
		$pro1="p0not0pos";
		$rbs1="r0";
		$cod1="tf";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'n');
		gen_ter($ter1,'n');

		$pro2="pRinot0pos";	# check!!!
		$rbs2="r0l";            # with pol_lk as an input
		$cod2="tf";
		$ter2="te";
		gen_prom($pro2);        
   		gen_rbs($rbs2,'y');     # the other parts are already present
		gen_polsum('p');
		gen_ribsum('r');
		design_two_long($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$rbs2,$cod2,$ter2);
	}

	if($name eq "not1"){
		$pro1="p0not1pos";
		$rbs1="r0";
		$cod1="tf";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'n');
		gen_ter($ter1,'n');

		$pro2="pRinot1pos_s";
		$srna2="s0l";
		$ter2="tes";
		gen_prom($pro2); 
		gen_srna($srna2,'y');
		gen_ter($ter2,'y');

		gen_polsum('p');
		design_two_short($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$srna2,$ter2);
	}

	if($name eq "not2"){
		$pro1="p0not2pos";
		$rbs1="rcnot";
		$cod1="tfl";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'y');
		gen_ter($ter1,'n');

		design_long($name,$pro1,$rbs1,$cod1,$ter1);
	}

	if($name eq "not3"){
		$pro1="p0not3pos";
		$rbs1="rcnot";
		$cod1="tfl";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'y');
		gen_ter($ter1,'n');

		$pro2="pAanot3pos_s";
		$srna2="s0l";
		$ter2="tes";
		gen_prom($pro2); 
		gen_srna($srna2,'y');
		gen_ter($ter2,'y');

		gen_polsum('p');
		design_two_short($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$srna2,$ter2);
	}
}

# SOP input gates
if($s_type eq "SOP"){
# NOT0 and NOT1 gate; three genes
	if($name eq "not0"){		# the gene number 2 is the one on the third place in the sequence
		$pro1="p0_1not0sop";		# the gene number 3 is on the contrary on the second position
		$rbs1="r0";
		$cod1="tf";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'n');
		gen_ter($ter1,'n');

		$pro2="p0_2not0sop";
		$rbs2="rlnot";
		$cod2="tfl";
		$ter2="te";
		gen_prom($pro2);
		gen_rbs($rbs2,'n'); # the other parts are already present
        	gen_cod($cod2,'y');

		$pro3="pAinot0sop_s";
		$srna3="s0l";
		$ter3="tes";
		gen_prom($pro3);
   		gen_srna($srna3,'y');
		gen_ter($ter3,'y');
		
		gen_polsum('p');
		gen_ribsum('r');
		design_three($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$rbs2,$cod2,$ter2,$pro3,$srna3,$ter3);
	}

	if($name eq "not1"){
		$pro1="p0_1not1sop";
		$rbs1="r0";
		$cod1="tf";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'n');
		gen_ter($ter1,'n');

		$pro2="pAinot1sop";
		$rbs2="r0l";
		$cod2="tfl";
		$ter2="te";
		gen_prom($pro2); # the other parts are already present
   		gen_rbs($rbs2,'y');
		
		$pro3="pRanot1sop_s";
		$srna3="s0l";
		$ter3="tes";
		gen_prom($pro3);
   		gen_srna($srna3,'y');
		gen_ter($ter3,'y');
		
		gen_polsum('p');
		gen_ribsum('r');
		design_three($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$rbs2,$cod2,$ter2,$pro3,$srna3,$ter3);
	}

# NOT2 and NOT3 gate; two genes
	if($name eq "not2"){
		$pro1="p0not2sop";
		$rbs1="riyes";
		$cod1="tfl";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'y');
		gen_ter($ter1,'n');

		$pro2="pRanot2sop";
		$rbs2="r0l";
		$cod2="tfl";
		$ter2="te";
		gen_prom($pro2); # the other parts are already present
		gen_rbs($rbs2,'y');
        	gen_cod($cod2,'n');

		gen_polsum('p');
		gen_ribsum('r');
		design_two_long($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$rbs2,$cod2,$ter2);
	}
	
	if($name eq "not3"){
		$pro1="p0not3sop";
		$rbs1="riyes";
		$cod1="tfl";
		$ter1="te";
		gen_prom($pro1);
   		gen_rbs($rbs1,'n');
        	gen_cod($cod1,'y');
		gen_ter($ter1,'n');

		$pro2="pRanot3sop_s";
		$srna2="s0l";
		$ter2="tes";
		gen_prom($pro2); 
		gen_srna($srna2,'y');
		gen_ter($ter2,'y');

		gen_polsum('p');
		design_two_short($name,$pro1,$rbs1,$cod1,$ter1,$pro2,$srna2,$ter2);
	}
}


}
1;
		
