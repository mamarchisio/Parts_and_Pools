#! /usr/bin/perl
use strict;
our @out_int;
our @num_cl;
our @lg_cl;
our @v_cl=();
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $sk;

sub internal_layer{
my $s_kind=$_[0];
my $sl=$_[1];

my $i;
my $j;
my $gate;
my $index;
my $prm;
my @sig_p;
my $n_sig;
my $rbs;
my @sig_r;
my @out_s=();
my $out;
my @uin;		# unordered input
my @oin;		# ordered input	
my $el;
my $g_sig;		# number of signals to the gate	
	if($s_kind eq "POS"){
		@out_s=split(//,$out_int[$sl]);

		for($i=0;$i<$num_cl[$sk];$i++){
			# calculating the number of signals to the internal gates
                        $prm=$sol_prm[$sl][$i];
                        @sig_p=split(//,$prm);

                        $rbs=$sol_rbs[$sl][$i];
                        @sig_r=split(//,$rbs);
			$g_sig=scalar(@sig_p)+scalar(@sig_r); 

	                @uin=();
        	        @oin=();
			$gate="";
			@sig_p=();
			if($lg_cl[$i] == 1){ 
				  $gate="not1";
		     	}else{
				$index=$g_sig;
				$gate="nor".$index;
			}
					
			$prm=$sol_prm[$sl][$i];
			@sig_p=split(//,$prm);
			$n_sig=scalar(@sig_p); 
			for($j=0; $j<$n_sig; $j++){	 # every signal to the promoter wants a repressor on the internal gate
				if($sig_p[$j] =~ /[abcd]/){
					push(@uin,"Ri");
				}else{
					push(@uin,"Ra");
				}
			}

			$rbs=$sol_rbs[$sl][$i];
			@sig_r=split(//,$rbs);
			$n_sig=scalar(@sig_r);
			for($j=0; $j<$n_sig; $j++){
				if($sig_r[$j] =~ /[abcd]/){ # every positive signal to the rbs is not accompanied by any regulatory factor
					push(@uin,'c');
				}
				if($sig_r[$j] =~ /[ABCD]/){ # every negative signal to the rbs requires a lock
					push(@uin,'l');
				}
			}
			
			# Reordering the input -- Ri Ra l c
			foreach $el ("Ri","Ra",'l','c'){
				for($j=0; $j<scalar(@uin); $j++){
					if($uin[$j] eq $el){
						push(@oin,$el);
					}
				}
			}

			# Adding the input to the gate
			for($j=0; $j<scalar(@oin); $j++){
				$gate .=$oin[$j];
			}

			$out=$out_s[$i];
			    $gate .= "_";
			    $gate .= "$out";
			$int_lay[$sl][$i]=$gate;
		}
	}elsif($s_kind eq "SOP"){		
		@out_s=split(//,$out_int[$sl]);
		for($i=0;$i<$num_cl[$sk];$i++){
	                @uin=();
        	        @oin=();
			$gate="";
			@sig_p=();
			$prm=$sol_prm[$sl][$i];
			@sig_p=split(//,$prm);
			$n_sig=scalar(@sig_p);
			for($j=0; $j<$n_sig; $j++){   # every signal to the promoter wants an activator on the internal gate
                                if($sig_p[$j] =~ /[abcd]/){
					push(@uin,"Ai");
                                }else{
					push(@uin,"Aa");
                                }
			}

                        $rbs=$sol_rbs[$sl][$i];
                        @sig_r=split(//,$rbs);
                        $n_sig=scalar(@sig_r);
                        for($j=0; $j<$n_sig; $j++){
                                if($sig_r[$j] =~ /[abcd]/){ # every positive signal to the rbs is not accompanied by any regulatory factor
                                        push(@uin,"i");
                                }
                                if($sig_r[$j] =~ /[ABCD]/){ # every negative signal to the rbs requires a key
                                        push(@uin,"k");
                                }
                        }

			$g_sig=scalar(@sig_p)+scalar(@sig_r); 

	                        if($lg_cl[$i] == 1){
        	                        $gate="yes1";
	                        }else{
                                	$index=$g_sig;
                                	$gate="and".$index;
				}


			# Reordering the input -- Ri Ra l c
                        foreach $el ("Ri","Ra",'l','c'){
                                for($j=0; $j<scalar(@uin); $j++){
                                        if($uin[$j] eq $el){
                                                push(@oin,$el);
                                        }
                                }
                        }

                        # Adding the input to the gate
                        for($j=0; $j<scalar(@oin); $j++){
                                $gate .=$oin[$j]
                        }


                       # Reordering the input -- Ai Aa k i
                        foreach $el ("Ai","Aa",'k','i'){
                                for($j=0; $j<scalar(@uin); $j++){
                                        if($uin[$j] eq $el){
                                                push(@oin,$el);
                                        }
                                }
                        }

                        # Adding the input to the gate
                        for($j=0; $j<scalar(@oin); $j++){
                                $gate .=$oin[$j]
                        }

			$out=$out_s[$i];
			$gate .= "_";
			$gate .= "$out";
			$int_lay[$sl][$i]=$gate;
		}
	}
}		
#----------------------------------------------------------------------


sub re_out_int{
my $sl=$_[0];

my @new_outa=();
my @tmp=split(//,$out_int[$sl]);
my $i;
my $j;
my $loi="";

	for($i=0;$i<$num_cl[$sk];$i++){
		$new_outa[$i]="no";
	}

	f_l:for($i=0;$i<$num_cl[$sk];$i++){
		if($tmp[$i] eq 'l' || $tmp[$i] eq 'o' || $tmp[$i] eq 'k' || $tmp[$i] eq 'e'){
			for($j=0;$j<$num_cl[$sk];$j++){
				if($sol_rbs[$sl][$j] eq "" && $new_outa[$j] eq "no"){
						$new_outa[$j] = $tmp[$i];
						next f_l;
				}
			}
		}
	}	

	s_l:for($i=0;$i<$num_cl[$sk];$i++){
		if($tmp[$i] eq 'R' || $tmp[$i] eq 'S' || $tmp[$i] eq 'A' || $tmp[$i] eq 'B'|| $tmp[$i] eq 'f'){
			for($j=0;$j<$num_cl[$sk];$j++){
				if($new_outa[$j] eq "no"){
					$new_outa[$j] = $tmp[$i];
					next s_l;
				}
			}
		}
	}							

	for($i=0;$i<$num_cl[$sk];$i++){
		$loi .= $new_outa[$i];
	}
	$out_int[$sl]=$loi;
}
#----------------------------------------------------------------------








				
1;
