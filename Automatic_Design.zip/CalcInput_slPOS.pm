#! /usr/bin/perl
use strict;
# Finding unique and degenerate input layers
our @num_in;
our @sg;
our @nsg;
our @sign;
our $sk;
our @reg_fac;
our @gene_n;
our @input_l;
our @sg_min;
our @common=();         # array of negated inputs that share a pool
our $common_flag;
our @co_sig=();
our @co_sig_cs;

#----------------------------------------------------------------------


sub il_costPOS{		# counting the regulatory factors due to the input layer
my $s_kind=$_[0];
my $sl=$_[1];
my $i;	
	if($s_kind eq "POS"){
		for($i=0; $i<$num_in[$sk]; $i++){
			if($input_l[$sl][$i] eq "yes0"){
				$reg_fac[$sl][1]++;    # adding a repressor
				$gene_n[$sl]++;
				next;
			}				

			if($input_l[$sl][$i] eq "yes1"){
				next;
			}				
			
			if($input_l[$sl][$i] eq "not0"){
				$reg_fac[$sl][1] += 2;
				$gene_n[$sl] +=2;
				next;
			}
			
			if($input_l[$sl][$i] eq "not1"){
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][3]++;
				$gene_n[$sl] +=2;
				next;
			}

			if($input_l[$sl][$i] eq "not2"){	
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=1;
				next;
			}	
				
			if($input_l[$sl][$i] eq "not3"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][3]++;	
				$gene_n[$sl] +=2;
				next;
			}
		}

               # Reducing the cost if some regulatory factor pools can be contracted
                if($common_flag eq 'y'){
                        my $ctr=scalar(@common); # number of possible contractions (max 2)
                        for(my $j=0; $j<$ctr; $j++){
                                my $ct_r=0;
                                my $ct_l=0;
                                for(my $k=0; $k<scalar(@{$co_sig_cs[$j]}); $k++){
                                        if($input_l[$sl][$co_sig_cs[$j][$k]] eq "not0" || $input_l[$sl][$co_sig_cs[$j][$k]] eq "not2"){
                                                $ct_r++;
                                        }elsif($input_l[$sl][$co_sig_cs[$j][$k]] eq "not1" || $input_l[$sl][$co_sig_cs[$j][$k]] eq "not3"){
                                                $ct_l++;
                                        }
                                }
                                if($ct_r == 2){
                                        $reg_fac[$sl][1]--;
                                }
                                if($ct_l == 2){
                                        $reg_fac[$sl][3]--;
                                }
                        }
                }		
	}elsif($s_kind eq "SOP"){
		for($i=0; $i<$num_in[$sk]; $i++){
			if($input_l[$sl][$i] eq "yes0"){
				$reg_fac[$sl][0]++;    # adding an activator
				$gene_n[$sl]++;
				next;
			}				

			if($input_l[$sl][$i] eq "yes1"){
				next;
			}				
			
			if($input_l[$sl][$i] eq "not0"){
				$reg_fac[$sl][0] += 2;
				$reg_fac[$sl][3] += 1;
				$gene_n[$sl] +=3;
				next;
			}
			
			if($input_l[$sl][$i] eq "not1"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;
				$gene_n[$sl] +=3;
				next;
			}

			if($input_l[$sl][$i] eq "not2"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=2;
				next;
			}	
				
			if($input_l[$sl][$i] eq "not3"){
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;	
				$gene_n[$sl] +=2;
				next;
			}
	
		}
	}

}	
#----------------------------------------------------------------------


1;
