#! /usr/bin/perl
$inc="(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
open(CC,">CIRC");
print CC "$inc \n";
close(CC);

`cat p*mdl >> CIRC`;
`cat r*mdl >> CIRC`;
`cat f*mdl >> CIRC`;
`cat t*mdl >> CIRC`;
`cat s*mdl >> CIRC`;
`cat *pool*mdl >> CIRC`;
`cat i*mdl >> CIRC`;
`cat n*mdl >> CIRC`;
`cat a*mdl >> CIRC`;
`cat o*mdl >> CIRC`;
`cat y*mdl >> CIRC`;
`cat circuit.mdl >> CIRC`;
`mv CIRC CIRCUIT.mdl`;
