#! /usr/bin/perl
use strict;
use PartsMaker;

our $two;
our @lts;

sub connections_mixed{
our $n_in;
our $solu;
our @sol_cl;
our @type_s;
our @sign_s;
our @sg;
our @nsg;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our @input_l;
our @second_fa;
our @out_int;
my @nb_s=();
my @nb_rf=();
my $nb;
my $i; 
my $j;
my $k;
my $name;
my $nm;
my $dm;
my $gp=0;
my $gr=0;
my @st_state=();
my @pos_state=();	
my @neg_state=();
my @int_state=(); 
my @tmpa;
my $stn;
my $ntn;
my $ptn;
my $itn;
my @namea;
my $ftn;
my @f_state=();
my $etn;
my @inpff=();
my @ointa=();
my $plp=1;
my $rbp=1;


	gen_pol_pool();
	gen_rib_pool();

	# Input layer: signal and rf pools' generation 
	$dm=scalar(@sg);
	for($i=0;$i<$dm;$i++){
        	gen_signal_pool($sg[$i]);
	}
	my @two_v=split(/\+/,$two);

	for($i=0;$i<2;$i++){	
		if($two_v[$i] =~/[abcd]/){
			$nm="Act";
			gen_tf_pool($nm,'a','n');  # for activators
			last;
		}else{
			$nm=$two_v[$i]."_neg";
			gen_tf_pool($nm,'a','n');  # for repressors
		}
	}
	
my $filename="circuit.mdl";
open (OUT,">$filename");
print OUT "
(define-module
  :class \"digital_c\"
  :super-classes (\"module\")
  :geometry-width \"2000\"
  :geometry-height \"1800\"";

# modules
print OUT "
  :modules(";

# Signal pools
my $xc=200;
my $yc=0;
for($i=0; $i<$n_in; $i++){
	$yc += 300;
print OUT "
   (\"${sg[$i]}_pool\"
    :is-a \"${sg[$i]}_pool\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
}

# Input layer
$dm=2;
$xc=400;
my $xcd=650;
my $xct=700;
$yc=-100;
my $ycd=0;
my $sx="";
my @input_l_nm=();
for($i=0; $i<$dm; $i++){
	$sx="ip".$i;
	$yc += 300;
	$nm="$input_l[$solu][$i]"."_"."$sx";
	push(@input_l_nm,$nm);
print OUT "
   (\"${input_l[$solu][$i]}_${sx}\"
    :is-a \"$input_l[$solu][$i]\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
}

if($two =~ /[abcd]/){
	$ycd = 100; 
print OUT "
   (\"Act_pool\"
    :is-a \"Act_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
}else{
		$ycd = 100; 	
   	for($i=0;$i<2;$i++){
       		$ycd += 300;
print OUT "
   (\"${two_v[$i]}_neg_pool\"
    :is-a \"${two_v[$i]}_neg_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
	}
}

# Final gates
$xc=1600;
$yc=800;
my @second_fa_nm=();
$nm="$second_fa[0]"."_sf0";
push(@second_fa_nm,$nm);
print OUT "
   (\"${second_fa[0]}_sf0\"
    :is-a \"$second_fa[0]\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";

# Polpool and ribpool
print OUT "
   (\"polpool\"
    :is-a \"polpool\"
    :geometry-x \"1600\"
    :geometry-y \"200\")
   (\"ribpool\"
    :is-a \"ribpool\"
    :geometry-x \"200\"
    :geometry-y \"1600\")";

print OUT ")";

# links
my $j;
print OUT "
  :links(";

#signal pools to input gates
for($i=0;$i<2;$i++){
print OUT "
   (\"${two_v[$i]}_pool_link\"
    :terminals(\"${two_v[$i]}_pool.exc_sig\" \"$input_l_nm[$i].exc_rf_1\"))";
}

#input gates to tf pool(s)  
if($two =~ /[abcd]/){
print OUT "
   (\"Act_pool_link\"
    :terminals(\"Act_pool.in_tf\" \"$input_l_nm[0].out_tf\" \"$input_l_nm[1].out_tf\"))";
}else{
	for($i=0;$i<2;$i++){ 	
print OUT "
   (\"${two_v[$i]}_neg_pool_link\"
    :terminals(\"${two_v[$i]}_neg_pool.in_tf\" \"$input_l_nm[$i].out_tf\"))";
	}
}	

#tf pool(s) to final gate
if($two =~ /[abcd]/){
print OUT "
   (\"Final_link\"
    :terminals(\"Act_pool.exc_tf_a\" \"$second_fa_nm[0].exc_tf_a_1\"))";
}else{
print OUT "
   (\"Final_link_1\"
    :terminals(\"$second_fa_nm[0].exc_tf_a_1\" \"${two_v[0]}_neg_pool.exc_tf_a\")) 
   (\"Final_link_2\"
    :terminals(\"$second_fa_nm[0].exc_tf_a_2\" \"${two_v[1]}_neg_pool.exc_tf_a\"))";
}

# single literals to final gate
print OUT "
   (\"$lts[0]_final_gate\"
    :terminals(\"${lts[0]}_pool.exc_sig\" \"$second_fa_nm[0].exc_rf_1\"))";

if(scalar(@lts) == 2){
print OUT "
   (\"$lts[1]_final_gate\"
    :terminals(\"${lts[1]}_pool.exc_sig\" \"$second_fa_nm[0].exc_rf_2\"))";	
}

my @exc_pol_link=();
my @in_pol_link=();
my @exc_r_link=();
my @in_r_link=();

#### polpool and ribpool to the gates
for($i=0; $i<2; $i++){
	push(@exc_pol_link,"${input_l_nm[$i]}.exc_pol");
	push(@in_pol_link,"${input_l_nm[$i]}.out_pol");
        push(@exc_r_link,"${input_l_nm[$i]}.exc_r");
        push(@in_r_link,"${input_l_nm[$i]}.out_r");
}

for($i=0; $i<scalar(@second_fa); $i++){
        push(@exc_pol_link,"${second_fa_nm[$i]}.exc_pol");
        push(@in_pol_link,"${second_fa_nm[$i]}.out_pol");
	push(@exc_r_link,"${second_fa_nm[$i]}.exc_r");
        push(@in_r_link,"${second_fa_nm[$i]}.out_r");
}

##multiple links# pol --> exc_pol/in_pol terminal
	my $dim=scalar(@exc_pol_link);
print OUT "
   (\"Polpool_exc_pol_link\"
    :terminals(\"Polpool.exc_pol\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$exc_pol_link[$j]\"";
        }
        print OUT "))";

	my $dim=scalar(@in_pol_link);
print OUT "
   (\"Polpool_in_pol_link\"
    :terminals(\"Polpool.in_pol\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$in_pol_link[$j]\"";
        }
        print OUT "))";

##multiple links# r --> exc_r/in_r terminal
        my $dim=scalar(@exc_r_link);
print OUT "
   (\"Ribpool_exc_r_link\"
    :terminals(\"Ribpool.exc_r\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$exc_r_link[$j]\"";
        }
        print OUT "))";

        my $dim=scalar(@in_r_link);
print OUT "
   (\"Polpool_in_r_link\"
    :terminals(\"Ribpool.in_r\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$in_r_link[$j]\"";
        }
        print OUT "))";

print OUT ")";

print OUT ")"; # define module
} # end sub
	
1;
