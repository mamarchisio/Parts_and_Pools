#! /usr/bin/perl 
use strict;

my $i;
my $j;

my @par=@ARGV;

my @def=("rbs",'p',0,0,"I1","I1",'n','n','n','n',2,0.0116,"1.0e6",0.01,0.02,"1.0e4",0.01,"1.0e4",0.01,"1.0e4",0.01,"1.0e4",0.01,"1.0e4",0.01,"1.0e-12");

my $r_name;
# Setting the file/class name.
if($par[0]  !~ /^\s*$/){
   $r_name = $par[0];
}else{
   $r_name = $def[0];
}

my $rbs;
# Setting the RBS type.
if($par[1] !~ /^\s*$/){
   $rbs = $par[1];
}else{
   $rbs = $def[1];
}

my $n_b;
# Setting the binding-site number
if($par[2] !~ /^\s*$/){
   $n_b = $par[2];
}else{
   $n_b = $def[2];
}

my $n_rf;
# Setting the regulatory factor number
if($par[3] !~ /^\s*$/){
   $n_rf = $par[3];
}else{
   $n_rf = $def[3];
}

my @rf=();
# Setting rf1 
if($par[4] !~ /^\s*$/){
   $rf[0] = $par[4];
}else{
   $rf[0] = $def[4];
}

# Setting rf2 
if($par[5] !~ /^\s*$/){
   $rf[1] = $par[5];
}else{
   $rf[1] = $def[5];
}

my $c_flag;
# Setting cooperativity flag
if($par[6] !~ /^\s*$/){
   $c_flag = $par[6];
}else{
   $c_flag = $def[6];
}

my $pol_lk_flag;
# Setting PoPS leakage flag.
if($par[7] !~ /^\s*$/){
   $pol_lk_flag = $par[7];
}else{
   $pol_lk_flag = $def[7];
}

my $fw_pol_rt_flag;
# Setting forwards PoPS readthrough flag.
if($par[8] !~ /^\s*$/){
   $fw_pol_rt_flag = $par[8];
}else{
   $fw_pol_rt_flag = $def[8];
}

my $bw_pol_rt_flag;
# Setting backwards PoPS readthrough flag.
if($par[9] !~ /^\s*$/){
   $bw_pol_rt_flag = $par[9];
}else{
   $bw_pol_rt_flag = $def[9];
}

my $k_el;
# Setting k_el value.
if($par[10] !~ /^\s*$/){
   $k_el = $par[10];
}else{
   $k_el = $def[10];
}

my $kd;
# Setting the unique const decay rate value (kd).
if($par[11] !~ /^\s*$/){
   $kd = $par[11];
}else{
   $kd = $def[11];
}

my $k1r;
# Setting k1r value.
if($par[12] !~ /^\s*$/){
   $k1r = $par[12];
}else{
   $k1r = $def[12];
}

my $kq;
# Calculating kq
$kq = $k1r*1000;

my $k_1r;
# Setting k_1r value.
if($par[13] !~ /^\s*$/){
   $k_1r = $par[13];
}else{
   $k_1r = $def[13];
}

my $k2r;
# Setting k2r value.
if($par[14] !~ /^\s*$/){
   $k2r = $par[14];
}else{
   $k2r = $def[14];
}

my $theta1;
# Setting theta1 value.
if($par[15] !~ /^\s*$/){
   $theta1 = $par[15];
}else{
   $theta1 = $def[15];
}

my $csi1;
# Setting csi1 value.
if($par[16] !~ /^\s*$/){
   $csi1 = $par[16];
}else{
   $csi1 = $def[16];
}

my $theta1n;
# Setting theta1n value.
if($par[17] !~ /^\s*$/){
   $theta1n = $par[17];
}else{
   $theta1n = $def[17];
}

my $csi1n;
# Setting csi1n value.
if($par[18] !~ /^\s*$/){
   $csi1n = $par[18];
}else{
   $csi1n = $def[18];
}

my $theta1f;
# Setting theta1f value.
if($par[19] !~ /^\s*$/){
   $theta1f = $par[19];
}else{
   $theta1f = $def[19];
}

my $csi1f;
# Setting csi1f value.
if($par[20] !~ /^\s*$/){
   $csi1f = $par[20];
}else{
   $csi1f = $def[20];
}

my $theta2n;
# Setting theta2n value.
if($par[21] !~ /^\s*$/){
   $theta2n = $par[21];
}else{
   $theta2n = $def[21];
}

my $csi2n;
# Setting csi2n value.
if($par[22] !~ /^\s*$/){
   $csi2n = $par[22];
}else{
   $csi2n = $def[22];
}

my $theta2f;
# Setting theta2f value.
if($par[23] !~ /^\s*$/){
   $theta2f = $par[23];
}else{
   $theta2f = $def[23];
}

my $csi2f;
# Setting csi2f value.
if($par[24] !~ /^\s*$/){
   $csi2f = $par[24];
}else{
   $csi2f = $def[24];
}

my $k2r_lk;
# Setting k_lkr value.
if($par[25] !~ /^\s*$/){
   $k2r_lk = $par[25];
}else{
   $k2r_lk = $def[25];
}

close(IN);

#####################################################################
# Checking the input

print "$r_name \n";

if($n_b > 2){
   die "Error: no more than two b-sites are allowed. \n"
}

if($n_b > 0){
   if($n_rf > $n_b){
	die "Error: regulatory factor number ($n_rf) exceeds the b-site number ($n_b). \n";
   }

   if($n_rf == 0){
	die "Error: at least one regulatory factor should be present. \n"
   }

   if($rf[0] !~/1/){
	die "Error: the regulatory factor associated with site b1 must have index 1. \n"
   }
	
   if($rf[1] =~/1/ && $rf[0] ne $rf[1]){
	die "Error: different regulatory factors must have different indeces. \n"
   }

   if($n_rf == 2 && $rf[0] eq $rf[1]){
	die "Error: regulatory factor number equals two but the same regulatory factor acts on both the b-sites. \n";
   }	

   if($n_b == 2 && $n_rf == 1 && ($rf[0] ne $rf[1])){
  	die "Error: regulatory factor number equals one but two different regulatory factors are present. \n";
   }

   if($n_rf == 2){
	if(($rf[0] =~ /l/ ||  $rf[0] =~ /C/) && ($rf[1] =~ /k/ ||  $rf[1] =~ /I/)){
		die "Error: the configuration ${rf[0]}-${rf[1]} is not allowed. \n";
	}
	if(($rf[0] =~ /k/ ||  $rf[0] =~ /I/) && ($rf[1] =~ /l/ ||  $rf[1] =~ /C/)){
		die "Error: the configuration ${rf[0]}-${rf[1]} is not allowed. \n";
	}
   }	
		
   if($n_b == 2 && $rf[0] eq "l1" && $rf[1] eq "C2"){
	die "Use the configuration C1-l2 instead of l1-C2. \n"
   }

   if($n_b == 2 && $rf[0] eq "k1" && $rf[1] eq "I2"){
        die "Use the configuration I1-k2 instead of k1-I2. \n"
   }
 
}
	
if($n_b == 0 && $n_rf > 0){
    die "Error: no regulatory factors can act on the constitutive RBS (n_b=0). \n";
}

# Turning off cooperativity (if necessary)
if($n_b < 2 && $c_flag eq 'y'){
	$c_flag='n';
}

if($rf[1] =~/l/ && $c_flag eq 'y'){
        $c_flag='n';
}

if($rf[1] =~/k/ && $c_flag eq 'y'){
        $c_flag='n';
}

# Checking readthrough and leakage

# Turning off polymerase leakage and readthrough in c-type RBSs
if($rbs eq 'c'){
  $pol_lk_flag = 'n';
  $fw_pol_rt_flag = 'n';
  $bw_pol_rt_flag = 'n';
}

# Turning off polymerase leakage and readthrough in s-type RBSs
if($rbs eq 's'){
  $pol_lk_flag = 'n';
  $fw_pol_rt_flag = 'n';
  $bw_pol_rt_flag = 'n';
}

# Cooperativity: kinetic rate constants.
if($c_flag eq 'y'){
	if($rf[0] =~/C/ && $rf[1] =~/C/){
		if($theta1f <= $theta1n){
			print "Warning: cooperativity between corepressors implies theta1f > theta1n. \n";
		}
		
                if($theta2f <= $theta2n){
                        print "Warning: cooperativity between corepressors implies theta2f > theta2n. \n";
                }		
		
                if($csi1f >= $csi1n){
                        print "Warning: cooperativity between corepressors implies csi1f < csi1n. \n";
                }

                if($csi2f >= $csi2n){
                        print "Warning: cooperativity between corepressors implies csi2f < csi2n. \n";
                }
	}

        if($rf[0] =~/I/ && $rf[1] =~/I/){
                if($theta1n <= $theta1f){
                        print "Warning: cooperativity between inducers implies theta1n > theta1f. \n";
                }

                if($theta2n <= $theta2f){
                        print "Warning: cooperativity between inducers implies theta2n > theta2f. \n";
                }

                if($csi1n >= $csi1f){
                        print "Warning: cooperativity between inducers implies csi1n < csi1f. \n";
                }

                if($csi2n >= $csi2f){
                        print "Warning: cooperativity between inducers implies csi2n < csi2f. \n";
                }
        }
}

if($c_flag eq 'n'){
	if($rf[0] =~/C/ && $rf[1] =~/C/){
		if($theta1f != $theta1n){
			$theta1f=$theta1n;
			print "Warning: theta1f has been set equal to theta1n. Cooperativity is off. \n"
		}

                if($theta2f != $theta2n){
                        $theta2f=$theta1n;
                        print "Warning: theta2f has been set equal to theta2n. Cooperativity is off. \n"
                }
		
                if($csi1f != $csi1n){
                        $csi1f=$csi1n;
                        print "Warning: csi1f has been set equal to csi1n. Cooperativity is off. \n"
                }

                if($csi2f != $csi2n){
                        $csi2f=$csi1n;
                        print "Warning: csi2f has been set equal to csi2n. Cooperativity is off. \n"
                }
	}

        if($rf[0] =~/I/ && $rf[1] =~/I/){
                if($theta1n != $theta1f){
                        $theta1n=$theta1f;
                        print "Warning: theta1n has been set equal to theta1f. Cooperativity is off. \n"
                }

                if($theta2n != $theta2f){
                        $theta2n=$theta1f;
                        print "Warning: theta2n has been set equal to theta2f. Cooperativity is off. \n"
                }

                if($csi1n != $csi1f){
                        $csi1n=$csi1f;
                        print "Warning: csi1n has been set equal to csi1f. Cooperativity is off. \n"
                }

                if($csi2n != $csi2f){
                        $csi2n=$csi1f;
                        print "Warning: csi2n has been set equal to csi2f. Cooperativity is off. \n"
                }
        }
}

print "b_sites: $n_b \n";
print "regulatory factors: $n_rf \n";
print "cooperativity: $c_flag \n";
print "******************************* \n\n";
#####################################################################
# b (binding) where effectors or sRNAs can bind. If two, both must be on to allow ribosome binding to the RBS

################### RBS species generation

our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes
my @b_adapters=(); # contains exchanged signal carriers

my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species 
my %h_b_adapters=(); # associates each "b" adapter to the corresponding adapter-flux

my $n_st;
my @states=();
# Number of RBS states
$n_st=2**$n_b;
if($n_b == 0){
	$states[1] = "b_free";
}


# RBS state generation.
# Each binding-site can be in two states: on (n) or off (f)
# The order is: b1nb2n; b1nb2f; b1fb2n; b1fb2f.

my $st_on;
my $st_off;
my $counter;

for($i=1; $i<$n_b+1; $i++){
   $st_on="n";
   $st_off="f";
   $counter=1;
   for($j=1; $j<$n_st+1;$j++){
      $states[$j]=$states[$j]."b$i$st_on";
      if($counter == 2**($n_b-$i)){
         my $tmp=$st_on;
         $st_on=$st_off;
         $st_off=$tmp;
         $counter=0;
      }
      $counter++;
   }
}

# Writing the RBS states into the species array
for($i=1;$i<$n_st+1;$i++){
    push(@species,$states[$i]); 
    push(@storages,$states[$i]);
}

# Ribosome-RBS complex(es)
my @rb;

if($n_b == 0){
  $rb[1]="rb";
}

if($n_b > 0){
    $rb[1]="r".$states[1];
}

# Writing the ribosome-promoter state into the species array
push(@species,$rb[1]);
push(@storages,$rb[1]);

# Writing free ribosome into the species array (adapter flux)
push(@species,"r_free");
push(@b_adapters,"r_free");
$h_b_adapters{"r_free"}="rips_b";

# Writing regulatory factors into the species array (adapter flux)
if($n_b > 0){
  for($i=0;$i<$n_rf;$i++){
    push(@species,$rf[$i]);
    push(@b_adapters,$rf[$i]);
    my $id=$i+1;
    if($rf[$i] =~ /l/ || $rf[$i] =~ /k/){
      $h_b_adapters{$rf[$i]}="rnaps_b_$id";
    }else{
      $h_b_adapters{$rf[$i]}="sips_b_$id";
    }
  }
}

# Writing the polymerase-RBS complex species into the species array
push(@species,"polb");
push(@storages,"polb");

# Writing the complexes due to ribosome readthrough - s-type RBS only
if($rbs eq 's'){
  push(@species,"rrtq");               # queued readthrough ribosomes
  push(@storages,"rrtq");

  push(@species,"rrt$states[1]");      # rt_ribosomes - RBS complex
  push(@storages,"rrt$states[1]");
}

# Writing the fictitious species (output) into the species array and the out_adapters array
# These adapters have the "in" terminal connected to a reaction, and the "out" one to a part terminal
push(@species,"r_cl");
push(@out_adapters,"r_cl");
$h_out_adapters{"r_cl"}="rips_out";

push(@species,"pol_el");
push(@out_adapters,"pol_el");
$h_out_adapters{"pol_el"}="pops_out";

# Leakage ribosomes 
if($n_b > 0){
  push(@species,"r_lk");
  push(@out_adapters,"r_lk");
  $h_out_adapters{"r_lk"}="rips_lk";
}

# Readthrough ribosomes -- produced only by s-type RBSs 
if($rbs eq 's'){
    push(@species,"r_rt");
    push(@out_adapters,"r_rt");
    $h_out_adapters{"r_rt"}="rips_rt_out";
}

# Assigning the non-species (input) entities to in_adapters
# These adapters have the "in" terminal connected to a part terminal and the "out" one to a storage-intra (species)
push(@in_adapters,"pops_in");
$h_in_adapters{"pops_in"}="polb";

# Incoming polymerases (leakage) - Possible only with p-type RBSs 
if($rbs eq 'p' && $pol_lk_flag eq 'y' ){
push(@in_adapters,"pops_lk");
  if($n_b == 0){
    	$h_in_adapters{"pops_lk"}=$states[1];	
  }if($n_b == 1 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
	$h_in_adapters{"pops_lk"}=$states[1];
  }if($n_b == 1 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
	$h_in_adapters{"pops_lk"}=$states[2];
  }if($n_b == 2 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
	$h_in_adapters{"pops_lk"}=$states[1];
  }if($n_b == 2 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
	$h_in_adapters{"pops_lk"}=$states[4];
  }
}

# Incoming polymerases (readthrough) - Possible only with p-type RBSs
#if(0){
if($rbs eq 'p' && $bw_pol_rt_flag eq 'y'){
push(@in_adapters,"pops_rt_bw");
  if($n_b == 0){
        $h_in_adapters{"pops_rt_bw"}=$states[1];
  }if($n_b == 1 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
        $h_in_adapters{"pops_rt_bw"}=$states[1];
  }if($n_b == 1 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
        $h_in_adapters{"pops_rt_bw"}=$states[2];
  }if($n_b == 2 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
        $h_in_adapters{"pops_rt_bw"}=$states[1];
  }if($n_b == 2 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
        $h_in_adapters{"pops_rt_bw"}=$states[4];
  }
}

if($rbs eq 'p' && $fw_pol_rt_flag eq 'y'){
push(@in_adapters,"pops_rt_fw");
  if($n_b == 0){
        $h_in_adapters{"pops_rt_fw"}=$states[1];
  }if($n_b == 1 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
        $h_in_adapters{"pops_rt_fw"}=$states[1];
  }if($n_b == 1 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
        $h_in_adapters{"pops_rt_fw"}=$states[2];
  }if($n_b == 2 && ($rf[0] =~ /l/ || $rf[0] =~ /C/)){
        $h_in_adapters{"pops_rt_fw"}=$states[1];
  }if($n_b == 2 && ($rf[0] =~ /k/ || $rf[0] =~ /I/)){
        $h_in_adapters{"pops_rt_fw"}=$states[4];
  }

}


# Incoming ribosomes (readthrough) - Possible only with s-type RBSs 
if($rbs eq 's'){
push(@in_adapters,"rips_rt_in");
$h_in_adapters{"rips_rt_in"}="rrtq";
}

# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
    $h_species{$species[$i]}=$i;
}

# Opening the output file containing all the RBS information
my $outfile;
$outfile=$r_name."_reactions.txt";
open(OUT,">$outfile");

# Writing RBS structure and species in the output file
print OUT "$r_name \n";
print OUT "n_b: $n_b \n";
for($i=0;$i<$n_rf;$i++){
  my $id=$i+1;	
  print OUT "RF$id: $rf[$i] \n";
}

print OUT "RBS preceded by: $rbs \n"; 
print OUT "Cooperativity: $c_flag \n";
print OUT "Polymerase leakage: $pol_lk_flag \n";
print OUT "Forwards polymerase readthrough: $fw_pol_rt_flag \n";
print OUT "Backwards polymerase readthrough: $bw_pol_rt_flag \n";

print OUT "$r_name species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

###########################
# Reaction generation
our @reactions=();
my %educts=();
my %products=();

my %values=();   # contains the rate (constant) values

# Regulatory factors - b sites reactions

# No b-site
if($n_b == 0){
  # States decay
  push(@reactions,"kd1");
  $educts{$reactions[$#reactions]}=[$states[1]];
  $products{$reactions[$#reactions]}=[];
  $values{$reactions[$#reactions]}=$kd;
}

# One-b-site-containing RBS
if($n_b == 1){
  # Regulatory factors binding/unbinding the RBS
  push(@reactions,"theta1");
  if($rf[0] =~ /l/ || $rf[0] =~ /C/){
    $educts{$reactions[$#reactions]}=[$rf[0],$states[1]];
    $products{$reactions[$#reactions]}=[$states[2]];
    $values{$reactions[$#reactions]}=$theta1;
  }elsif($rf[0] =~ /k/ || $rf[0] =~ /I/){
    $educts{$reactions[$#reactions]}=[$rf[0],$states[2]];
    $products{$reactions[$#reactions]}=[$states[1]];
    $values{$reactions[$#reactions]}=$theta1;
  }

  push(@reactions,"csi1");
  if($rf[0] =~ /l/ || $rf[0] =~ /C/){
    $educts{$reactions[$#reactions]}=[$states[2]];
    $products{$reactions[$#reactions]}=[$rf[0],$states[1]];
    $values{$reactions[$#reactions]}=$csi1;
  }elsif($rf[0] =~ /k/ || $rf[0] =~ /I/){
    $educts{$reactions[$#reactions]}=[$states[1]];
    $products{$reactions[$#reactions]}=[$rf[0],$states[2]];
    $values{$reactions[$#reactions]}=$csi1;
  }


  # States decay 
  push(@reactions,"kd1");
  $educts{$reactions[$#reactions]}=[$states[1]];
  if($rf[0] =~ /l/ || $rf[0] =~ /C/ || $rf[0] =~ /k/){
    $products{$reactions[$#reactions]}=[];
  }elsif($rf[0] =~ /I/){ 
    $products{$reactions[$#reactions]}=[$rf[0]];
  }  
  $values{$reactions[$#reactions]}=$kd;
  
  push(@reactions,"kd2");
  $educts{$reactions[$#reactions]}=[$states[2]];
  if($rf[0] =~ /l/ || $rf[0] =~ /I/ || $rf[0] =~ /k/){
    $products{$reactions[$#reactions]}=[];
  }elsif($rf[0] =~ /C/){
    $products{$reactions[$#reactions]}=[$rf[0]];
  }
    $values{$reactions[$#reactions]}=$kd;
}

# Two-b-site-containing RBS

if($n_b == 2){
  # Regulatory factors binding/unbinding the RBS
      push(@reactions,"theta1n");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$rf[0],$states[1]];
	$products{$reactions[$#reactions]}=[$states[3]];
      }else{
	$educts{$reactions[$#reactions]}=[$rf[0],$states[3]];
	$products{$reactions[$#reactions]}=[$states[1]];
      }
      $values{$reactions[$#reactions]}=$theta1n;

      push(@reactions,"csi1n");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=[$rf[0],$states[1]];
      }else{
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=[$rf[0],$states[3]];
      }
      $values{$reactions[$#reactions]}=$csi1n;

      push(@reactions,"theta1f");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$rf[0],$states[2]];
	$products{$reactions[$#reactions]}=[$states[4]];
      }else{
	$educts{$reactions[$#reactions]}=[$rf[0],$states[4]];
	$products{$reactions[$#reactions]}=[$states[2]];
      }
      $values{$reactions[$#reactions]}=$theta1f;

      push(@reactions,"csi1f");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$rf[0],$states[2]];
      }else{
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=[$rf[0],$states[4]];
      }
      $values{$reactions[$#reactions]}=$csi1f;

      push(@reactions,"theta2n");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$rf[1],$states[1]];
	$products{$reactions[$#reactions]}=[$states[2]];
      }else{
	$educts{$reactions[$#reactions]}=[$rf[1],$states[2]];
	$products{$reactions[$#reactions]}=[$states[1]];
      }
      $values{$reactions[$#reactions]}=$theta2n;

      push(@reactions,"csi2n");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=[$rf[1],$states[1]];
      }else{
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=[$rf[1],$states[2]];
      }
      $values{$reactions[$#reactions]}=$csi2n;       

      push(@reactions,"theta2f");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$rf[1],$states[3]];
	$products{$reactions[$#reactions]}=[$states[4]];
      }else{
	$educts{$reactions[$#reactions]}=[$rf[1],$states[4]];
	$products{$reactions[$#reactions]}=[$states[3]];
      }
      $values{$reactions[$#reactions]}=$theta2f;

      push(@reactions,"csi2f");
      if($rf[0] =~ /l/ || $rf[0] =~ /C/){
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$rf[1],$states[3]];
      }else{
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=[$rf[1],$states[4]];
      }
      $values{$reactions[$#reactions]}=$csi2f;      

      # States decay
      push(@reactions,"kd1");
      $educts{$reactions[$#reactions]}=[$states[1]];
      $products{$reactions[$#reactions]}=[];
      if($rf[0] =~ /I/){
	push(@{$products{$reactions[$#reactions]}},"I1")
      }
      if($rf[1] =~ /I/){
	push(@{$products{$reactions[$#reactions]}},"I2")
      }
      $values{$reactions[$#reactions]}=$kd;

      push(@reactions,"kd2");
      $educts{$reactions[$#reactions]}=[$states[2]];
      $products{$reactions[$#reactions]}=[];
      if($rf[0] =~ /I/){
	push(@{$products{$reactions[$#reactions]}},"I1")
      }
      if($rf[1] =~ /C/){
	push(@{$products{$reactions[$#reactions]}},"C2")
      }
      $values{$reactions[$#reactions]}=$kd;

      push(@reactions,"kd3");
      $educts{$reactions[$#reactions]}=[$states[3]];
      $products{$reactions[$#reactions]}=[];
      if($rf[0] =~ /C/){
	push(@{$products{$reactions[$#reactions]}},"C1")
      }
      if($rf[1] =~ /I/){
	push(@{$products{$reactions[$#reactions]}},"I2")
      }
      $values{$reactions[$#reactions]}=$kd;

      push(@reactions,"kd4");
      $educts{$reactions[$#reactions]}=[$states[4]];
      $products{$reactions[$#reactions]}=[];
      if($rf[0] =~ /C/){
	push(@{$products{$reactions[$#reactions]}},"C1")
      }
      if($rf[1] =~ /C/){
	push(@{$products{$reactions[$#reactions]}},"C2")
      }
      $values{$reactions[$#reactions]}=$kd;
    }

# Ribosome-RBS reactions 
push(@reactions,"k1r");
$educts{$reactions[$#reactions]}=[$states[1],"r_free"];
$products{$reactions[$#reactions]}=[$rb[1]];
$values{$reactions[$#reactions]}=$k1r;

push(@reactions,"k_1r");
$educts{$reactions[$#reactions]}=[$rb[1]];
$products{$reactions[$#reactions]}=[$states[1],"r_free"];
$values{$reactions[$#reactions]}=$k_1r;

push(@reactions,"k2r");
$educts{$reactions[$#reactions]}=[$rb[1]];
$products{$reactions[$#reactions]}=[$states[1],"r_cl"];  
$values{$reactions[$#reactions]}=$k2r;

# Ribosome-b-site complex decay
if($n_b == 0){
    push(@reactions,"k_drb");
    $educts{$reactions[$#reactions]}=[$rb[1]];
    $products{$reactions[$#reactions]}=["r_free"];
    $values{$reactions[$#reactions]}=$kd;
  }

if($n_b == 1){
  push(@reactions,"k_dr1");
  $educts{$reactions[$#reactions]}=[$rb[1]];
  if($rf[0] =~ /I/){
    $products{$reactions[$#reactions]}=[$rf[0],"r_free"];
  }else{
    $products{$reactions[$#reactions]}=["r_free"];
  }
  $values{$reactions[$#reactions]}=$kd;
}

if($n_b == 2){
  push(@reactions,"k_dr1");
  $educts{$reactions[$#reactions]}=[$rb[1]];
  $products{$reactions[$#reactions]}=["r_free"];
  if($rf[0] =~ /I/){
    push(@{$products{$reactions[$#reactions]}},"I1")
  }
  if($rf[1] =~ /I/){
    push(@{$products{$reactions[$#reactions]}},"I2")
  }
  $values{$reactions[$#reactions]}=$kd;
}

# Leakage (output)

if($n_b == 1){
  push(@reactions,"k2r_lk");
  $educts{$reactions[$#reactions]}=[$states[2]];
  $products{$reactions[$#reactions]}=["r_lk",$states[2]];
  $values{$reactions[$#reactions]}=$k2r_lk;
}

if($n_b == 2){
  push(@reactions,"k22r_lk");
  $educts{$reactions[$#reactions]}=[$states[2]];
  $products{$reactions[$#reactions]}=["r_lk",$states[2]];
  $values{$reactions[$#reactions]}=$k2r_lk;

  push(@reactions,"k23r_lk");
  $educts{$reactions[$#reactions]}=[$states[3]];
  $products{$reactions[$#reactions]}=["r_lk",$states[3]];
  $values{$reactions[$#reactions]}=$k2r_lk;

  push(@reactions,"k24r_lk");
  $educts{$reactions[$#reactions]}=[$states[4]];
  $products{$reactions[$#reactions]}=["r_lk",$states[4]];
  $values{$reactions[$#reactions]}=$k2r_lk;
}

# Polymerase starting the elongation phase
push(@reactions,"k_el");
$educts{$reactions[$#reactions]}=["polb"];
$products{$reactions[$#reactions]}=["pol_el"];
if($n_b == 0){
 push(@{$products{$reactions[$#reactions]}},$states[1]);	
}elsif($n_b == 1){
  if($rf [0] =~ /l/ || $rf [0] =~ /C/){
     push(@{$products{$reactions[$#reactions]}},$states[1]);
  }else{
     push(@{$products{$reactions[$#reactions]}},$states[2]);
  }
}elsif($n_b == 2){
  if($rf [0] =~ /l/ || $rf [0] =~ /C/){
     push(@{$products{$reactions[$#reactions]}},$states[1]);
  }else{
     push(@{$products{$reactions[$#reactions]}},$states[4]);
  }
}	 	
$values{$reactions[$#reactions]}=$k_el;

# Queued ribosome reaction
if($rbs eq 's'){
push(@reactions,"kq");
$educts{$reactions[$#reactions]}=["rrtq",$states[1]];
$products{$reactions[$#reactions]}=["rrt$states[1]"];
$values{$reactions[$#reactions]}=$kq;

if($n_b > 0){
 push(@reactions,"kq_f2");
 $educts{$reactions[$#reactions]}=["rrtq",$states[2]];
 $products{$reactions[$#reactions]}=["r_free",$states[2]];
 $values{$reactions[$#reactions]}=$kq;
 
 if($n_b == 2){
  push(@reactions,"kq_f3");
  $educts{$reactions[$#reactions]}=["rrtq",$states[3]];
  $products{$reactions[$#reactions]}=["r_free",$states[3]];
  $values{$reactions[$#reactions]}=$kq;

  push(@reactions,"kq_f4");
  $educts{$reactions[$#reactions]}=["rrtq",$states[4]];
  $products{$reactions[$#reactions]}=["r_free",$states[4]];
  $values{$reactions[$#reactions]}=$kq;
 }
}

push(@reactions,"k2r_rt");
$educts{$reactions[$#reactions]}=["rrt$states[1]"];
$products{$reactions[$#reactions]}=["r_rt",$states[1]];
$values{$reactions[$#reactions]}=$k2r;
}

# Writing all the reactions on the output file
print OUT "$r_name reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}


print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
#    if($reactions[$i] !~ /INP/){
      $h_reactions{$reactions[$i]}=$i;
#    }
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
    if($LM[$row][$col] eq '0'){ # change due to the leakage
       $LM[$row][$col]=$letters[$counter];
    }else{
       $LM[$row][$col]="$LM[$row][$col]"."&".$letters[$counter];
    }
    $counter++;
  }



}

#print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$r_name.".mdl";
open (MDL,">$filename");

# Loading the libraries
 #print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$r_name\"
  :super-classes (\"module\")
  :icon \"rbs.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
    $cc=0.0;
print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"exc_r\"
    :is-eq-to \"rips_b.in\"
    :geometry-side \"TOP\"
    :geometry-position \"0.1\")
   (\"out_r\"
    :is-eq-to \"rips_out.out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.9\")
   (\"in_pol\"
    :is-eq-to \"pops_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.9\")
   (\"out_pol\"
    :is-eq-to \"pops_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.9\")
";

if($n_b > 0){
print MDL
"   (\"out_r_lk\"
    :is-eq-to \"rips_lk.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.1\")
";
}

if($rbs eq 'p' && $pol_lk_flag eq 'y'){
print MDL 
"   (\"in_pol_lk\"
    :is-eq-to \"pops_lk.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.1\")
";
}

if($rbs eq 'p' && $bw_pol_rt_flag eq 'y'){
print MDL # pops_rt_bw.i 
"   (\"in_pol_rt_bw\"
    :is-eq-to \"pops_rt_bw.in\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.5\")
";
}

if($rbs eq 'p' && $fw_pol_rt_flag eq 'y'){
print MDL # pops_rt_fw.in
"   (\"in_pol_rt_fw\"
    :is-eq-to \"pops_rt_fw.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.5\")
";
}

if($rbs eq 's'){
print MDL 
"   (\"in_r_rt\"
    :is-eq-to \"rips_rt_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.1\")
   (\"out_r_rt\"
    :is-eq-to \"rips_rt_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.5\")
";
}

my @side=("LEFT","BOTTOM");
my $co;

if($n_b > 0){
  for($i=0;$i<$n_rf;$i++){
    $co=0.1;
    my $pd=$i+1;
    if($rf[$i] =~ /l/ || $rf[$i] =~ /k/){
print MDL
"   (\"exc_rf_$pd\"
    :is-eq-to \"rnaps_b_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.1\")
";
     }else{
print MDL
"   (\"exc_rf_$pd\"
    :is-eq-to \"sips_b_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.1\")
";
     }
  }
}

print MDL 
"   )
";


# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

foreach $key (keys %h_out_adapters){
  my $apt = $h_out_adapters{$key};
print MDL 
"   (\"$h_out_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}

#b adapters
foreach $key (keys %h_b_adapters){
  my $apt = $h_b_adapters{$key};
print MDL
"   (\"$h_b_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}


# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    $class{$reactions[$i]}=$cl;
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
      if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
        if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] !~ /\&/){
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
        }else{
          my @set = split('&',$LM[$h_species{$storages[$i]}][$h_reactions{$key}]);

print MDL " \"$key.$set[0]\"";
print MDL " \"$key.$set[1]\"";
        }
      }
    }
    foreach $key (keys %h_in_adapters){
       if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
       }
    }

    if($storages[$i] eq "rq"){
print MDL " \"pops_cl_in.out\"";
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@out_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_out_adapters{$out_adapters[$i]}.in\""; # always IN terminal
    foreach $key (keys %h_reactions){ # fictitious reactions
      if($LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }

print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@b_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_b_adapters{$b_adapters[$i]}.out\""; # always OUT terminal
    foreach $key (keys %h_reactions){ # fictitious reactions
      if($LM[$h_species{$b_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$b_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }

print MDL "))
";
    $c_lk++;
}





print MDL
"  ))
";


# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}
