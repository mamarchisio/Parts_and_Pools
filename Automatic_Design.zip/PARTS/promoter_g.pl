#! /usr/bin/perl
# ATTENTION: since only the promoter-promoter system has input fluxes, this file is slightly different from the other part generators.
use strict;

my $i;
my $j;

my @par=@ARGV;

my @def=("promoter",0,0,"Ra1","Ra2","I1","I2",'n','n','n','n',1.0e-09,1.0e9,0.1,1.0e9,0.1,1.0e9,0.1,1.0e9,0.1,1.0e9,0.1,0.00116,0.00116,1.0e6,1.0e6,1.0e6,0.01,0.5,1.0e6,0.003,1.5,1.0e-5,'n');

my $p_name;
# Setting file/class name.
if($par[0] !~ /^\s*$/){
   $p_name = $par[0];
}else{
   $p_name = $def[0];
}

my $n_op;
# Setting n_op value.
if($par[1] !~ /^\s*$/){
   $n_op = $par[1];
}else{
   $n_op = $def[1];
}

my $n_tf;
# Setting n_tf.
if($par[2] !~ /^\s*$/){
   $n_tf = $par[2];
}else{
   $n_tf = $def[2];
}

my @tf=();
# Setting TF1.
if($par[3] !~ /^\s*$/){
   $tf[0] = $par[3];
}else{
   $tf[0] = $def[3];
}

# Setting TF2.
if($par[4] !~ /^\s*$/){
   $tf[1] = $par[4];
}else{
   $tf[1] = $def[4];
}

my @sg=();
# Setting S1.
if($par[5] !~ /^\s*$/){
   $sg[0] = $par[5];
}else{
   $sg[0] = $def[5];
}

# Setting S2.
if($par[6] !~ /^\s*$/){
   $sg[1] = $par[6];
}else{
   $sg[1] = $def[6];
}

my $cp_flag;
# Setting cp_flag.
if($par[7] !~ /^\s*$/){
   $cp_flag = $par[7];
}else{
   $cp_flag = $def[7];
}

my $syn_flag;
# Setting syn_flag.
if($par[8] !~ /^\s*$/){
   $syn_flag = $par[8];
}else{
   $syn_flag = $def[8];
}

my $rt_flag;
# Setting rt_flag.
if($par[9] !~ /^\s*$/){
   $rt_flag = $par[9];
}else{
   $rt_flag = $def[9];
}

my $pr_flag;
# Setting pr_flag
if($par[10] !~ /^\s*$/){
   $pr_flag = $par[10];
}else{
   $pr_flag = $def[10];
}

my $p_free_v;
# Setting p_free_v.
if($par[11] !~ /^\s*$/){
   $p_free_v = $par[11];
}else{
   $p_free_v = $def[11];
}

my $alpha_v;
# Setting alpha_v.
if($par[12] !~ /^\s*$/){
   $alpha_v = $par[12];
}else{
   $alpha_v = $def[12];
}

my $beta_v;
# Setting beta_v.
if($par[13] !~ /^\s*$/){
   $beta_v = $par[13];
}else{
   $beta_v = $def[13];
}

my $alpha1f_v;
# Setting alpha1f_v.
if($par[14] !~ /^\s*$/){
   $alpha1f_v = $par[14];
}else{
   $alpha1f_v = $def[14];
}

my $beta1f_v;
# Setting beta1f_v.
if($par[15] !~ /^\s*$/){
   $beta1f_v = $par[15];
}else{
   $beta1f_v = $def[15];
}

my $alpha1t_v;
# Setting alpha1t_v.
if($par[16] !~ /^\s*$/){
   $alpha1t_v = $par[16];
}else{
   $alpha1t_v = $def[16];
}

my $beta1t_v;
# Setting beta1t_v.
if($par[17] !~ /^\s*$/){
   $beta1t_v = $par[17];
}else{
   $beta1t_v = $def[17];
}

my $alpha2f_v;
# Setting alpha2f_v.
if($par[18] !~ /^\s*$/){
   $alpha2f_v = $par[18];
}else{
   $alpha2f_v = $def[18];
}

my $beta2f_v;
# Setting beta2f_v.
if($par[19] !~ /^\s*$/){
   $beta2f_v = $par[19];
}else{
   $beta2f_v = $def[19];
}

my $alpha2t_v;
# Setting alpha2t_v.
if($par[20] !~ /^\s*$/){
   $alpha2t_v = $par[20];
}else{
   $alpha2t_v = $def[20];
}

my $beta2t_v;
# Setting beta2t_v.
if($par[21] !~ /^\s*$/){
   $beta2t_v = $par[21];
}else{
   $beta2t_v = $def[21];
}

my $k_d1_v;
# Setting k_d1_v.
if($par[22] !~ /^\s*$/){
   $k_d1_v = $par[22];
}else{
   $k_d1_v = $def[22];
}

my $k_d2_v;
# Setting k_d2_v.
if($par[23] !~ /^\s*$/){
   $k_d2_v = $par[23];
}else{
   $k_d2_v = $def[23];
}

my $gamma1_v;
# Setting gamma1_v.
if($par[24] !~ /^\s*$/){
   $gamma1_v = $par[24];
}else{
   $gamma1_v = $def[24];
}

my $gamma2_v;
# Setting gamma2_v.
if($par[25] !~ /^\s*$/){
   $gamma2_v = $par[25];
}else{
   $gamma2_v = $def[25];
}

my $k1_v;
# Setting k1_v.
if($par[26] !~ /^\s*$/){
   $k1_v = $par[26];
}else{
   $k1_v = $def[26];
}

# Calculating k_q_v
my $k_q_v = $k1_v*1000;

my $k_1_v;
# Setting k_1_v.
if($par[27] !~ /^\s*$/){
   $k_1_v = $par[27];
}else{
   $k_1_v = $def[27];
}

# Calculating $k_dq_v
my $k_dq_v = $k_1_v*1000;

my $k2_v;
# Setting k2_v.
if($par[28] !~ /^\s*$/){
   $k2_v = $par[28];
}else{
   $k2_v = $def[28];
}

my $k1sa_v;
# Setting k1sa_v.
if($par[29] !~ /^\s*$/){
   $k1sa_v = $par[29];
}else{
   $k1sa_v = $def[29];
}
my $k_1sa_v;
# Setting k_1sa_v.
if($par[30] !~ /^\s*$/){
   $k_1sa_v = $par[30];
}else{
   $k_1sa_v = $def[30];
}

my $k2sa_v;
# Setting k2sa_v.
if($par[31] !~ /^\s*$/){
   $k2sa_v = $par[31];
}else{
   $k2sa_v = $def[31];
}

my $k2_lk_v;
# Setting k2_lk_v.
if($par[32] !~ /^\s*$/){
   $k2_lk_v = $par[32];
}else{
   $k2_lk_v = $def[32];
}

my $comp_flag;
# Setting comp_flag
if($par[33] !~ /^\s*$/){
   $comp_flag = $par[33];
}else{
   $comp_flag = $def[33];
}

##########################################

# Input checking

print "$p_name \n";
my $n_sg;

if($n_op > 2){
   die "No more than two operators are allowed. \n";
}

if($n_op >0){
   if($n_tf > $n_op){
      die "Transcription factor number ($n_tf) exceeds the operator number ($n_op). \n";
   }
   if($n_tf == 0){
      die "Transcription factor number must be equal to 1 or 2. \n";
   }


# Setting the signal number equal to the TF number.
   $n_sg = $n_tf;

   if($n_op == 2){
      if($tf[0] =~/A/ && $tf[1] =~/R/){
	 die "The configuration A1-R2 is not allowed. \n";
      }
   }

# Checking the signals, TFs and operators.
# Allowed signals are: I1,I2,C1,C2,N1,N2.
   if(!($tf[0] =~/1/ || $sg[0] =~/1/)){
      print "Operator 1 is associated either with a TF or with a signal whose index is 2. Your setting was: \n";
      print "O1 --> $tf[0] --> $sg[0]\n";
      die "\n";
   }

   if($n_op == 2){
      if($tf[1] =~/2/ && !($sg[1] =~/2/)){
	 die "A TF and its signal must have the same index. Error on operator 2: $tf[1] --> $sg[1].\n";
      }

      if($tf[1] =~/1/ && !($sg[1] =~/1/)){
	 die "A TF and its signal must have the same index. Error on operator 2: $tf[1] --> $sg[1].\n";
      }
   }
}

#print "TFFFFFF @tf \n";
# Only active TFs can enter the promoter
#for($i=0;$i<$n_tf;$i++){
#   if($tf[$i] =~ /i/){
#	die "Inactive transcription factors are not allowed. \n"
#   }
#}

for($i=1; $i<$n_op+1; $i++){
   if($sg[$i-1] =~/I/ && !($tf[$i-1] =~/Ra/  || $tf[$i-1] =~/Ai/)){
	 die "Error on operator $i: $sg[$i-1] and $tf[$i-1] are not consistent. \n";
   }

   if($sg[$i-1] =~/C/ && !($tf[$i-1] =~/Aa/ || $tf[$i-1] =~/Ri/)){
	 die "Error on operator $i: $sg[$i-1] and $tf[$i-1] are not consistent. \n";
   }

   if($sg[$i-1] =~/N/ && !($tf[$i-1] =~/Ra/ || $tf[$i-1] =~/Aa/)){
         die "Error on operator $i: $sg[$i-1] and $tf[$i-1] are not consistent. \n";
   }
}

if($n_op == 2 && $n_tf == 1){
   if($tf[0] ne $tf[1]){
      die "Error on TF number: $tf[0] different from $tf[1] but TF number = $n_tf. \n";
   }
   if($sg[0] ne $sg[1]){
      die "Error on TF number: $sg[0] different from $sg[1] but Signal (i.e. TF) number = $n_tf. \n";
   }
}

my @tf_a=();		# initializing the array of active TF
for($i=1; $i<$n_op+1; $i++){
	$tf_a[$i-1]=$tf[$i-1];
	if($tf[$i-1] =~ /i/){
		$tf_a[$i-1] =~ s/i/a/;
	}
} 

if($n_tf == 2 && $tf[0] eq $tf[1]){
   die "Error on TF number: the same TF has been specified twice: set n_tf=1. \n";
}

# Setting cooperativity flags.
my $r_cp_flag = 'n';
my $a_cp_flag = 'n';

if($n_op < 2 && $cp_flag eq 'y'){
   die "Cooperativity requires two operators. \n";
}

if($n_op == 2 && $cp_flag eq 'y'){
   if($tf[0] =~/R/ && $tf[1] =~/R/){
      $r_cp_flag = 'y';
   }elsif($tf[0] =~/A/ && $tf[1] =~/A/){
      $a_cp_flag = 'y';
   }else{
      print "Error: two different TFs cannot interact cooperatively. \n";
      die "Set cooperativity equal to 'n' or change TFs. \n";
   }
}

# Checking synergistic activation.
if($n_op < 2 && $syn_flag eq 'y'){
   die "Synergistic interaction possible only with two operators. \n";
}

if($n_op == 2 && $syn_flag eq 'y'){
   if($tf[0] =~/R/ || $tf[1] =~/R/){
      print "Synergistic activation can not take place with repressors. \n";
      die "Set synergistic activation equal to 'n' or change TFs \n";
   }
   if($cp_flag eq 'y'){
      print "Cooperativity and synergistic activation cannot co-exist.\n";
      die "Set either cooperativity or synergistic activation equal to 'n'. \n";
   }
}

if($n_op == 2){
   if($tf[0] =~/A/ && $tf[1] =~/A/){
      if($a_cp_flag eq 'n' && $syn_flag eq 'n'){
	 die "Cooperativity or synergistic activation must be present between two activators. \n";
	 die "Set either cooperativity or synergistic activation equal to 'y'. \n";
      }
   }
}

# Checking input signals
if($rt_flag eq 'y' && $pr_flag eq 'y'){
  die "Error: a promoter can be preceded either by a terminator or by another promoter. You set both \"readthrough\" and \"promoter flag\" to 'y'. \n";
}

# Checking alpha and beta values.
# alpha1 and beta1 depend on the state of operator 2 only in case of
# cooperativity between activators.
if($a_cp_flag ne 'y' && $n_op == 2){
	if($tf[0] =~/A/ && $tf[1] =~/A/){
   		if($alpha1t_v != $alpha1f_v){
      			$alpha1t_v=$alpha1f_v;
      			print "Warning: alpha1t and alpha1f have been set to same value (alpha1f) \n";
      			print "You set \"cooperativity\" to 'n' \n";
   		}

   		if($beta1t_v != $beta1f_v){
      			$beta1t_v=$beta1f_v;
      			print "Warning: beta1t and beta1f have been set to same value (beta1f) \n";
      			print "You set \"cooperativity\" to 'n' \n";
   		}
	}
}


# alpha2 and beta2 depend on the state of operator 1 only in case of
# cooperativity between repressors.
if($r_cp_flag ne 'y' && $n_op == 2){
	if($tf[0] =~/R/ && $tf[1] =~/R/){
	   	if($alpha2t_v != $alpha2f_v){
      			$alpha2t_v=$alpha2f_v;
      			print "Warning: alpha2t and alpha2f have been set to same value (alpha2f) \n";
      			print "You set \"cooperativity\" to 'n' \n";
   		}

   		if($beta2t_v != $beta2f_v){
      			$beta2t_v=$beta2f_v;
      			print "Warning: beta2t and beta2f have been set to same value (beta2f) \n";
      			print "You set \"cooperativity\" to 'n' \n";
   		}
	}
}


# When there is cooperativity between repressors it is expected that:
# alpha2t > alpha2f and beta2t < beta2f
if($r_cp_flag eq 'y' && $n_op == 2){
   if($alpha2t_v <= $alpha2f_v){
      print "Warning: alpha2t <= alpha2f: this is not a cooperative behavior.\n";
      print "You set: cooperativity = $cp_flag \n";
   }

   if($beta2t_v >= $beta2f_v){
      print "Warning: beta2t >= beta2f: this is not a cooperative behavior.\n";
      print "You set: cooperativity = $cp_flag \n";
   }
}


# When there is cooperativity between activators it is expected that:
# alpha1t > alpha1f and beta1t < beta1f
if($a_cp_flag eq 'y' && $n_op == 2){
   if($alpha1t_v <= $alpha1f_v){
      print "Warning: alpha1t <= alpha1f: this is not a cooperative behavior.\n";
      print "You set: cooperativity = $cp_flag \n";
   }

   if($beta1t_v >= $beta1f_v){
      print "Warning: beta1t >= beta1f: this is not a cooperative behavior.\n";
      print "You set: cooperativity = $cp_flag \n";
   }
}

# When there is synergistic activation it is expected that:
# k2sa > k2
# k1sa > k1
# k_1sa < k_1
if($syn_flag eq 'y' && $n_op ==2){
   if($k2sa_v <= $k2_v){
      print "Warning: k2sa <= k2: this is not a synergistic activation.\n";
      print "You set: synergistic activation = $syn_flag \n";
   }

   if($k1sa_v <= $k1_v){
      print "Warning: k1sa <= k1: this is not a synergistic activation.\n";
      print "You set: synergistic activation = $syn_flag \n";
   }

   if($k_1sa_v >= $k_1_v){
      print "Warning: k_1sa >= k_1: this is not a synergistic activation.\n";
      print "You set: synergistic activation = $syn_flag \n";
   }
}

# Compartment flag
if($comp_flag ne 'n' && $comp_flag ne 'y'){
	die "Compartment presence must be properly specified. You wrote: Compartment:  $comp_flag \n";
}

####

print "Readthrough: $rt_flag \n";
print "Promoter flag: $pr_flag \n";
print "Cooperativity: $cp_flag \n";
print "Synergistic Activation: $syn_flag \n";
print "Compartment: $comp_flag \n";
print "--------------------------------------- \n\n";
#############################################################################

### Species generation
our @species;
my @storages=(); # contains nor fictitious species neither signal carriers 
my @adapters=(); #  contains all the species associated with adapters
my %h_adapters=();  # associates each adapter to the corresponding adapter-flux (and terminal)

# Number of promoter states
my $n_st=2**$n_op;
my @states=();

# Promoter states
# For n_op=2, the order is: o1fo2f; o1fo2t; o1to2f; o1to2t.
my $st_on;
my $st_off;
my $counter;
my $tmp;

for($i=1; $i<$n_op+1; $i++){
   $st_on="f";
   $st_off="t";
   $counter=1;
   for($j=1; $j<$n_st+1;$j++){
      $states[$j]=$states[$j]."o$i$st_on";
      if($counter == 2**($n_op-$i)){
	 $tmp=$st_on;
	 $st_on=$st_off;
	 $st_off=$tmp;
	 $counter=0;
      }
      $counter++;
   }
}

if($n_op == 0){
	$states[1]="p_free";
}

# print promoter states
#for($j=1;$j<$n_st+1;$j++){
#   print "$j \t $states[$j] \n";
#}

# Copying the promoter states into the species array
for($i=1;$i<$n_st+1;$i++){
    push(@species,$states[$i]); 
    push(@storages,$states[$i]);
}

# Polymerase-promoter complex(es)
my @p_pol;

if($n_op == 0){
  $p_pol[1]="ppol";
}

if($n_op == 1){
  if($tf[0] =~ /R/){
    $p_pol[1]="pol".$states[1];
  }else{
    $p_pol[1]="pol".$states[2];
  }
}

if($n_op == 2){
  if($syn_flag eq 'n'){
    if($tf[0] =~ /R/ && $tf[1] =~ /R/){
      $p_pol[1]="pol".$states[1];
    }elsif($tf[0] =~ /R/ && $tf[1] =~ /A/){
      $p_pol[1]="pol".$states[2];
    }elsif($tf[0] =~ /A/ && $tf[1] =~ /A/){
      $p_pol[1]="pol".$states[4];
    }
  }else{
    $p_pol[2]="pol".$states[2];
    $p_pol[3]="pol".$states[3];
    $p_pol[4]="pol".$states[4];
  }
}		

# Copying the polymerase-promoter states into the species array

for($i=1;$i<scalar(@p_pol);$i++){
    if($i == 1 && $syn_flag eq 'y'){
	next;
    }	
    push(@species,$p_pol[$i]);
    push(@storages,$p_pol[$i]);
}

# Copying free RNA polymerase into the species array (adapter flux)
push(@species,"pol_free");
push(@adapters,"pol_free");
$h_adapters{"pol_free"}="pops_b.out";

# Copying transcription factors into the species array (adapter flux)
if($n_op > 0){
  for($i=0;$i<$n_tf;$i++){
    push(@species,$tf_a[$i]);		# this excludes inactive TFs to enter the promoter
    push(@adapters,$tf_a[$i]);		#       "               "              "
    my $id=$i+1;
    $h_adapters{$tf_a[$i]}="faps_b_a_$id.out";
    if($tf[$i] =~ /a/ && $sg[$i] !~ /N/){
      my $tfi=$tf[$i];
      $tfi =~ s/a/i/;
      push(@species,$tfi);
      push(@adapters,$tfi);
      $h_adapters{$tfi}="faps_b_i_$id.out";
    }
  }
}

# Copying signals into the species array (adapter flux)

if($n_op > 0){
  for($i=0;$i<$n_sg;$i++){
    my $id=$i+1;
    if($sg[$i] !~ /N/){
      push(@species,$sg[$i]);
      push(@adapters,$sg[$i]);
      $h_adapters{$sg[$i]}="sips_b_$id.out";
    }
  }
}

# Writing the fictitious species into the species array
push(@species,"pol_cl");
push(@adapters,"pol_cl");
$h_adapters{"pol_cl"}="pops_out.in";

if($n_op > 0 || $pr_flag eq 'y'){
  push(@species,"pol_lk_out");
  push(@adapters,"pol_lk_out");
  $h_adapters{"pol_lk_out"}="pops_lk_out.in";
}

# Insering incoming pol_lk, incoming pol_cl, and polq state for the promoter-promoter system only
if($pr_flag eq 'y'){
  push(@species,"pol_lk_in");
  push(@adapters,"pol_lk_in");
  $h_adapters{"pol_lk_in"}="pops_lk_in.out";

  push(@species,"pol_cl_in");
  push(@adapters,"pol_cl_in");
  $h_adapters{"pol_cl_in"}="pops_cl_in.out";

  push(@species,"polq");
  push(@storages,"polq");
}

# checking the species	 
for($i=0;$i<scalar(@species);$i++){
    print "$i \t $species[$i] \n";
}

# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
#    print "$i \t $species[$i] \n";
    $h_species{$species[$i]}=$i;
#    print "H: $h_species{$species[$i]} \n";
}

# Opening the output file containing all the promoter information
my $outfile;
$outfile=$p_name."_reactions.txt";
open(OUT,">$outfile");

# Writing promoter structure and species on the output file
print OUT "$p_name \n";
print OUT "n_op: $n_op \n";
for($i=0;$i<$n_tf;$i++){
  my $id=$i+1;	
  print OUT "TF$id: $tf[$i] \n";
}

for($i=0;$i<$n_sg;$i++){
  my $id=$i+1;	
  print OUT "SG$id: $sg[$i] \n";
}

print OUT "Readthrough: $rt_flag \n";
print OUT "Promoter flag: $pr_flag \n";
print OUT "Cooperativity: $cp_flag \n";
print OUT "Synergistic Activation: $syn_flag \n";

print OUT "$p_name species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

# checking the species hash
#for $key (keys %h_species){
#    print "$key \t $h_species{$key} \n";
#}

###########################
# Reaction generation
our @reactions=();
my %educts=();
my %products=();

my %values=();   # contains the rate (contant) values

# Transcription factors - promoter operators reactions

# One-operator-containing promoters
if($n_op == 1){
  # Transcription factors binding/unbinding the promoter
  push(@reactions,"alpha1");
  $educts{$reactions[$#reactions]}=[$tf_a[0],$states[1]];
  $products{$reactions[$#reactions]}=[$states[2]];
  $values{$reactions[$#reactions]}=$alpha_v;

  push(@reactions,"beta1");
  $educts{$reactions[$#reactions]}=[$states[2]];
  $products{$reactions[$#reactions]}=[$tf_a[0],$states[1]];
  $values{$reactions[$#reactions]}=$beta_v;

  # Chemicals acting on transcription factors bound to the promoter
  if($tf[0] eq "Ra1" && $sg[0] eq "I1"){
    my $tfi=$tf[0];
    $tfi =~ s/a/i/;
    push(@reactions,"gamma12");
    $educts{$reactions[$#reactions]}=[$sg[0],$states[2]];
    $products{$reactions[$#reactions]}=[$tfi,$states[1]];
    $values{$reactions[$#reactions]}=$gamma1_v;
  }

  if($tf[0] eq "Aa1" && $sg[0] eq "C1"){
    my $tfi=$tf[0];
    $tfi =~ s/a/i/;
    push(@reactions,"gamma12");
    $educts{$reactions[$#reactions]}=[$sg[0],$states[2]];
    $products{$reactions[$#reactions]}=[$tfi,$states[1]];
    $values{$reactions[$#reactions]}=$gamma1_v;
  }

  # Decay
  if($tf[0] =~ /a/){
    push(@reactions,"kd12");
    $educts{$reactions[$#reactions]}=[$states[2]];
    $products{$reactions[$#reactions]}=[$states[1]];
    $values{$reactions[$#reactions]}=$k_d1_v;
  }else{
    push(@reactions,"kd12");
    $educts{$reactions[$#reactions]}=[$states[2]];
    $products{$reactions[$#reactions]}=[$states[1],$sg[0]];
    $values{$reactions[$#reactions]}=$k_d1_v;
  }

}

# Two-operator-containing promoters

if($n_op == 2){
  # Transcription factors binding/unbinding the promoter
      push(@reactions,"alpha1f");
      $educts{$reactions[$#reactions]}=[$tf_a[0],$states[1]];
      $products{$reactions[$#reactions]}=[$states[3]];
      $values{$reactions[$#reactions]}=$alpha1f_v;

      push(@reactions,"beta1f");
      $educts{$reactions[$#reactions]}=[$states[3]];
      $products{$reactions[$#reactions]}=[$tf_a[0],$states[1]];
      $values{$reactions[$#reactions]}=$beta1f_v;

      push(@reactions,"alpha1t");
      $educts{$reactions[$#reactions]}=[$tf_a[0],$states[2]];
      $products{$reactions[$#reactions]}=[$states[4]];
      $values{$reactions[$#reactions]}=$alpha1t_v;

      push(@reactions,"beta1t");
      $educts{$reactions[$#reactions]}=[$states[4]];
      $products{$reactions[$#reactions]}=[$tf_a[0],$states[2]];
      $values{$reactions[$#reactions]}=$beta1t_v;

      push(@reactions,"alpha2f");
      $educts{$reactions[$#reactions]}=[$tf_a[1],$states[1]];
      $products{$reactions[$#reactions]}=[$states[2]];
      $values{$reactions[$#reactions]}=$alpha2f_v;

      push(@reactions,"beta2f");
      $educts{$reactions[$#reactions]}=[$states[2]];
      $products{$reactions[$#reactions]}=[$tf_a[1],$states[1]];
      $values{$reactions[$#reactions]}=$beta2f_v;       

      push(@reactions,"alpha2t");
      $educts{$reactions[$#reactions]}=[$tf_a[1],$states[3]];
      $products{$reactions[$#reactions]}=[$states[4]];
      $values{$reactions[$#reactions]}=$alpha2t_v;

      push(@reactions,"beta2t");
      $educts{$reactions[$#reactions]}=[$states[4]];
      $products{$reactions[$#reactions]}=[$tf_a[1],$states[3]];
      $values{$reactions[$#reactions]}=$beta2t_v;      

  # Chemicals acting on transcription factors bound to the promoter
      if($tf[0] eq "Ra1" && $sg[0] eq "I1" || $tf[0] eq "Aa1" && $sg[0] eq "C1"){
	my $tfi=$tf[0];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma13");
	$educts{$reactions[$#reactions]}=[$sg[0],$states[3]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1]];
	$values{$reactions[$#reactions]}=$gamma1_v;
 
	push(@reactions,"gamma14");
	$educts{$reactions[$#reactions]}=[$sg[0],$states[4]];
	$products{$reactions[$#reactions]}=[$tfi,$states[2]];
	$values{$reactions[$#reactions]}=$gamma1_v;
      }
      
      if($tf[1] =~ /Ra/ && $sg[1] =~ /I/ || $tf[1] =~ /Aa/ && $sg[1] =~ /C/){
	my $tfi=$tf[1];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma22");
	$educts{$reactions[$#reactions]}=[$sg[1],$states[2]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1]];
	$values{$reactions[$#reactions]}=$gamma2_v;

	push(@reactions,"gamma24");
	$educts{$reactions[$#reactions]}=[$sg[1],$states[4]];
	$products{$reactions[$#reactions]}=[$tfi,$states[3]];
	$values{$reactions[$#reactions]}=$gamma2_v;
      }

      # Decay
      if($tf[0] =~ /a/){
	push(@reactions,"kd13");
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=[$states[1]];
	$values{$reactions[$#reactions]}=$k_d1_v;

	push(@reactions,"kd14");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$states[2]];
	$values{$reactions[$#reactions]}=$k_d1_v;
      }else{
	push(@reactions,"kd13");
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=[$states[1],$sg[0]];
	$values{$reactions[$#reactions]}=$k_d1_v;

	push(@reactions,"kd14");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$states[2],$sg[0]];
	$values{$reactions[$#reactions]}=$k_d1_v;
      }

      if($tf[1] =~ /a/){
	push(@reactions,"kd22");
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=[$states[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;

	push(@reactions,"kd24");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$states[3]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }else{
	push(@reactions,"kd22");
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=[$states[1],$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;

	push(@reactions,"kd24");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=[$states[3],$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }

    }

# Polymerase-promoter reactions 
#
if($n_op == 0){
  	push(@reactions,"k1");
	$educts{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$products{$reactions[$#reactions]}=[$p_pol[1]];
	$values{$reactions[$#reactions]}=$k1_v;

  	push(@reactions,"k_1");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_1_v;

  	push(@reactions,"k2");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_cl"];  
	$values{$reactions[$#reactions]}=$k2_v;
}	

if($n_op == 1){
  if($tf[0] =~ /R/){
  	push(@reactions,"k1");
	$educts{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$products{$reactions[$#reactions]}=[$p_pol[1]];
	$values{$reactions[$#reactions]}=$k1_v;

  	push(@reactions,"k_1");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_1_v;

  	push(@reactions,"k2");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_cl"];  
	$values{$reactions[$#reactions]}=$k2_v;
      }else{
  	push(@reactions,"k1");
	$educts{$reactions[$#reactions]}=[$states[2],"pol_free"];
	$products{$reactions[$#reactions]}=[$p_pol[1]];
	$values{$reactions[$#reactions]}=$k1_v;

  	push(@reactions,"k_1");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[2],"pol_free"];
	$values{$reactions[$#reactions]}=$k_1_v;

  	push(@reactions,"k2");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[2],"pol_cl"];  
	$values{$reactions[$#reactions]}=$k2_v;
      }	
}

if($n_op == 2){
  if($tf[0] =~ /R/){
    if($tf[1] =~/R/){
      push(@reactions,"k1");
      $educts{$reactions[$#reactions]}=[$states[1],"pol_free"];
      $products{$reactions[$#reactions]}=[$p_pol[1]];
      $values{$reactions[$#reactions]}=$k1_v;
      
      push(@reactions,"k_1");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[1],"pol_free"];
      $values{$reactions[$#reactions]}=$k_1_v;
      
      push(@reactions,"k2");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[1],"pol_cl"];  
      $values{$reactions[$#reactions]}=$k2_v;
    }elsif($tf[1] =~ /A/){
      push(@reactions,"k1");
      $educts{$reactions[$#reactions]}=[$states[2],"pol_free"];
      $products{$reactions[$#reactions]}=[$p_pol[1]];
      $values{$reactions[$#reactions]}=$k1_v;
      
      push(@reactions,"k_1");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[2],"pol_free"];
      $values{$reactions[$#reactions]}=$k_1_v;
      
      push(@reactions,"k2");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[2],"pol_cl"];  
      $values{$reactions[$#reactions]}=$k2_v;
    }
  }elsif($tf[0] =~ /A/){
	if($syn_flag eq 'n'){
	  push(@reactions,"k1");
	  $educts{$reactions[$#reactions]}=[$states[4],"pol_free"];
	  $products{$reactions[$#reactions]}=[$p_pol[1]];
	  $values{$reactions[$#reactions]}=$k1_v;
	  
	  push(@reactions,"k_1");
	  $educts{$reactions[$#reactions]}=[$p_pol[1]];
	  $products{$reactions[$#reactions]}=[$states[4],"pol_free"];
	  $values{$reactions[$#reactions]}=$k_1_v;
	  
	  push(@reactions,"k2");
	  $educts{$reactions[$#reactions]}=[$p_pol[1]];
	  $products{$reactions[$#reactions]}=[$states[4],"pol_cl"];  
	  $values{$reactions[$#reactions]}=$k2_v;
	}else{
	  push(@reactions,"k12");
	  $educts{$reactions[$#reactions]}=[$states[2],"pol_free"];
	  $products{$reactions[$#reactions]}=[$p_pol[2]];
	  $values{$reactions[$#reactions]}=$k1_v;

	  push(@reactions,"k_12");
	  $educts{$reactions[$#reactions]}=[$p_pol[2]];
	  $products{$reactions[$#reactions]}=[$states[2],"pol_free"];
	  $values{$reactions[$#reactions]}=$k_1_v;
 
	  push(@reactions,"k22");
	  $educts{$reactions[$#reactions]}=[$p_pol[2]];
	  $products{$reactions[$#reactions]}=[$states[2],"pol_cl"];  
	  $values{$reactions[$#reactions]}=$k2_v;

	  push(@reactions,"k13");
	  $educts{$reactions[$#reactions]}=[$states[3],"pol_free"];
	  $products{$reactions[$#reactions]}=[$p_pol[3]];
	  $values{$reactions[$#reactions]}=$k1_v;

	  push(@reactions,"k_13");
	  $educts{$reactions[$#reactions]}=[$p_pol[3]];
	  $products{$reactions[$#reactions]}=[$states[3],"pol_free"];
	  $values{$reactions[$#reactions]}=$k_1_v;
	  
	  push(@reactions,"k23");
	  $educts{$reactions[$#reactions]}=[$p_pol[3]];
	  $products{$reactions[$#reactions]}=[$states[3],"pol_cl"];  
	  $values{$reactions[$#reactions]}=$k2_v;

	  push(@reactions,"k14");
	  $educts{$reactions[$#reactions]}=[$states[4],"pol_free"];
	  $products{$reactions[$#reactions]}=[$p_pol[4]];
	  $values{$reactions[$#reactions]}=$k1sa_v;

	  push(@reactions,"k_14");
	  $educts{$reactions[$#reactions]}=[$p_pol[4]];
	  $products{$reactions[$#reactions]}=[$states[4],"pol_free"];
	  $values{$reactions[$#reactions]}=$k_1sa_v;

	  push(@reactions,"k24");
	  $educts{$reactions[$#reactions]}=[$p_pol[4]];
	  $products{$reactions[$#reactions]}=[$states[4],"pol_cl"];  
	  $values{$reactions[$#reactions]}=$k2sa_v;
	}
      }
}
# Chemicals acting on polymerase-promoter complex 
 
  if($n_op == 1){
    if($tf[0] eq "Aa1" && $sg[0] eq "C1"){
	my $tfi=$tf[0];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma12p");
	$educts{$reactions[$#reactions]}=[$sg[0],$p_pol[1]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$gamma1_v;
      }
  }

  if($n_op == 2){
    if($syn_flag eq 'n'){
      if($tf[0] eq "Aa1" && $sg[0] eq "C1"){
	my $tfi=$tf[0];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma14p");
	$educts{$reactions[$#reactions]}=[$sg[0],$p_pol[1]];
	$products{$reactions[$#reactions]}=[$tfi,$states[2],"pol_free"];
	$values{$reactions[$#reactions]}=$gamma1_v;
      }

      if($tf[1] =~ /Aa/ && $sg[1] =~ /C/){
	my $tfi=$tf[1];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma24p");
	$educts{$reactions[$#reactions]}=[$sg[1],$p_pol[1]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$gamma2_v;
      }
    }else{
      if($tf[0] eq "Aa1" && $sg[0] eq "C1"){
	my $tfi=$tf[0];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma13p");
	$educts{$reactions[$#reactions]}=[$sg[0],$p_pol[3]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$gamma1_v;

	push(@reactions,"gamma14p");
	$educts{$reactions[$#reactions]}=[$sg[0],$p_pol[4]];
	$products{$reactions[$#reactions]}=[$tfi,$p_pol[2]];
	$values{$reactions[$#reactions]}=$gamma1_v;
      }

      if($tf[1] =~ /Aa/ && $sg[1] =~ /C/){
	my $tfi=$tf[1];
	$tfi =~ s/a/i/;
	push(@reactions,"gamma22p");
	$educts{$reactions[$#reactions]}=[$sg[1],$p_pol[2]];
	$products{$reactions[$#reactions]}=[$tfi,$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$gamma2_v;

	push(@reactions,"gamma24p");
	$educts{$reactions[$#reactions]}=[$sg[1],$p_pol[4]];
	$products{$reactions[$#reactions]}=[$tfi,$p_pol[3]];
	$values{$reactions[$#reactions]}=$gamma2_v;
      }
    }
  }

# Polymerase-promoter complex decay
  if($n_op == 1){
    if($tf[0] =~/Aa/){
 	push(@reactions,"kd12p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;
      }elsif($tf[0] =~/Ai/){	
 	push(@reactions,"kd12p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[1],$sg[0],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;
      }
  }

  if($n_op == 2){
    if($tf[0] =~ /Aa/ && $tf[1] =~ /Aa/){
      if($syn_flag eq 'n'){
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[2],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[3],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }else{
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[2]];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd13p");
	$educts{$reactions[$#reactions]}=[$p_pol[3]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;
	
 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[3]];
	$values{$reactions[$#reactions]}=$k_d2_v;

 	push(@reactions,"kd22p");
	$educts{$reactions[$#reactions]}=[$p_pol[2]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }
    }

    if($tf[0] =~ /Aa/ && $tf[1] =~ /Ai/){
      if($syn_flag eq 'n'){
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[2],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[3],"pol_free",$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }else{
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[2]];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd13p");
	$educts{$reactions[$#reactions]}=[$p_pol[3]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free"];
	$values{$reactions[$#reactions]}=$k_d1_v;
	
 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[3],$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;

 	push(@reactions,"kd22p");
	$educts{$reactions[$#reactions]}=[$p_pol[2]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free",$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }
    }

    if($tf[0] =~ /R/ && $tf[1] =~ /Aa/){
      push(@reactions,"kd22p");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[1],"pol_free"];
      $values{$reactions[$#reactions]}=$k_d2_v;
    }elsif($tf[0] =~ /R/ && $tf[1] =~ /Ai/){
      push(@reactions,"kd22p");
      $educts{$reactions[$#reactions]}=[$p_pol[1]];
      $products{$reactions[$#reactions]}=[$states[1],"pol_free",$sg[1]];
      $values{$reactions[$#reactions]}=$k_d2_v;
    }

    if($tf[0] =~ /Ai/ && $tf[1] =~ /Ai/){
      if($syn_flag eq 'n'){
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[2],"pol_free",$sg[0]];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[1]];
	$products{$reactions[$#reactions]}=[$states[3],"pol_free",$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }else{
 	push(@reactions,"kd14p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[2],$sg[0]];
	$values{$reactions[$#reactions]}=$k_d1_v;

 	push(@reactions,"kd13p");
	$educts{$reactions[$#reactions]}=[$p_pol[3]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free",$sg[0]];
	$values{$reactions[$#reactions]}=$k_d1_v;
	
 	push(@reactions,"kd24p");
	$educts{$reactions[$#reactions]}=[$p_pol[4]];
	$products{$reactions[$#reactions]}=[$p_pol[3],$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;

 	push(@reactions,"kd22p");
	$educts{$reactions[$#reactions]}=[$p_pol[2]];
	$products{$reactions[$#reactions]}=[$states[1],"pol_free",$sg[1]];
	$values{$reactions[$#reactions]}=$k_d2_v;
      }
    }
  }

# Leakage

if($n_op == 1){
  if($tf[0] =~ /R/){ # NOTATION HAS CHANGED 
 	push(@reactions,"k22_lk");
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[2]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
      }else{
 	push(@reactions,"k21_lk");
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[1]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
      }
}

if($n_op == 2){
  if($tf[0] =~ /R/ && $tf[1] =~ /R/){
    	push(@reactions,"k22_lk");
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[2]];
	$values{$reactions[$#reactions]}=$k2_lk_v;

 	push(@reactions,"k23_lk");
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[3]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
    
 	push(@reactions,"k24_lk");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[4]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
  }

  if($tf[0] =~ /R/ && $tf[1] =~ /A/){
 	push(@reactions,"k21_lk");
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[1]];
	$values{$reactions[$#reactions]}=$k2_lk_v;

 	push(@reactions,"k23_lk");
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[3]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
    
 	push(@reactions,"k24_lk");
	$educts{$reactions[$#reactions]}=[$states[4]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[4]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
      }

  if($tf[0] =~ /A/ && $tf[1] =~ /A/){
    if($syn_flag eq 'n'){
 	push(@reactions,"k21_lk");
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[1]];
	$values{$reactions[$#reactions]}=$k2_lk_v;

 	push(@reactions,"k22_lk");
	$educts{$reactions[$#reactions]}=[$states[2]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[2]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
    
 	push(@reactions,"k23_lk");
	$educts{$reactions[$#reactions]}=[$states[3]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[3]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
      }else{
 	push(@reactions,"k21_lk");
	$educts{$reactions[$#reactions]}=[$states[1]];
	$products{$reactions[$#reactions]}=["pol_lk_out",$states[1]];
	$values{$reactions[$#reactions]}=$k2_lk_v;
      }
  }
}

my @flux_reactions=();  # Contains fictitiuos reactions - only for the promoter-promoter system
# Queued polymerases, only for promoter-promoter system
if($pr_flag eq 'y'){
 	push(@flux_reactions,"FLX_lk");
	$educts{$flux_reactions[$#flux_reactions]}=["pol_lk_in"];
	$products{$flux_reactions[$#flux_reactions]}=["pol_lk_out"];

 	push(@flux_reactions,"FLX_cl");
	$educts{$flux_reactions[$#flux_reactions]}=["pol_cl_in"];
	$products{$flux_reactions[$#flux_reactions]}=["polq"];

	if($n_op == 0){
	  push(@reactions,"kq");
	  $educts{$reactions[$#reactions]}=["polq",$states[1]];
	  $products{$reactions[$#reactions]}=[$p_pol[1]];
	  $values{$reactions[$#reactions]}=$k_q_v;
	}
	
	if($n_op == 1){
	  if($tf[0] =~/R/){
	    push(@reactions,"kq");
	    $educts{$reactions[$#reactions]}=["polq",$states[1]];
	    $products{$reactions[$#reactions]}=[$p_pol[1]];
	    $values{$reactions[$#reactions]}=$k_q_v;
	  }elsif($tf[0] =~/A/){
	    push(@reactions,"kdq");
	    $educts{$reactions[$#reactions]}=["polq"];
	    $products{$reactions[$#reactions]}=["pol_free"];
	    $values{$reactions[$#reactions]}=$k_q_v;
	  }
	}

	if($n_op == 2){
	  if($tf[0] =~/R/ && $tf[1] =~/R/){
	    push(@reactions,"kq");
	    $educts{$reactions[$#reactions]}=["polq",$states[1]];
	    $products{$reactions[$#reactions]}=[$p_pol[1]];
	    $values{$reactions[$#reactions]}=$k_q_v;
	  }elsif($tf[0] =~/R/ && $tf[1] =~/A/){
	    push(@reactions,"kq");
	    $educts{$reactions[$#reactions]}=["polq"];
	    $products{$reactions[$#reactions]}=["pol_free"];
	    $values{$reactions[$#reactions]}=$k_q_v;
	  }elsif($tf[0] =~/A/ && $tf[1] =~/A/){
	    push(@reactions,"kq");
	    $educts{$reactions[$#reactions]}=["polq"];
	    $products{$reactions[$#reactions]}=["pol_free"];
	    $values{$reactions[$#reactions]}=$k_q_v;
	  }
	}
      }


# Writing all the reactions on the output file
print OUT "$p_name reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@flux_reactions); $i++){
#  print OUT "$flux_reactions[$i]: \t";
  print OUT "FLUX: \t";
  $key=$educts{$flux_reactions[$i]}[0];
  $flux = $h_adapters{$key};
  print "PINELLO: $key => $flux \n";
  $flux =~ s/$\.out/ /;  
  print OUT "$flux";
  print OUT " ===> ";
  print OUT "$products{$flux_reactions[$i]}[0]";
  print OUT "\n";
}


print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Checking the reactions
for($i=0;$i<scalar(@reactions); $i++){
  print "$reactions[$i] \n";
  $key=$reactions[$i];
#  print "MM:",scalar(@{$educts{$key}}), "\n";
  $dim=scalar(@{$educts{$key}});
#  print "DIM: $dim \n";
  for($j=0;$j<$dim;$j++){
    print "e$j \t $educts{$key}[$j] \n";
  }
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print "p$j \t $products{$key}[$j] \n";
  }
  print "------------------------- \n";
}

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
#    if($reactions[$i] !~ /INP/){
      $h_reactions{$reactions[$i]}=$i;
#    }
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
#    print "$LM[$j,$i] \n";
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  print "$kr \t $col \t $dummy \n";
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    print "$kr \t $ks \t $row \n";
    print "KR: $kr I: $i \t $row \t $col \n";
    $LM[$row][$col]=-1;
    print "P: $letters[$counter] \n";
    $LM[$row][$col]=$letters[$counter];
    $counter++;
    print "M:$LM[$row][$col]\n";
#    print_mat();
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
#    $LM[$row][$col]='1';
    if($LM[$row][$col] eq '0'){ # change due to the leakage
       $LM[$row][$col]=$letters[$counter];
    }else{
       $LM[$row][$col]="$LM[$row][$col]"."&".$letters[$counter];
    } 
    $counter++;
  }
}

print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$p_name.".mdl";
open (MDL,">$filename");

# Loading the libraries
print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";

# Class definition
print MDL 
"(define-module
  :class \"$p_name\"
  :super-classes (\"module\")
  :icon \"promoter.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
  if($storages[$i] eq "p_free" || $storages[$i] eq "o1f" || $storages[$i] eq "o1fo2f"){
    $cc=$p_free_v;
  }else{
    $cc=0.0;
  }
print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

if($comp_flag eq 'y'){
	for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].r\"
   :value \"parent.v*k1*";
   		for($j=0; $j<scalar(@{$educts{$reactions[$i]}}); $j++){
print MDL "$letters[$j].c";
			if($j+1<scalar(@{$educts{$reactions[$i]}})){
print MDL "*";
			}else{
print MDL "\")
";
			}
   		}	
	}	
}

for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"exc_pol\"
    :is-eq-to \"pops_b.in\"
    :geometry-side \"TOP\"
    :geometry-position \"0.1\")
   (\"out_pol\"
    :is-eq-to \"pops_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.9\")
";

if($n_op > 0 || $pr_flag eq 'y'){
print MDL
"   (\"out_pol_lk\"
    :is-eq-to \"pops_lk_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.1\")
";
}

my @side=("LEFT","BOTTOM");
my $co;

if($n_op > 0){
  for($i=0;$i<$n_tf;$i++){
    $co=0.1;
    my $pd=$i+1;
print MDL
"   (\"exc_tf_a_$pd\"
    :is-eq-to \"faps_b_a_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.1\")
";
    if($tf[$i] =~ /a/ && $sg[$i] !~ /N/){
print MDL
"   (\"exc_tf_i_$pd\"
    :is-eq-to \"faps_b_i_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.3\")
   (\"exc_sig_$pd\"
    :is-eq-to \"sips_b_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.5\")
";
    }

    if($tf[$i] =~ /i/){
print MDL
"   (\"exc_sig_$pd\"
    :is-eq-to \"sips_b_$pd.in\"
    :geometry-side \"$side[$i]\"
    :geometry-position \"0.5\")
";
    }


  }
}

if($pr_flag eq 'y'){
print MDL
"   (\"in_pol_lk\"
    :is-eq-to \"pops_lk_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.7\")
   (\"in_pol_cl\"
    :is-eq-to \"pops_cl_in.in\"
    :geometry-side \"left\"
    :geometry-position \"0.9\")
";
}

print MDL 
"   )
";


# Writing the modules - adapter flux  
print MDL
"  :modules
  ((\"pops_b\"
    :is-a \"adapter-flux\")
   (\"pops_out\"
    :is-a \"adapter-flux\")
";

if($n_op > 0 || $pr_flag eq 'y'){
print MDL 
"   (\"pops_lk_out\"
    :is-a \"adapter-flux\")
";
}

if($n_op > 0){
  for($i=0;$i<$n_tf;$i++){
    my $pd=$i+1;
print MDL
"   (\"faps_b_a_$pd\"
    :is-a \"adapter-flux\")
";

    if($tf[$i] =~ /a/ && $sg[$i] !~ /N/){
print MDL
"   (\"faps_b_i_$pd\"
    :is-a \"adapter-flux\")
   (\"sips_b_$pd\"
    :is-a \"adapter-flux\")
";
    }

    if($tf[$i] =~ /i/){
print MDL
"   (\"sips_b_$pd\"
    :is-a \"adapter-flux\")
";
    }
	

  }
}

if($pr_flag eq 'y'){
print MDL
"   (\"pops_lk_in\"
    :is-a \"adapter-flux\")
   (\"pops_cl_in\"
    :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
#  if($reactions[$i] !~ /INP/){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    $class{$reactions[$i]}=$cl;
#  }
#  print "$reactions[$i] \t $cl \n";
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
#  if($reactions[$i] !~ /INP/){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
#  }
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$storages[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
	if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] !~ /\&/){
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
        }else{
          print "SET \n";
	  my @set = split('&',$LM[$h_species{$storages[$i]}][$h_reactions{$key}]);
print " $key.$set[0] \n";
print " $key.$set[1] \n";

print MDL " \"$key.$set[0]\"";			
print MDL " \"$key.$set[1]\"";
	}
      }
      if($storages[$i] eq "polq"){
print MDL " \"pops_cl_in.out\"";
      }
   }
print MDL "))
"; 
    $c_lk++;
}

for($i=0;$i<scalar(@adapters);$i++){
  if($adapters[$i] eq "pol_lk_in" || $adapters[$i] eq "pol_cl_in"){
    next;
  }
  if($pr_flag eq 'y' && $adapters[$i] eq "pol_lk_out"){
    next;
  }
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_adapters{$adapters[$i]}\"";
    print "A: $adapters[$i] \n";
    foreach $key (keys %h_reactions){
#      print "KEY: $key \t $h_reactions{$key} \t $LM[$h_species{$adapters[$i]}][$h_reactions{$key}] \n";
      if($LM[$h_species{$adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$adapters[$i]}][$h_reactions{$key}]\"";
      }
    }
print MDL "))
";
    $c_lk++;
}

if($pr_flag eq 'y'){
print MDL 
"  (\"link_${c_lk}\"
    :terminals (\"pops_lk_in.out\" \"pops_lk_out.in\"))
";
}

print MDL
"  ))
";


# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}

