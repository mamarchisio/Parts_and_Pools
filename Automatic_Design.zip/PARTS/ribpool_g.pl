#! /usr/bin/perl
use strict;

my $i;
my $j;

# Ribosome pool builder.

my @par=@ARGV;

my @def=(2.1e-6,'n');

my $r_free;
# Setting r_free value.
if($par[0] !~ /^\s*$/){
   $r_free = $par[0];
}else{
   $r_free = $def[0];
}


#########################################################################
# Checking parameters
#########################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

push(@species,"r_free");
push(@storages,"r_free");

push(@in_adapters,"rips_in");
$h_in_adapters{"rips_in"}="r_free";

push(@in_adapters,"rips_b");
$h_in_adapters{"rips_b"}="r_free";

# Opening the output file containing all the ribpool information
my $outfile;
$outfile="Ribpool_reactions.txt";
open(OUT,">$outfile");


# Writing tfpool species in the output file
print OUT "Ribpool \n";
print OUT "Free ribosomes: $r_free \n";
print "\n";
print OUT "Ribpool species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Writing all the reactions on the output file
print OUT "Ribpool reactions: \n";

my $key;
my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  #print "PINELLO: $key => $flux \n";
 # $flux =~ s/$\.out/ /;  
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}

close(OUT);

######################################## Writing the MDL file
my $filename="ribpool.mdl";
open (MDL,">$filename");

# Loading the libraries
#print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"Ribpool\"
  :super-classes (\"module\")
  :icon \"Ribpool.png\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
$cc=$r_free;

print MDL
"  (\"$storages[0].c0\"
   :value \"$cc\")
";

print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"in_r\"
    :is-eq-to \"rips_in.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.9\")
   (\"exc_r\"
    :is-eq-to \"rips_b.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.1\")
";

print MDL 
"  )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
 #print "IN_AD: $in_adapters[$i] \n";

print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

print MDL
"  ))
";
