#! /usr/bin/perl

use strict;
my $i;
my $j;

# Coding part builder.
# Coding part types:
# p --> normal protein
# r --> reporter protein
# t --> transcription factor
# e --> enzyme
# c --> cistronic protein

my @par=@ARGV;

my @def=("cod",'p','p','n','n',0.056,0.049,0.00116,0.5);

my $cod_name;
# Setting the file/class name.
if($par[0] !~ /^\s*$/){
   $cod_name = $par[0];
}else{
   $cod_name = $def[0];
}

my $part;
# Setting the coding part type.
if($par[1] !~ /^\s*$/){
   $part = $par[1];
}else{
   $part = $def[1];
}

my $c_type;
my $icon_name;
# Setting the cistronic icon (only if part eq 'c').
if($part eq 'c'){
   if($par[2]){
      $c_type = $par[2];
   }else{
      $c_type = $def[2];
   }
}

if($part eq 'p' || $c_type eq 'p'){
   $icon_name="protein_coding.png";
}
if($part eq 'r' || $c_type eq 'r'){
   $icon_name="reporter_coding.png";
}
if($part eq 't' || $c_type eq 't'){
   $icon_name="tr_factor_coding.png";
}
if($part eq 'e' || $c_type eq 'e'){
   $icon_name="enzyme_coding.png";
}

my $first_cistron;
# Setting the firts cistron flag
if($par[3] !~ /^\s*$/){
   $first_cistron = $par[3];
}else{
   $first_cistron = $def[3];
}

my $fc_flag;
if($part eq 'c'){
   $fc_flag = $first_cistron;
}

my $r_lk_flag;
# Setting the firts cistron flag
if($par[4] !~ /^\s*$/){
   $r_lk_flag = $par[4];
}else{
   $r_lk_flag = $def[4];
}

my $k_el;
# Setting k_el value.
if($par[5] !~ /^\s*$/){
   $k_el = $par[5];
}else{
   $k_el = $def[5];
}

my $k_el_r;
# Setting k_el_r value.
if($par[6] !~ /^\s*$/){
   $k_el_r = $par[6];
}else{
   $k_el_r = $def[6];
}

my $k_d;
# Setting k_d value.
if($par[7] !~ /^\s*$/){
   $k_d = $par[7];
}else{
   $k_d = $def[7];
}

my $zeta_r;
# Setting zeta_r value.
if($par[8] !~ /^\s*$/){
   $zeta_r = $par[8];
}else{
   $zeta_r = $def[8];
}

########################################################################
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes

my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

# Polymerase-dependent species
push(@species,"pola");
push(@storages,"pola");

push(@species,"pol_el");
push(@out_adapters,"pol_el");
$h_out_adapters{"pol_el"}="pops_out";

push(@in_adapters,"pops_in");
$h_in_adapters{"pops_in"}="pola";

# Ribosome-dependent species
push(@species,"ra");
push(@storages,"ra");

if($part ne 'c'){
  push(@species,"ru");
  push(@storages,"ru");

  push(@species,"r_free");
  push(@out_adapters,"r_free");
  $h_out_adapters{"r_free"}="rips_out";
}else{
  push(@species,"r_el");
  push(@out_adapters,"r_el");
  $h_out_adapters{"r_el"}="rips_out";

  if($fc_flag eq 'n'){
    push(@species,"rrta");
    push(@storages,"rrta");
    push(@in_adapters,"rips_rt_in");
    $h_in_adapters{"rips_rt_in"}="rrta";
    
    push(@species,"r_rt_el");
    push(@out_adapters,"r_rt_el");
    $h_out_adapters{"r_rt_el"}="rips_rt_out";
  }
}

push(@in_adapters,"rips_in");
$h_in_adapters{"rips_in"}="ra";

if($part ne 'c'){
  push(@species,"z");
  if($part eq 'p' || $part eq 'r'){
    push(@storages,"z");
  }elsif($part eq 't'){
    push(@out_adapters,"z");
    $h_out_adapters{"z"}="faps_out";
  }elsif($part eq 'e'){
    push(@out_adapters,"z");
    $h_out_adapters{"z"}="enps_out";
  }
}

if($r_lk_flag eq 'y'){
   push(@in_adapters,"rips_lk_in");
   if($part ne 'c'){
     if($part eq 'p' || $part eq 'r'){
       $h_in_adapters{"rips_lk_in"}="z";
     }elsif($part eq 't'){
       $h_in_adapters{"rips_lk_in"}="faps_out";
     }elsif($part eq 'e'){
       $h_in_adapters{"rips_lk_in"}="enps_out";
     }
  }else{
    $h_in_adapters{"rips_lk_in"}="rips_lk_out"; # connection between two adapters
  }
}

# Creating the species hash
my %h_species=();
my $key;

for($i=0;$i<scalar(@species);$i++){
    $h_species{$species[$i]}=$i;
}

# Opening the output file containing all the RBS information
my $outfile;
$outfile=$cod_name."_reactions.txt";
open(OUT,">$outfile");

# Writing RBS structure and species in the output file
print OUT "$cod_name \n";
print OUT "type: $part \n";
if($part eq 'c'){ 
  print OUT "cistronic part: $c_type \n";
  print OUT "firt cistron: $fc_flag \n";
}
print OUT "ribosome leakage: $r_lk_flag \n";
print OUT "\n";
print OUT "$cod_name species: \n";
for($i=0;$i<scalar(@species);$i++){
  print OUT "$species[$i] \n";
}
print OUT "\n";

##############################################################

# Reaction generation
our @reactions=();
my %educts=();
my %products=();
my %values=();   # contains the rate (constant) values

# Polymerase-dependent reaction
push(@reactions,"k_el");
$educts{$reactions[$#reactions]}=["pola"];
$products{$reactions[$#reactions]}=["pol_el"];
$values{$reactions[$#reactions]}=$k_el;

# Ribosome-dependent reactions
if($part ne 'c'){
  # ru formation
  push(@reactions,"k_el_r");
  $educts{$reactions[$#reactions]}=["ra"];
  $products{$reactions[$#reactions]}=["ru"];
  $values{$reactions[$#reactions]}=$k_el_r;

  # ribosome leaving the mRNA and protein synthesis
  push(@reactions,"zeta_r");
  $educts{$reactions[$#reactions]}=["ru"];
  $products{$reactions[$#reactions]}=["r_free","z"];
  $values{$reactions[$#reactions]}=$zeta_r;
  if($part eq 'p' || $part eq 'r'){
    # protein decay
    push(@reactions,"k_d");
    $educts{$reactions[$#reactions]}=["z"];
    $products{$reactions[$#reactions]}=[];
    $values{$reactions[$#reactions]}=$k_d;
  }
}else{
  # r_el production
  push(@reactions,"k_el_r");
  $educts{$reactions[$#reactions]}=["ra"];
  $products{$reactions[$#reactions]}=["r_el"];
  $values{$reactions[$#reactions]}=$k_el_r;
  
  if($fc_flag eq 'n'){
     # r_rt_el production
     push(@reactions,"k_el_r_rt");
     $educts{$reactions[$#reactions]}=["rrta"];
     $products{$reactions[$#reactions]}=["r_rt_el"];
     $values{$reactions[$#reactions]}=$k_el_r;
  }
}

# Writing all the reactions on the output file
print OUT "$cod_name reactions: \n";

my $dim;
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i]: \t";
  $key=$reactions[$i];
  $dim=scalar(@{$educts{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$educts{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT " ---> ";
  $dim=scalar(@{$products{$key}});
  for($j=0;$j<$dim;$j++){
    print OUT "$products{$key}[$j]";
    if($j<$dim-1){
      print OUT " + ";
    }
  }
  print OUT "\n";
}

my $flux;
for($i=0;$i<scalar(@in_adapters); $i++){
  print OUT "FLUX: \t";
  $key=$in_adapters[$i];
  $flux = $h_in_adapters{$key};
  print OUT "$key";
  print OUT " ===> ";
  print OUT "$flux";
  print OUT "\n";
}


print OUT "\n";
print OUT "Parameter values: \n";
for($i=0;$i<scalar(@reactions); $i++){
  print OUT "$reactions[$i] = $values{$reactions[$i]}\n";
}

close(OUT);

# Creating the reaction hash
my %h_reactions=();

for($i=0;$i<scalar(@reactions);$i++){
#    if($reactions[$i] !~ /INP/){
      $h_reactions{$reactions[$i]}=$i;
#    }
}
##########################################

# Link matrix generation

# Link matrix initialization
my @LM;
for($i=0;$i<scalar(@reactions);$i++){
  for($j=0;$j<scalar(@species);$j++){
    $LM[$j][$i]=0;
  }
}

# Filling in the link matrix
my $kr;
my $ks;

my $col;
my $row;

my @letters=('a','b','c','d','e','f','g');
my $index;
my $counter;

my $dummy;

foreach $kr (keys %h_reactions){
  $col=$h_reactions{$kr};
  $dummy=scalar(@{$educts{$kr}});
  $counter=0;
  for($i=0;$i<scalar(@{$educts{$kr}});$i++){
    $ks=$educts{$kr}[$i];
    $row=$h_species{$ks};
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }

  for($i=0;$i<scalar(@{$products{$kr}});$i++){
    $ks=$products{$kr}[$i];
    $row=$h_species{$ks};
#    $LM[$row][$col]='1';
    $LM[$row][$col]=$letters[$counter];
    $counter++;
  }
}

#print_mat(scalar(@reactions),scalar(@species),@LM);

######################################## Writing the MDL file
my $filename=$cod_name.".mdl";
open (MDL,">$filename");

# Loading the libraries
#print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$cod_name\"
  :super-classes (\"module\")
  :icon \"$icon_name\"
";

# Writing the parameters
print MDL 
"  :parameters(
";

my $cc;
for($i=0;$i<scalar(@storages);$i++){
    $cc=0.0;
print MDL
"  (\"$storages[$i].c0\"
   :value \"$cc\")
";
}

for($i=0;$i<scalar(@reactions);$i++){
print MDL
"  (\"$reactions[$i].k1\"
   :value \"$values{$reactions[$i]}\")
";
}
print MDL 
"  )
";

# Writing the terminals
print MDL 
"  :terminals
  ((\"in_pol\"
    :is-eq-to \"pops_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.9\")
   (\"out_pol\"
    :is-eq-to \"pops_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.1\")
   (\"in_r\"
    :is-eq-to \"rips_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.1\")
   (\"out_r\"
    :is-eq-to \"rips_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.9\")
";

if($part eq 't' || $part eq 'c' && $c_type eq 't'){
print MDL
"   (\"out_tf\"
    :is-eq-to \"faps_out.out\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.5\")
";
}

if($part eq 'e' || $part eq 'c' && $c_type eq 'e'){
print MDL
"   (\"en_out\"
    :is-eq-to \"enps_out.out\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.5\")
";
}




if($r_lk_flag eq 'y'){
print MDL 
"   (\"in_r_lk\"
    :is-eq-to \"rips_lk_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.4\")
";
   if($part eq 'c'){
print MDL
"   (\"out_r_lk\"
    :is-eq-to \"rips_lk_out.out\"
    :geometry-side \"RIGHT\"
    :geometry-position \"0.4\")
";
   }
}

if($part eq 'c' && $fc_flag eq 'n'){
print MDL 
"   (\"in_r_rt\"
    :is-eq-to \"rips_rt_in.in\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.7\")
   (\"out_r_rt\"
    :is-eq-to \"rips_rt_out.out\"
    :geometry-side \"LEFT\"
    :geometry-position \"0.7\")
";
}

print MDL 
"   )
";

# Writing the modules - adapter flux  
# out adapters
print MDL
"  :modules(
";

foreach $key (keys %h_out_adapters){
print MDL 
"   (\"$h_out_adapters{$key}\"
    :is-a \"adapter-flux\")
";
}

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){

print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

if($part eq 'c' && $r_lk_flag eq 'y'){
print MDL
"   (\"rips_lk_out\"
     :is-a \"adapter-flux\")
";
}

# Writing the modules - storage-intra
for($i=0;$i<scalar(@storages);$i++){
print MDL
"   (\"$storages[$i]\"
     :is-a \"storage-intra\")
";
}

# Assigning each reaction to a class
my %class=();
my $cl;
my $ed;
my $pd;
my $tt;
my $es;

for($i=0;$i<scalar(@reactions);$i++){
    $ed=scalar(@{$educts{$reactions[$i]}});
    if($ed == 1){
      $es='';
    }elsif($ed == 2){
      $es = "ab";
    }
    $pd=scalar(@{$products{$reactions[$i]}});
    $tt=$ed+$pd;
    $cl="trans"."$tt".'a-'."fi"."$ed"."$es"."_r";
    $class{$reactions[$i]}=$cl;
}

# Writing the modules - reactions
for($i=0;$i<scalar(@reactions);$i++){
print MDL 
"   (\"$reactions[$i]\"
     :is-a \"$class{$reactions[$i]}\")
";
}

print MDL
"  )
";

# Writing the links
print MDL
"  :links(
";

my $c_lk=1;
for($i=0;$i<scalar(@storages);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$storages[$i].cf\"";
    foreach $key (keys %h_reactions){
      if($LM[$h_species{$storages[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$storages[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){	
	if($h_in_adapters{$key} eq $storages[$i]){
print MDL " \"$key.out\"";
	}
    }
print MDL "))
";
    $c_lk++;
}

for($i=0;$i<scalar(@out_adapters);$i++){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"$h_out_adapters{$out_adapters[$i]}.in\""; # always IN terminal
    foreach $key (keys %h_reactions){ # fictitious reactions
      if($LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}] ne '0'){
print MDL " \"$key.$LM[$h_species{$out_adapters[$i]}][$h_reactions{$key}]\"";
      }
    }
    foreach $key (keys %h_in_adapters){
        if($h_in_adapters{$key} eq $h_out_adapters{$out_adapters[$i]}){
print MDL " \"$key.out\"";
        }
    }
print MDL "))
";
    $c_lk++;
}

if($part eq 'c' && $r_lk_flag eq 'y'){
print MDL
"  (\"link_${c_lk}\"
    :terminals (\"rips_lk_in.out\" \"rips_lk_out.in\"))
";
}

print MDL
"  ))
";


# Subroutine for printing the link matrix
sub print_mat{
  my $dr=$_[0];
  my $ds=$_[1];
  my $LM=$_[2];
  my $u;
  my $r;
  my $s;
  
  for($u=0;$u<$dr;$u++){
    print "$reactions[$u] \t";
  }
  print "\n";
  
  for($s=0;$s<$ds;$s++){
    for($r=0;$r<$dr;$r++){
      print "$LM[$s][$r] \t";
    }
    print "\t $species[$s] \n";
  }
}

