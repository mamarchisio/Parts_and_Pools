#! /usr/bin/perl
use strict;

my $i;
my $j;

my @par=@ARGV;

my @def=('p');

my $sc;
# Setting pol_free value.
if($par[0] !~ /^\s*$/){
   $sc = $par[0];
}else{
   $sc = $def[0];
}

#########################################################################
# Checking parameters

if($sc ne 'p' && $sc ne 'r'){
     die "You can chhose only between polymerases and ribosomes. \n";
}

#########################################################################
# Species generation
our @species;
my @storages=(); # contains "true" species only
my @out_adapters=(); # contains the fictitious species on the rhs of some reactions (output fluxes) 
my @in_adapters=();  # contains input fluxes


my %h_out_adapters=();  # associates each "out" adapter to the corresponding adapter-flux 
my %h_in_adapters=(); # associates each "in" adapter to the corresponding species/adapter-flux 

if($sc eq 'p'){
  push(@in_adapters,"pops_in");
  push(@in_adapters,"pops_b");
}else{
  push(@in_adapters,"rips_in");
  push(@in_adapters,"rips_b");
}

######################################## Writing the MDL file
my $name;
if($sc eq 'p'){
   $name = "polsum";
}else{
   $name = "ribsum";
}

my $filename=$name.".mdl";
open (MDL,">$filename");

# Loading the libraries
#print MDL "(include \"promot:kb;SignalTransd;libraries;reduced-library.mdl\")";
print MDL 
"
";

# Class definition
print MDL 
"(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$name.png\"
";

# Writing the terminals
if($sc eq 'p'){
print MDL 
"  :terminals
  ((\"pol_b_in\"
    :is-eq-to \"pops_b.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.9\")
   (\"pol_in\"
    :is-eq-to \"pops_in.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.1\")
   (\"pol_b_out\"
    :is-eq-to \"pops_b.out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.9\")
   (\"pol_out\"
    :is-eq-to \"pops_in.out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.1\"))
";
}else{
print MDL
"  :terminals
  ((\"r_b_in\"
    :is-eq-to \"rips_b.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.9\")
   (\"r_in\"
    :is-eq-to \"rips_in.in\"
    :geometry-side \"BOTTOM\"
    :geometry-position \"0.1\")
   (\"r_b_out\"
    :is-eq-to \"rips_b.out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.9\")
   (\"r_out\"
    :is-eq-to \"rips_in.out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.1\"))
";
}

# Writing the modules - adapter flux  
print MDL
"  :modules(
";

# in adapters
for($i=0;$i<scalar(@in_adapters);$i++){
print MDL
"   (\"$in_adapters[$i]\"
     :is-a \"adapter-flux\")
";
}

print MDL
"  ))
";
