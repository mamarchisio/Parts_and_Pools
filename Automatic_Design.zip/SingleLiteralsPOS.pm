#! /usr/bin/perl
use strict;
use CalcInput;
use CalcInput_slPOS;
use CalcSingle_slPOS;
use CalcInternal_slPOS;

our $sl;                # solution number
our $sk;                # solution kind (POS or SOP)
our $s_kind;
our @fm_list=();        # Boolean formulae
our @lg_cl=();		# Clauses' length
our @num_cl=();		# Clauses' number
our @v_cl=(); 		# vector of clauses
our @num_in=();         # input number 
our @sg=();		# positive signals
our @nsg=();		# negated signals
our @sign;              # sign matrix
our $ca;                # counter assignment
our @type_s=();
our @out_int=();
our @gene_n=();
our @leak_p=();
our @reg_fac=();
our @input_l=();
our @sol_cl=();
our @sol_num_in=();
our @sol_class=();	
our @free_rbs=(); 	
our @int_lay=();	
our @first_f=();	
our @second_f=();	
our @sol_prm=();		
our @sol_rbs=();		
our @score_s=();
our @sign_s=();
our @final_c;
our @signals;

our @sg_to_final=();    # signals to be sent to the final gate
our @osg=();            # other signals
our @i_as=();           # integer assignment 
our @rbs;
our @v_oc=(); 	# vector of long clauses
our @lg_ocl=();      # length other clauses

our @common=();         # array of negated inputs that share a pool
our $common_flag='n';
our @co_sig=();
our @co_sig_cs=();

sub single_literals_POS{
my $fm=$fm_list[$sk];   # current formula
my $i0;
my $i1;
my $i2;
my $i3;
my $i4;
my $i5;
my $i6;
my $i7;
my $s_as;               # string (partial) assignment   
my $tag;		# total assignments
my @s_deg;		# signal degeneracy - for input layer calculation
my @prm;		# 
my @input_c;
my @deg_il;	        # vector containing all the possible input layers associated with a signal
my %sph;		# signals-parts hash
my $cc=0;		# counter-final-configurations
my $cc_t=0;		# temporary counter
my $free=0;		# number of free RBS in a given internal layer configuration
my $i;
my $j;
my $k;
my @let=('A','B','C','D');
@common=();
# this is a particular case when the POS formula contains a negated signal: it can be sent directly to the final gate

# Filling up the sg_to_final vector
for(my $i=0;$i<$num_cl[$sk]; $i++){
  if($lg_cl[$i] == 1 && $v_cl[$i] =~ /[ABCD]/){
    my $signal=lc($v_cl[$i]);
    push(@sg_to_final,$signal);
  }
}

my $oc_fm;            # other clause formula (without the negated single literals)
for(my $i=0;$i<$num_cl[$sk]; $i++){
  if($lg_cl[$i] > 1 || ($lg_cl[$i] == 1 && $v_cl[$i] =~ /[abcd]/)){
    push(@v_oc,$v_cl[$i]);
    $oc_fm .= $v_cl[$i].'-';
  }
}


@osg=();
# Constructing osg 
if($oc_fm =~/[a]/){
  push(@osg,'a');
}

if($oc_fm =~/[b]/){
  push(@osg,'b');
}

if($oc_fm =~/[c]/){
  push(@osg,'c');
}

if($oc_fm =~/[d]/){
  push(@osg,'d');
}

if($oc_fm =~/[A]/){
  push(@osg,'A');
}

if($oc_fm =~/[B]/){
  push(@osg,'B');
}

if($oc_fm =~/[C]/){
  push(@osg,'C');
}

if($oc_fm =~/[D]/){
  push(@osg,'D');
}


@sg=();
@nsg=();
# Counting the number of input signals - signals to the final gate are not considered here
if($oc_fm =~/[aA]/){
  $num_in[$sk]++;
  push(@sg,'a');
  push(@nsg,'A');
}

if($oc_fm =~/[bB]/){
  $num_in[$sk]++;
  push(@sg,'b');
  push(@nsg,'B');
}

if($oc_fm =~/[cC]/){
  $num_in[$sk]++;
  push(@sg,'c');
  push(@nsg,'C');
  
}

if($oc_fm =~/[dD]/){
  $num_in[$sk]++;
  push(@sg,'d');
  push(@nsg,'D');
}

# SIGN matrix initialization
for(my $i=0; $i<$num_in[$sk]; $i++){
  for(my $j=0; $j<2; $j++){
    $sign[$i][$j]=0;
  }
}

# SIGN matrix construction
for(my $i=0; $i<$num_in[$sk]; $i++){
  for(my $j=0; $j<scalar(@v_oc); $j++){
      if($v_oc[$j] =~ /$sg[$i]/){
        $sign[$i][0]++;
      }

      if($v_oc[$j] =~ /$nsg[$i]/){
        $sign[$i][1]++;
      }
    }
}

for(my $i=0; $i<$num_in[$sk]; $i++){ # sigle literal have now degeneracy 1
  for(my $j=0; $j<scalar(@sg_to_final); $j++){
    if($sg_to_final[$j] =~ /$sg[$i]/){
      $sign[$i][0]++;
    }
  }
}

# Assignment enumeration
$ca=0;				# counter-assignment

if($osg[0] ne ""){
  for($i0=0; $i0<2; $i0++){
    if($osg[1] ne ""){
      for($i1=0; $i1<2; $i1++){
	if($osg[2] ne ""){
	  for($i2=0; $i2<2; $i2++){
	    if($osg[3] ne ""){	
	      for($i3=0; $i3<2; $i3++){
		if($osg[4] ne ""){
		  for($i4=0; $i4<2; $i4++){
		    if($osg[5] ne ""){	
		      for($i5=0; $i5<2; $i5++){
			if($osg[6] ne ""){
			  for($i6=0; $i6<2; $i6++){	
			    if($osg[7] ne ""){
			      for($i7=0; $i7<2; $i7++){
				$s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6,$i7";	
				fl_as($ca,$s_as);
				$ca++;		
			      }							
			    }else{			      
			      $s_as="$i0,$i1,$i2,$i3,$i4,$i5,$i6";	
			      fl_as($ca,$s_as);
			      $ca++;
			    }	
			  }	
			}else{
			  $s_as="$i0,$i1,$i2,$i3,$i4,$i5";	
			  fl_as($ca,$s_as);
			  $ca++;
			}
		      }
		    }else{
		      $s_as="$i0,$i1,$i2,$i3,$i4";	
		      fl_as($ca,$s_as);
		      $ca++;
		    }	
		  }	
		}else{
		  $s_as="$i0,$i1,$i2,$i3";	
		  fl_as($ca,$s_as);
		  $ca++;
		}
	      }
	    }else{
	      $s_as="$i0,$i1,$i2";	
	      fl_as($ca,$s_as);
	      $ca++;
	    }
	  }
	}else{
	  $s_as="$i0,$i1";	
	  fl_as($ca,$s_as);
	  $ca++;
	}
      }
    }else{
      $s_as="$i0";	
      fl_as($ca,$s_as);
      $ca++;
    }
  }	
}


$tag=2**scalar(@osg);

# Calculating the input layer degeneracy
@s_deg=();
for(my $i=0; $i<$num_in[$sk]; $i++){
  my $ucs=uc($sg[$i]);  
  if($oc_fm !~ /$sg[$i]/ && $oc_fm !~ /$ucs/ ){
    next;
  }
  if($sign[$i][0] == 0){
    $s_deg[$i] = 2;
  }else{
    $s_deg[$i] = 1;
  }
}

### Other clause matrix construction (@mat)
my @mat=();
my @tv=();

for(my $i=0; $i<scalar(@v_oc); $i++){
    @tv=();	
    @tv=split(/\+/,$v_oc[$i]);
    my @otv = sort @tv;	
    @tv=@otv;		
    push(@lg_ocl,scalar(@tv));
    for(my $j=0; $j<scalar(@tv); $j++){
      $mat[$i][$j]=$tv[$j];
    }	
}

       # Check if the the negated signals are present only once (for POS only)
        if($s_kind eq "POS"){
                my @su_cl=(); # total number of clauses where a negated signal appears
                my @wh_cl=(); # labels of the (last) clause where a negated signal appears
                for($i=0; $i<scalar(@v_oc); $i++){
                        for($j=0; $j<$lg_ocl[$i]; $j++){
                                if($mat[$i][$j] eq 'A'){
                                        $su_cl[0]++;
                                        $wh_cl[0]=$i;
                                }
                                if($mat[$i][$j] eq 'B'){
                                        $su_cl[1]++;
                                        $wh_cl[1]=$i;
                                }
                                if($mat[$i][$j] eq 'C'){
                                        $su_cl[2]++;
                                        $wh_cl[2]=$i;
                                }
                                if($mat[$i][$j] eq 'D'){
                                        $su_cl[3]++;
                                        $wh_cl[3]=$i;
                                }
                        }
                }

		my %hle=('a' => 0, 'b' => 1, 'c' => 2, 'd' => 3);
                my $clau=0;
                my $str;
                my $rstr; # reordered string
                my $co=0;
                my $refe=\@common;
                lj0: for($j=0; $j<4; $j++){
                        if($j>0){
                                $co=ich_common($let[$j],$refe);
                        }
                        if($co == 1){
                                $co=0;
                                next lj0;
                        }
                        $str="_";
                        if($su_cl[$j] == 1){
                                $clau=$wh_cl[$j];
                                ljj:for(my $jj=$j+1; $jj<4; $jj++){
                                        if($su_cl[$jj] == 1 && $wh_cl[$jj] == $clau){
						if(length($str)<2){	
                                                	$str.=$let[$jj];
						}else{
							next ljj;
						}				
                                        }else{
                                                next ljj;
                                        }
                                }
                                if($str ne '_'){
                                        $str.=$let[$j];
                                        $str =~ s/^_//;
                                        $rstr=ireorder($str);
                                        push(@common,$rstr);

                                }
                        }else{
                                next lj0;
                        }
                }

                if(scalar(@common) > 0){
                        $common_flag = 'y';
                        for($j=0; $j<scalar(@common); $j++){
                                my @tmpa=split(//,$common[$j]);
                                for($k=0; $k<scalar(@tmpa); $k++){
                                        for($i=0; $i<scalar(@sg); $i++){ 
                                                if($sg[$i] eq lc($tmpa[$k])){
                                                        $co_sig_cs[$j][$k]=$i;
							$co_sig[$j][$k]=$hle{$sg[$i]};
                                                }
                                        }
                                }
                        }
                }

}


my $cit=0;	# counter-internal

# tag loop
ta_l:for(my $i=0; $i<$tag; $i++){   
  $prm[$cit]=();
  $rbs[$cit]=();

#  hash: signal--> part
  my $dim=scalar(@osg);
  for(my $j=0; $j<$dim; $j++){
    if($i_as[$i][$j] == 0){
      $sph{$osg[$j]}='p';
    }else{
      $sph{$osg[$j]}='r';
    }
  }
  
  for(my $j=0; $j<scalar(@v_oc); $j++){
    for(my $k=0; $k<$lg_ocl[$j]; $k++){
      if($sph{$mat[$j][$k]} eq 'p'){
	if(length($prm[$cit][$j]) < 2){
	  $prm[$cit][$j] .= $mat[$j][$k];
	}else{
	  next ta_l;
	}
      }else{
	if(length($rbs[$cit][$j]) < 2){
	  $rbs[$cit][$j] .= $mat[$j][$k];
	}else{
	  next ta_l;
	}
      }
    }
  }
 	
                # Insert: pool contraction
                if($common_flag eq 'y' && $s_kind eq "POS"){
                        for($j=0; $j<$num_cl[$sk]; $j++){
                                for($k=0; $k<scalar(@common); $k++){
                                        if($prm[$cit][$j] eq $common[$k]){
                                                $prm[$cit][$j] = $let[$co_sig[$k][0]];
                                                last;
                                        }
                                        if($rbs[$cit][$j] eq $common[$k]){
                                                $rbs[$cit][$j] = $let[$co_sig[$k][0]];
                                                last;
                                        }
                                }
                        }
                }


  $free = lcount_free($cit,\@rbs);		# Calculating the number of free RBS for the just found internal layer
		
  # Calculating the input layer(s) associated with the current internal layer
  @deg_il=all_inp(\%sph);	 	        # degenerate-input-layers vector

  @input_c=();			                # vector containing all the possible (up to 16) input layer configurations
  @input_c=inp_config(\@s_deg,\@deg_il);

  # Calculating the final layers associated with the current internal layer
  $cc_t=final_layer_slPOS($free);		# start filling up the @final_c vector 
  $cc=$cc_t;

  for(my $j=0;$j<scalar(@input_c);$j++){
    for(my $k=0;$k<$cc+1;$k++){
      # Vector initialization
      $type_s[$sl] = $s_kind;
      $out_int[$sl]="";
      $gene_n[$sl]=0;
      $leak_p[$sl]=0;
      for(my $jj=0;$jj<4;$jj++){
	$reg_fac[$sl][$jj]=0;
      }
      
      for(my $l=0;$l<$num_in[$sk];$l++){		
	$input_l[$sl][$l]=$input_c[$j][$l];
      }
      for(my $l=0;$l<$num_in[$sk];$l++){
	$signals[$sl][$l]=$sg[$l];
      }
      il_costPOS($s_kind,$sl);
      
      for(my $l=0; $l<scalar(@v_oc); $l++){
	$sol_prm[$sl][$l] = $prm[$cit][$l];
	$sol_rbs[$sl][$l] = $rbs[$cit][$l];
      }

      $free_rbs[$sl]=$free;
      $sol_num_in[$sl]=$num_in[$sk];
      $sol_cl[$sl]=scalar(@v_oc);
      $sol_class[$sl]=$final_c[$k][0];
      $out_int[$sl]=$final_c[$k][1];		
      #Reordering out_int				
      re_out_int_slPOS($sl);	
      $first_f[$sl]=$final_c[$k][2];				
      $second_f[$sl]=$final_c[$k][3];
      $gene_n[$sl] += $final_c[$k][4];
      $leak_p[$sl] = $final_c[$k][5];
      $reg_fac[$sl][0] += $final_c[$k][6];
      $reg_fac[$sl][1] += $final_c[$k][7];			
      $reg_fac[$sl][2] += $final_c[$k][8];
      $reg_fac[$sl][3] += $final_c[$k][9];	
      for(my $ii=0; $ii<$num_in[$sk];$ii++){
	for(my $jj=0; $jj<2; $jj++){
	  $sign_s[$sl][$ii][$jj] = $sign[$ii][$jj];
	}
      }				
      internal_layer_slPOS($s_kind,$sl);
      score_sol($sl);
      $sl++;	
    }	
  }
  
  if(scalar(@input_c) == 0){
      $type_s[$sl] = $s_kind;
      $out_int[$sl]="";
      $gene_n[$sl]=0;
      $leak_p[$sl]=0;

      
      $free_rbs[$sl]=$free;
      $sol_num_in[$sl]=$num_in[$sk];
      $sol_cl[$sl]=scalar(@v_oc);
      $sol_class[$sl]=$final_c[0][0];
      $out_int[$sl]=$final_c[0][1];		
      #Reordering out_int				
      re_out_int_slPOS($sl);	
      $first_f[$sl]=$final_c[0][2];				
      $second_f[$sl]=$final_c[0][3];
      $gene_n[$sl] += $final_c[0][4];
      $leak_p[$sl] = $final_c[0][5];
      $reg_fac[$sl][0] += $final_c[0][6];
      $reg_fac[$sl][1] += $final_c[0][7];			
      $reg_fac[$sl][2] += $final_c[0][8];
      $reg_fac[$sl][3] += $final_c[0][9];	
      for(my $ii=0; $ii<$num_in[$sk];$ii++){
	for(my $jj=0; $jj<2; $jj++){
	  $sign_s[$sl][$ii][$jj] = $sign[$ii][$jj];
	}
      }				
      internal_layer_slPOS($s_kind,$sl);
      score_sol($sl);
      $sl++;	
    }	
 

  $cit++;
} # end loop $tag


}
#-----------------------------------------------


sub fl_as{
  my $ca=$_[0];
  my $s_as=$_[1];

  my $dm;
  my @v_as;

  for(my $i=0; $i<scalar(@sg_to_final); $i++){
    $i_as[$ca][$i]=1;
  }

  @v_as=split(/,/,$s_as);
  $dm=scalar(@v_as);
  for(my $i=0; $i<$dm; $i++){
    $i_as[$ca][$i]=$v_as[$i];
  }
}
#-----------------------------------------------


sub printlas{
my $ve=$_[0];
my $ca=$_[1];
	for(my $i=0; $i<$ca; $i++){
			print "$i \t";
		for(my $j=0; $j<8; $j++){
			print "$i_as[$i][$j] ";
		}
		print "\n";
	}
}
#-----------------------------------------------
sub lcount_free{
my $it=$_[0];
my $rbs=$_[1];
my $free=0;
my $i;
        for($i=0; $i<scalar(@v_oc); $i++){
                if(${rbs}[$it][$i] eq ""){
                        $free++;
                }
        }
	return($free);
}
#-----------------------------------------------

sub ich_common{
my $le=$_[0];
my @arr=@{$_[1]};
my $i;
my $check=0;

        for($i=0; $i<scalar(@arr); $i++){
                if(@arr[$i] =~ /$le/){
                        $check=1;
                        last;
                }
        }
        return($check);
}
#-----------------------------------------------
sub ireorder{
my $str=$_[0];
my $rstr="";

        my @sarr=split('',$str);
        my @rarr=sort @sarr;

        for(my $i=0; $i<scalar(@rarr); $i++){
                $rstr .= $rarr[$i];
        }
        return($rstr);
}
#-----------------------------------------------
~






1;
