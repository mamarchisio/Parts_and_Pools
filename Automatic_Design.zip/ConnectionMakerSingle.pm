#! /usr/bin/perl
use strict;
use PartsMaker;

sub connections_single{
our $n_in;
our $solu;
our @sol_cl;
our @type_s;
our @sign_s;
our @sg;
our @nsg;
our @sol_prm;
our @sol_rbs;
our @int_lay;
our @input_l;
our @second_fa;
our @out_int;
our @common;
our $common_flag;
our @co_sig;
our @co_sig_cs;
my @nb_s=();
my @nb_rf=();
my $nb;
my $i; 
my $j;
my $k;
my $name;
my $nm;
my $dm;
my $gp=0;
my $gr=0;
my @st_state=();
my @pos_state=();	
my @neg_state=();
my @int_state=(); 
my @tmpa;
my $stn;
my $ntn;
my $ptn;
my $itn;
my @namea;
my $ftn;
my @f_state=();
my $etn;
my @inpff=();
my @ointa=();
my $plp=1;
my $rbp=1;
my @input_l_nm=();
my @co_pool=();


	gen_pol_pool();
	gen_rib_pool();
	
	# Input layer: internal rf pools' generation
	if($type_s[$solu] eq "POS"){
		for($i=0; $i<$n_in; $i++){
			if($input_l[$solu][$i] eq  "not0" || $input_l[$solu][$i] eq  "not1"){
				$name=$sg[$i]."_pos";
				$nb_rf[$i]=$sign_s[$solu][$i][0]+1;
				$pos_state[$i]=1;
				gen_tf_pool($name,'i','y');
			}
			if($input_l[$solu][$i] eq  "not3"){
				$name="inp"."$i";
				gen_tf_pool($name,'a','n');
			}
		}
	}elsif($type_s[$solu] eq "SOP"){
		for($i=0; $i<$n_in; $i++){
			if($input_l[$solu][$i] eq "not0"){
				$name=$sg[$i]."_pos";
				$nb_rf[$i]=$sign_s[$solu][$i][0]+1;
				$pos_state[$i]=1;
				gen_tf_pool($name,'i','y');
				$name="inp".$i;
				gen_srna_pool($name);
			}elsif($input_l[$solu][$i] eq "not1"){
				$name=$sg[$i]."_pos";
				$nb_rf[$i]=$sign_s[$solu][$i][0]+1;
				$pos_state[$i]=1;
				gen_tf_pool($name,'i','y');
				$name="inp".$i;
				gen_tf_pool($name,'a','n');
			}elsif($input_l[$solu][$i] eq "not2" || $input_l[$solu][$i] eq "not3"){
				$name="inp".$i;
				gen_tf_pool($name,'a','n');
			}
		}
	}

	# Input layer: signal and rf pools' generation 
	$dm=scalar(@sg);
	for($i=0;$i<$dm;$i++){
		$nb_s[$i]=$sign_s[$solu][$i][0];		# signal pool terminals
		if($input_l[$solu][$i] !~ /yes/){
			$nb_s[$i]++;
		}
		$st_state[$i]=1;

                gen_signal_pool($sg[$i]);

		$nb_rf[$i]=$sign_s[$solu][$i][1];	# regulatory factor pool terminals

		if(($type_s[$solu] eq "POS" && $common_flag eq 'n') || ($type_s[$solu] eq "SOP")){
			if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not2"){ 
				$nm=$sg[$i]."_neg";
				$neg_state[$i]=1;
				gen_tf_pool($nm,'a','n');
			}elsif($input_l[$solu][$i] eq "yes0"){
				$nb_rf[$i]=$sign_s[$solu][$i][0];
				$nm=$sg[$i]."_pos";
				$pos_state[$i]=1;			
				gen_tf_pool($nm,'i','y');
			}elsif($input_l[$solu][$i] eq "not1" || $input_l[$solu][$i] eq "not3"){
				$nm=$sg[$i]."_neg";
				$neg_state[$i]=1;
				gen_srna_pool($nm);
			}	
		}
	}

        my @link_co=();
        if($type_s[$solu] eq "POS" && $common_flag eq 'y'){
                @input_l_nm=();
                for($i=0; $i<$n_in; $i++){
                	my $sx="ip".$i;
                	my $nm="$input_l[$solu][$i]"."_"."$sx";
                	push(@input_l_nm,$nm);
		}

	# Initializing the int_state arrayr(@common); # number of possible contractions (max 2)
		my $ctr=scalar(@common); # number of possible contractions (max 2)   
	        my @r_pool=();
                my @l_pool=();
#		my @co_pool=();
                for(my $j=0; $j<$ctr; $j++){
			@r_pool=();
			@l_pool=();
                        my $ct_r=0;
                        my $ct_l=0;
                        for(my $k=0; $k<scalar(@{$co_sig_cs[$j]}); $k++){
                                if($input_l[$solu][$co_sig_cs[$j][$k]] eq "not0" || $input_l[$solu][$co_sig_cs[$j][$k]] eq "not2"){
                                        $ct_r++;
                                        push(@r_pool,$co_sig_cs[$j][$k]);
                                }elsif($input_l[$solu][$co_sig_cs[$j][$k]] eq "not1" || $input_l[$solu][$co_sig_cs[$j][$k]] eq "not3"){
                                        $ct_l++;
                                        push(@l_pool,$co_sig_cs[$j][$k]);
                                }
			}
                                if($ct_r == 2){
                                        $nm=$sg[$r_pool[0]]."_neg";
                                        $neg_state[$r_pool[0]]=1;
                                        $neg_state[$r_pool[1]]=1;
                                        gen_tf_pool($nm,'a','n');
					push(@co_pool,$sg[$r_pool[1]]); # to be excluded
                                        push(@link_co,"(\"$input_l_nm[$r_pool[0]]_$input_l_nm[$r_pool[1]]_${sg[$r_pool[0]]}_neg_pool\"
    :terminals(\"$input_l_nm[$r_pool[0]].out_tf\" \"$input_l_nm[$r_pool[1]].out_tf\" \"${sg[$r_pool[0]]}_neg_pool.in_tf\"))");
                                }
                                if($ct_l == 2){
                                        $nm=$sg[$l_pool[0]]."_neg";
                                        $neg_state[$l_pool[0]]=1;
                                        $neg_state[$l_pool[1]]=1;
                                        gen_srna_pool($nm);
					push(@co_pool,$sg[$l_pool[1]]); # to be excluded
                                        push(@link_co,"(\"$input_l_nm[$l_pool[0]]_$input_l_nm[$l_pool[1]]_${sg[$l_pool[0]]}_neg_pool\"
    :terminals(\"$input_l_nm[$l_pool[0]].out_rna\" \"$input_l_nm[$l_pool[1]].out_rna\" \"${sg[$l_pool[0]]}_neg_pool.in_srna\"))");

                                }
                                if($ct_r == 1){
                                        $nm=$sg[$r_pool[0]]."_neg";
                                        $neg_state[$r_pool[0]]=1;
                                        gen_tf_pool($nm,'a','n');
                   			push(@link_co,"(\"$input_l_nm[$r_pool[0]]_${sg[$r_pool[0]]}_neg_pool\"
    :terminals(\"$input_l_nm[$r_pool[0]].out_tf\" \"${sg[$r_pool[0]]}_neg_pool.in_tf\"))");
                                }
                                if($ct_l == 1){
                                        $nm=$sg[$l_pool[0]]."_neg";
                                        $neg_state[$l_pool[0]]=1;
                                        gen_srna_pool($nm);
                                        push(@link_co,"(\"$input_l_nm[$l_pool[0]]_${sg[$l_pool[0]]}_neg_pool\"
    :terminals(\"$input_l_nm[$l_pool[0]].out_rna\" \"${sg[$l_pool[0]]}_neg_pool.in_srna\"))");
                                }
                        for($i=0;$i<$n_in;$i++){ 
                                my $ucs=uc($sg[$i]);
                                if($common[0] =~ /$ucs/){
                                        next;
                                }
                                if($common[1] =~ /$ucs/){
                                        next;
                                }
                                if($input_l[$solu][$i] eq ""){
                                        next;
                                }

                                if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not2"){
                                $nm=$sg[$i]."_neg";
                                $neg_state[$i]=1;
                                gen_tf_pool($nm,'a','n');
                                }elsif($input_l[$solu][$i] eq "yes0"){
                                $nb_rf[$i]=$sign_s[$solu][$i][0];
                                $nm=$sg[$i]."_pos";
                                $pos_state[$i]=1;
                                gen_tf_pool($nm,'i','y');
                                }elsif($input_l[$solu][$i] eq "not1" || $input_l[$solu][$i] eq "not3"){
                                $nm=$sg[$i]."_neg";
                                $neg_state[$i]=1;
                                gen_srna_pool($nm);
                                }
                        }

                        
                }
        }
	for($i=0; $i<$sol_cl[$solu]; $i++){
		for($j=0; $j<3; $j++){
			$int_state[$i][$j] = 1;		# 0--> exc_sig; 1--> exc_tf; 2 --> exc_rf
		}
	}
 
        # Calculating the terminal number of the internal layer pools  ---  int_ter [RSloABke]
	my @int_ter=();
        for($i=0; $i<$sol_cl[$solu]; $i++){
	    if($int_lay[$solu][$i] =~/R$/){
		$int_ter[0]++;
	    }elsif($int_lay[$solu][$i] =~/S$/){
		$int_ter[1]++;
	    }elsif($int_lay[$solu][$i] =~/l$/){
		$int_ter[2]++;
	    }elsif($int_lay[$solu][$i] =~/o$/){
		$int_ter[3]++;
	    }elsif($int_lay[$solu][$i] =~/A$/){
		$int_ter[4]++;
	    }elsif($int_lay[$solu][$i] =~/B$/){
		$int_ter[5]++;
	    }elsif($int_lay[$solu][$i] =~/k$/){
		$int_ter[6]++;
	    }elsif($int_lay[$solu][$i] =~/e$/){
		$int_ter[7]++;
	    }
	}

	my $num_p=0;
	my @int_name=();
	# Counting the number of internal pools
	for($i=0; $i<scalar(@int_ter); $i++){
		if($int_ter[$i] > 0){
			$num_p++;
			if($i == 0){
				push(@int_name,'R');
			}elsif($i == 1){
				push(@int_name,'S');
			}elsif($i == 2){
				push(@int_name,'l');
			}elsif($i == 3){
				push(@int_name,'o');
			}elsif($i == 4){
				push(@int_name,'A');
			}elsif($i == 5){
				push(@int_name,'B');
			}elsif($i == 6){
				push(@int_name,'k');
			}elsif($i == 7){
				push(@int_name,'e');
			}
		}
	}

	# Internal layer: rf pools' generation
	for($i=0; $i<$sol_cl[$solu]; $i++){
	    if($int_lay[$solu][$i] =~/R$/){
		$name="int"."_R";
		gen_tf_pool($name,'a','n');
	    }elsif($int_lay[$solu][$i] =~/S$/){
		$name="int"."_S";	
		gen_tf_pool($name,'a','n');
	    }elsif($int_lay[$solu][$i] =~/l$/){
		$name="int"."_l";
		gen_srna_pool($name);
	    }elsif($int_lay[$solu][$i] =~/o$/){
		$name="int"."_o";
		gen_srna_pool($name);
	    }elsif($int_lay[$solu][$i] =~/A$/){
		$name="int"."_A";
		gen_tf_pool($name,'a','n');
	    }elsif($int_lay[$solu][$i] =~/B$/){
		$name="int"."_B";
		gen_tf_pool($name,'a','n');
	    }elsif($int_lay[$solu][$i] =~/k$/){
		$name="int"."_k";
		gen_srna_pool($name);
	    }elsif($int_lay[$solu][$i] =~/e$/){
		$name="int"."_e";
		gen_srna_pool($name);
	    }
	}

	# Final layer: last pool generation (if necessary)
	$dm=scalar(@second_fa);
	if($dm == 2){
		$name="fin";	
		if($second_fa[0] =~/_l/ || $second_fa[0] =~/_k/){
			gen_srna_pool($name); 
		}else{
			
			gen_tf_pool($name,'a','n');
		}
	}			


my $filename="circuit.mdl";
open (OUT,">$filename");
print OUT "
(define-module
  :class \"digital_c\"
  :super-classes (\"module\")
  :geometry-width \"2000\"
  :geometry-height \"1800\"";

# modules
print OUT "
  :modules(";

# Signal pools
my $xc=200;
my $yc=0;
for($i=0; $i<$n_in; $i++){
	$yc += 300;
print OUT "
   (\"${sg[$i]}_pool\"
    :is-a \"${sg[$i]}_pool\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
}

# Input layer
$dm=$n_in;
$xc=400;
my $xcd=450;
my $xct=500;
$yc=-100;
my $ycd=0;
my $sx="";
my @input_l_nm=();
for($i=0; $i<$dm; $i++){
	$sx="ip".$i;
	$yc += 300;
	$nm="$input_l[$solu][$i]"."_"."$sx";
	push(@input_l_nm,$nm);
	if($input_l[$solu][$i] eq "yes1"){
		next;
	}
print OUT "
   (\"${input_l[$solu][$i]}_${sx}\"
    :is-a \"$input_l[$solu][$i]\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";

	if($type_s[$solu] eq "POS"){ 
		if($input_l[$solu][$i] eq "yes0"){
			 $ycd = $yc-100;
print OUT "
   (\"${sg[$i]}_pos_pool\"
    :is-a \"${sg[$i]}_pos_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
                }elsif($input_l[$solu][$i] eq "not3"){   # $input_l[$solu][$i] eq "not2" || --> now new
			$ycd = $yc-100;
print OUT "
   (\"inp${i}_pool\"
    :is-a \"inp${i}_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
		}elsif($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not1"){
			$ycd = $yc-100;
print OUT "
   (\"${sg[$i]}_pos_pool\"
    :is-a \"${sg[$i]}_pos_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
		}
	}elsif($type_s[$solu] eq "SOP"){ 
		if($input_l[$solu][$i] eq "yes0"){
			 $ycd = $yc-100;
print OUT "
   (\"${sg[$i]}_pos_pool\"
    :is-a \"${sg[$i]}_pos_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
		}elsif($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not1"){
			$ycd = $yc-100;
print OUT "
   (\"${sg[$i]}_pos_pool\"
    :is-a \"${sg[$i]}_pos_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")
   (\"inp${i}_pool\"
    :is-a \"inp${i}_pool\"
    :geometry-x \"$xct\"
    :geometry-y \"$ycd\")";
		}elsif($input_l[$solu][$i] eq "not2" || $input_l[$solu][$i] eq "not3"){
			$ycd = $yc-100;
print OUT "
   (\"inp${i}_pool\"
    :is-a \"inp${i}_pool\"
    :geometry-x \"$xcd\"
    :geometry-y \"$ycd\")";
		}
	}
} # end input layer for ($i<$dm) 

# Negative signal pools
my $xc=600;
my $yc=0;
if(($type_s[$solu] eq "POS" && $common_flag eq 'n') || ($type_s[$solu] eq "SOP")){
	for($i=0; $i<$n_in; $i++){ 
		$yc += 300;
		if($sign_s[$solu][$i][1] > 0){
print OUT "
   (\"${sg[$i]}_neg_pool\"
    :is-a \"${sg[$i]}_neg_pool\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
		}
	}
}elsif($type_s[$solu] eq "POS" && $common_flag eq 'y'){
        for($i=0; $i<$n_in; $i++){ 

		if($sign_s[$solu][$i][1] > 0){
			if($sg[$i] eq $co_pool[0]){
				next;
			}
			if($sg[$i] eq $co_pool[1]){
				next;
			}
		$yc += 300;
print OUT "
   (\"${sg[$i]}_neg_pool\"
    :is-a \"${sg[$i]}_neg_pool\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";		
	}
	}
}	


# Internal layer
$xc=800;
$yc=0;
$sx="";
my @int_lay_nm=();
for($i=0; $i<$sol_cl[$solu]; $i++){
	$sx="it".$i;
	$yc += 200;
	$nm="$int_lay[$solu][$i]"."_"."$sx";
	push(@int_lay_nm,$nm);
print OUT "
   (\"${int_lay[$solu][$i]}_${sx}\"
    :is-a \"$int_lay[$solu][$i]\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
}

# Internal rf pools
$xc=1000;
$yc=0;
for($i=0; $i<$num_p; $i++){
	$yc += 200;
print OUT "
   (\"int_${int_name[$i]}_pool\"
    :is-a \"int_${int_name[$i]}_pool\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";
}

# Final gates
$xc=1600;
$yc=800;
$dm=scalar(@second_fa);
my @second_fa_nm=();
$nm="$second_fa[0]"."_sf0";
push(@second_fa_nm,$nm);
print OUT "
   (\"${second_fa[0]}_sf0\"
    :is-a \"$second_fa[0]\"
    :geometry-x \"$xc\"
    :geometry-y \"$yc\")";

if($dm == 2){
$nm="$second_fa[1]"."_sf1";
push(@second_fa_nm,$nm);
print OUT "
   (\"fin_pool\"
    :is-a \"fin_pool\"
    :geometry-x \"1700\"
    :geometry-y \"$yc\")
   (\"${second_fa[1]}_sf1\"
    :is-a \"$second_fa[1]\"
    :geometry-x \"1800\"
    :geometry-y \"$yc\")";
}

# Polpool and ribpool
print OUT "
   (\"polpool\"
    :is-a \"polpool\"
    :geometry-x \"1600\"
    :geometry-y \"200\")
   (\"ribpool\"
    :is-a \"ribpool\"
    :geometry-x \"200\"
    :geometry-y \"1600\")";

print OUT ")";

# links
my $j;
print OUT "
  :links(";

our %signal_pool_link=();
for($i=0; $i<$n_in; $i++){
        my $key=$sg[$i];	
	@{$signal_pool_link{$key}}=();
}

##### signal pools to input layer gates, (sig)-pos-pool, (sig)-neg-pools, internal layer gates
##### signal pools to input layer gates --> only to the RBS
for($i=0; $i<$n_in; $i++){
	my $key=$sg[$i];
	if($input_l[$solu][$i] eq "not2" || $input_l[$solu][$i] eq "not3"){
		push(@{$signal_pool_link{$key}},"$input_l_nm[$i].exc_rf_1");
	}
}

##### signal pools to the (sig)_pos_pools
for($i=0; $i<$n_in; $i++){
	my $key=$sg[$i];
        if($input_l[$solu][$i] eq "yes0" || $input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not1"){
		push(@{$signal_pool_link{$key}},"${sg[$i]}_pos_pool.exc_sg");
	}
}

our %signal_pos_pool_link=();
for($i=0; $i<$n_in; $i++){
	my $key=$sg[$i];
        @{$signal_pos_pool_link{$key}}=();
}

#### signal pos pools to internal layers gates 
for($i=0; $i<$sol_cl[$solu]; $i++){
        @tmpa=();
        if($sol_prm[$solu][$i] ne ""){
                @tmpa=split(//,$sol_prm[$solu][$i]);
                for($j=0; $j<scalar(@tmpa); $j++){
                        if($tmpa[$j] =~ /[abcd]/){
				my $key=$tmpa[$j];
                                if($tmpa[$j] eq 'a'){
                                        $ptn=$pos_state[0];
                                        $pos_state[0]++;
                                }elsif($tmpa[$j] eq 'b'){
                                        $ptn=$pos_state[1];
                                        $pos_state[1]++;
                                }elsif($tmpa[$j] eq 'c'){
                                        $ptn=$pos_state[2];
                                        $pos_state[2]++;
                                }elsif($tmpa[$j] eq 'd'){
                                        $ptn=$pos_state[3];
                                        $pos_state[3]++;
                                }
                                $itn=$int_state[$i][0];
                                $int_state[$i][0]++;

				push(@{$signal_pool_link{$key}},"$int_lay_nm[$i].exc_sig_${itn}");
				$itn=$int_state[$i][1];
				$int_state[$i][1]++;
				
				push(@{$signal_pos_pool_link{$key}},"$int_lay_nm[$i].exc_tf_a_${itn}");	
                        }
                }
        }
}


#### signal pools to internal layer gates -- on RBS
for($i=0; $i<$sol_cl[$solu]; $i++){
        @tmpa=();
        if($sol_rbs[$solu][$i] ne ""){
                @tmpa=split(//,$sol_rbs[$solu][$i]);
                for($j=0; $j<scalar(@tmpa); $j++){
                        if($tmpa[$j] =~ /[abcd]/){
				my $key=$tmpa[$j];
                                if($tmpa[$j] eq 'a'){
                                        $stn=$st_state[0];
                                        $st_state[0]++;
                                }elsif($tmpa[$j] eq 'b'){
                                        $stn=$st_state[1];
                                        $st_state[1]++;
                                }elsif($tmpa[$j] eq 'c'){
                                        $stn=$st_state[2];
                                        $st_state[2]++;
                                }elsif($tmpa[$j] eq 'd'){
                                        $stn=$st_state[3];
                                        $st_state[3]++;
                                }
                                $itn=$int_state[$i][2];
                                $int_state[$i][2]++;
			
				push(@{$signal_pool_link{$key}},"$int_lay_nm[$i].exc_rf_${itn}");
                        }
                }
        }
}

##multiple links# signal pools' links --> exc_sig terminal
for($i=0;$i<$n_in;$i++){
print OUT "
   (\"${sg[$i]}_pool_link\"
    :terminals(\"${sg[$i]}_pool.exc_sig\"";
	my $key=$sg[$i];
	my $dim=scalar(@{$signal_pool_link{$key}});
	for($j=0;$j<$dim;$j++){
		print OUT " \"${$signal_pool_link{$key}}[$j]\""; 
	}
	print OUT "))";
}

##### input gates to the (sig)_neg_pools
if($type_s[$solu] eq "POS" && $common_flag eq 'y'){
        for($i=0; $i<scalar(@link_co); $i++){
print OUT "\n   $link_co[$i]";
        }
        for($i=0; $i<$n_in; $i++){ 
                my $ucs=uc($sg[$i]);
                if($common[0] =~ /$ucs/){
                        next;
                }
                if($common[1] =~ /$ucs/){
                        next;
                }
                if($input_l[$solu][$i] eq ""){
                        next;
                }

                if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not2"){
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_neg_pool\"
    :terminals(\"$input_l_nm[$i].out_tf\" \"${sg[$i]}_neg_pool.in_tf\"))";
                }elsif($input_l[$solu][$i] eq "not1" || $input_l[$solu][$i] eq "not3"){
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_neg_pool\"
    :terminals(\"$input_l_nm[$i].out_rna\" \"${sg[$i]}_neg_pool.in_srna\"))";
                }
        } 
}else{
	for($i=0; $i<$n_in; $i++){
		if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not2"){
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_neg_pool\"
    :terminals(\"$input_l_nm[$i].out_tf\" \"${sg[$i]}_neg_pool.in_tf\"))";
		}elsif($input_l[$solu][$i] eq "not1" || $input_l[$solu][$i] eq "not3"){
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_neg_pool\"
    :terminals(\"$input_l_nm[$i].out_rna\" \"${sg[$i]}_neg_pool.in_srna\"))";
		}
	}
}
##### input gates to the (sig)_pos_pools
for($i=0; $i<$n_in; $i++){
	if($input_l[$solu][$i] eq "yes0"){
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_pos_pool\"
    :terminals(\"$input_l_nm[$i].out_tf\" \"${sg[$i]}_pos_pool.in_tf\"))";
	}
}

##### (sig)_pos_pools to their input gate  --> exc_tf
for($i=0; $i<$n_in; $i++){
	my $key=$sg[$i];
        if($type_s[$solu] eq "POS"){
                if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not1"){
			push(@{$signal_pos_pool_link{$key}},"$input_l_nm[$i].exc_tf_a"); 
		}
        }elsif($type_s[$solu] eq "SOP"){
                if($input_l[$solu][$i] eq "not1"){
                        push(@{$signal_pos_pool_link{$key}},"$input_l_nm[$i].exc_tf_a_1");  
                }elsif($input_l[$solu][$i] eq "not0"){
                        push(@{$signal_pos_pool_link{$key}},"$input_l_nm[$i].exc_tf_a_1");  
                }
        }
}

#### inp_pool and sig_pos_pol (in_tf) to their input gate
for($i=0; $i<$n_in; $i++){
	if($type_s[$solu] eq "POS"){
		if($input_l[$solu][$i] eq "not0" || $input_l[$solu][$i] eq "not1"){
			$ptn=$pos_state[$i];
			$pos_state[$i]++;
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_pos_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i\" \"${sg[$i]}_pos_pool.in_tf\"))";
		}elsif($input_l[$solu][$i] eq "not3"){
print OUT "
   (\"$input_l_nm[$i]_inp${i}_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i\" \"inp${i}_pool.in_tf\"))			
   (\"inp${i}_pool_$input_l_nm[$i]_down\"
    :terminals(\"inp${i}_pool.exc_tf_a\" \"$input_l_nm[$i].exc_tf_a\"))";  
		}
	}elsif($type_s[$solu] eq "SOP"){
		if($input_l[$solu][$i] eq "not1"){
			$ptn=$pos_state[$i];
			$pos_state[$i]++;
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_pos_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i1\" \"${sg[$i]}_pos_pool.in_tf\"))				
   (\"$input_l_nm[$i]_inp${i}_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i2\" \"inp${i}_pool.in_tf\"))			
   (\"inp${i}_pool_$input_l_nm[$i]_down\"
    :terminals(\"inp${i}_pool.exc_tf_a\" \"$input_l_nm[$i].exc_tf_i2\"))";
		}elsif($input_l[$solu][$i] eq "not0"){
			$ptn=$pos_state[$i];
                        $pos_state[$i]++;
print OUT "
   (\"$input_l_nm[$i]_${sg[$i]}_pos_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i1\" \"${sg[$i]}_pos_pool.in_tf\"))
   (\"$input_l_nm[$i]_inp${i}_pool_up\"
    :terminals(\"$input_l_nm[$i].out_rna_i\" \"inp${i}_pool.in_srna\"))
   (\"inp${i}_pool_$input_l_nm[$i]_down\"
     :terminals(\"inp${i}_pool.exc_srna\" \"$input_l_nm[$i].exc_rf_1\"))";	
		}elsif($input_l[$solu][$i] eq "not2" || $input_l[$solu][$i] eq "not3"){
print OUT "
   (\"$input_l_nm[$i]_inp${i}_pool_up\"
    :terminals(\"$input_l_nm[$i].out_tf_i\" \"inp${i}_pool.in_tf\"))		
   (\"inp${i}_pool_$input_l_nm[$i]_down\"
    :terminals(\"inp${i}_pool.exc_tf_a\" \"$input_l_nm[$i].exc_tf_a\"))"; 
		}
	}
} 

##multiple links# signal pos pools' links --> exc_tf terminal
for($i=0;$i<$n_in;$i++){
        my $key=$sg[$i];
        my $dim=scalar(@{$signal_pos_pool_link{$key}});
        if($dim > 0){
print OUT "
   (\"${sg[$i]}_pos_pool_link\"
    :terminals(\"${sg[$i]}_pos_pool.exc_tf_a\" ";   
        for($j=0;$j<$dim;$j++){
                print OUT " \"${$signal_pos_pool_link{$key}}[$j]\" ";
        }
        print OUT "))";
	}
}

our %signal_neg_pool_link_tf=();
for($i=0;$i<$n_in;$i++){
        my $key=$nsg[$i];
	@{$signal_neg_pool_link_tf{$key}}=();
}
#### signal neg pools to internal layer gates -- on promoter (exc_tf)
for($i=0; $i<$sol_cl[$solu]; $i++){
	@tmpa=();
	if($sol_prm[$solu][$i] ne ""){
		@tmpa=split(//,$sol_prm[$solu][$i]);
		for($j=0; $j<scalar(@tmpa); $j++){
			my $key=$tmpa[$j];
			if($tmpa[$j] =~ /[ABCD]/){	
				if($tmpa[$j] eq 'A'){
					$ntn=$neg_state[0];
					$neg_state[0]++;
				}elsif($tmpa[$j] eq 'B'){
					$ntn=$neg_state[1];
					$neg_state[1]++;
				}elsif($tmpa[$j] eq 'C'){
					$ntn=$neg_state[2];
					$neg_state[2]++;
				}elsif($tmpa[$j] eq 'D'){
					$ntn=$neg_state[3];
					$neg_state[3]++;
				}
				$itn=$int_state[$i][1];
				$int_state[$i][1]++;
				push(@{$signal_neg_pool_link_tf{$key}},"$int_lay_nm[$i].exc_tf_a_${itn}");
			}
		}
	}
}

our %signal_neg_pool_link_srna=();
for($i=0;$i<$n_in;$i++){
        my $key=$nsg[$i];
        @{$signal_neg_pool_link_srna{$key}}=();
}

#### signal neg pools to internal layer gates -- on RBS
for($i=0; $i<$sol_cl[$solu]; $i++){
	@tmpa=();
	if($sol_rbs[$solu][$i] ne ""){
		@tmpa=split(//,$sol_rbs[$solu][$i]);
		for($j=0; $j<scalar(@tmpa); $j++){
			my $key=$tmpa[$j];
			if($tmpa[$j] =~ /[ABCD]/){	
				if($tmpa[$j] eq 'A'){
					$ntn=$neg_state[0];
					$neg_state[0]++;
				}elsif($tmpa[$j] eq 'B'){
					$ntn=$neg_state[1];
					$neg_state[1]++;
				}elsif($tmpa[$j] eq 'C'){
					$ntn=$neg_state[2];
					$neg_state[2]++;
				}elsif($tmpa[$j] eq 'D'){
					$ntn=$neg_state[3];
					$neg_state[3]++;
				}
				$itn=$int_state[$i][2];
				$int_state[$i][2]++;

				push(@{$signal_neg_pool_link_srna{$key}},"$int_lay_nm[$i].exc_rf_${itn}");
			}
		}
	}
}

##multiple links# signal neg pools' links --> exc_tf terminal
for($i=0;$i<$n_in;$i++){
        my $key=$nsg[$i];
        my $dim=scalar(@{$signal_neg_pool_link_tf{$key}});
	my $si=lc($key);
        if($dim > 0){
print OUT "
   (\"${si}_neg_pool_link\"
    :terminals(\"${si}_neg_pool.exc_tf_a\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"${$signal_neg_pool_link_tf{$key}}[$j]\"";
        }
        print OUT "))";
        }
}

##multiple links# signal neg pools' links --> exc_srna terminal
for($i=0;$i<$n_in;$i++){
        my $key=$nsg[$i];
        my $dim=scalar(@{$signal_neg_pool_link_srna{$key}});
        my $si=lc($key);
        if($dim > 0){
print OUT "
   (\"${si}_neg_pool_link\"
    :terminals(\"${si}_neg_pool.exc_srna\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"${$signal_neg_pool_link_srna{$key}}[$j]\"";
        }
        print OUT "))";
        }
}



#### internal gates to their pools
my $rp=1;		# counting the int_R pool terminals
my $sp=1;
my $ap=1;
my $bp=1;
my $lp=1;
my $op=1;
my $kp=1;
my $ep=1;
our %int_pool_tf_link=();
our %int_pool_srna_link=();

foreach $i ('R','S','A','B'){
        my $key=$i;
        @{$int_pool_tf_link{$key}}=();
}

foreach $i ('l','o','k','e'){
        my $key=$i;
        @{$int_pool_srna_link{$key}}=();
}

for($i=0; $i<$sol_cl[$solu]; $i++){
	@namea=split(/_/,$int_lay[$solu][$i]);
	my $key=$namea[1];
	if($namea[1] eq 'R'){
		push(@{$int_pool_tf_link{$key}},"${int_lay_nm[$i]}.out_tf");
	}elsif($namea[1] eq 'S'){
		push(@{$int_pool_tf_link{$key}},"${int_lay_nm[$i]}.out_tf");
	}elsif($namea[1] eq 'A'){
		push(@{$int_pool_tf_link{$key}},"${int_lay_nm[$i]}.out_tf");
	}elsif($namea[1] eq 'B'){
		push(@{$int_pool_tf_link{$key}},"${int_lay_nm[$i]}.out_tf");
	}elsif($namea[1] eq 'l'){
		push(@{$int_pool_srna_link{$key}},"${int_lay_nm[$i]}.out_rna");
	}elsif($namea[1] eq 'o'){
		push(@{$int_pool_srna_link{$key}},"${int_lay_nm[$i]}.out_rna");
	}elsif($namea[1] eq 'k'){
		push(@{$int_pool_srna_link{$key}},"${int_lay_nm[$i]}.out_rna");
	}elsif($namea[1] eq 'e'){
		push(@{$int_pool_srna_link{$key}},"${int_lay_nm[$i]}.out_rna");
	}
}

##multiple links# int pool links --> in_tf terminal
foreach $i ('R','S','A','B'){
        my $key=$i;
        my $dim=scalar(@{$int_pool_tf_link{$key}});
        if($dim > 0){
print OUT "
   (\"int_${key}_pool_link\"
    :terminals(\"int_${key}_pool.in_tf\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"${$int_pool_tf_link{$key}}[$j]\"";
        }
print OUT "))";
	}
}

##multiple links# int pool links --> in_srna terminal
foreach $i ('l','o','k','e'){
        my $key=$i;
        my $dim=scalar(@{$int_pool_srna_link{$key}});
        if($dim > 0){
print OUT "
   (\"int_${key}_pool_link\"
    :terminals(\"int_${key}_pool.in_srna\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"${$int_pool_srna_link{$key}}[$j]\" ";
        }
print OUT "))";
	}
}

$f_state[0][0]=1;
$f_state[0][1]=1;


# int_(rf)_pools to final gate

@ointa=@int_name;
for($j=0; $j<$num_p; $j++){
print OUT "
   (\"int_${ointa[$j]}_pool_${second_fa_nm[0]}\"";
				if($ointa[$j] eq 'R' || $ointa[$j] eq 'S' || $ointa[$j] eq 'A' || $ointa[$j] eq 'B'){
					$etn=$f_state[0][0];				
					$f_state[0][0]++;
print OUT "
    :terminals (\"int_${ointa[$j]}_pool.exc_tf_a\" \"${second_fa_nm[0]}.exc_tf_a_${etn}\"))";	
				}elsif($ointa[$j] eq 'l' || $ointa[$j] eq 'o' || $ointa[$j] eq 'k' || $ointa[$j] eq 'e'){
					$etn=$f_state[0][1];
					$f_state[0][1]++;
print OUT "
    :terminals (\"int_${ointa[$j]}_pool.exc_srna\" \"${second_fa_nm[0]}.exc_rf_${etn}\"))";
				}
}	
#### second_fa gate to its pool when present
if($second_fa[0] =~ /R$/){
print OUT "
   (\"${second_fa_nm[0]}_fin_pool\"
    :terminals (\"${second_fa_nm[0]}.out_tf\" \"fin_pool.in_tf\"))";
}elsif($second_fa[0] =~ /l$/){
print OUT "
   (\"${second_fa_nm[0]}_fin_pool\"
    :terminals (\"${second_fa_nm[0]}.out_rna\" \"fin_pool.in_srna\"))";
}

#### fin_pool with second_fa[1] gate (NOT)
if($second_fa[0] =~ /R$/){
print OUT "
   (\"fin_pool_${second_fa_nm[1]}\"
    :terminals (\"fin_pool.exc_tf_a\" \"${second_fa_nm[1]}.exc_tf_a_1\"))";
}elsif($second_fa[0] =~ /l$/){
print OUT "
   (\"fin_pool_${second_fa_nm[1]}\"
    :terminals (\"fin_pool.exc_srna\" \"${second_fa_nm[1]}.exc_rf_1\"))";
}

our @exc_pol_link=();
our @in_pol_link=();
our @exc_r_link=();
our @in_r_link=();

#### polpool and ribpool to the gates
for($i=0; $i<$n_in; $i++){
	if($input_l[$solu][$i] eq "yes1"){
		next;
	}
	push(@exc_pol_link,"${input_l_nm[$i]}.exc_pol");
	push(@in_pol_link,"${input_l_nm[$i]}.out_pol");
        push(@exc_r_link,"${input_l_nm[$i]}.exc_r");
        push(@in_r_link,"${input_l_nm[$i]}.out_r");
}

for($i=0; $i<$sol_cl[$solu]; $i++){
	push(@exc_pol_link,"${int_lay_nm[$i]}.exc_pol");
        push(@in_pol_link,"${int_lay_nm[$i]}.out_pol");

	if($int_lay[$solu][$i] =~ /R$/ || $int_lay[$solu][$i] =~ /S$/ || $int_lay[$solu][$i] =~ /A$/ || $int_lay[$solu][$i] =~ /B$/){
	        push(@exc_r_link,"${int_lay_nm[$i]}.exc_r");
        	push(@in_r_link,"${int_lay_nm[$i]}.out_r");
	}
}

for($i=0; $i<scalar(@second_fa); $i++){
        push(@exc_pol_link,"${second_fa_nm[$i]}.exc_pol");
        push(@in_pol_link,"${second_fa_nm[$i]}.out_pol");

	if($second_fa[$i] =~ /R$/ || $second_fa[$i] =~ /A$/ || $second_fa[$i] =~ /f$/){
	        push(@exc_r_link,"${second_fa_nm[$i]}.exc_r");
        	push(@in_r_link,"${second_fa_nm[$i]}.out_r");
	}
}


##multiple links# pol --> exc_pol/in_pol terminal
	my $dim=scalar(@exc_pol_link);
print OUT "
   (\"Polpool_exc_pol_link\"
    :terminals(\"Polpool.exc_pol\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$exc_pol_link[$j]\"";
        }
        print OUT "))";

	my $dim=scalar(@in_pol_link);
print OUT "
   (\"Polpool_in_pol_link\"
    :terminals(\"Polpool.in_pol\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$in_pol_link[$j]\"";
        }
        print OUT "))";

##multiple links# r --> exc_r/in_r terminal
        my $dim=scalar(@exc_r_link);
print OUT "
   (\"Ribpool_exc_r_link\"
    :terminals(\"Ribpool.exc_r\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$exc_r_link[$j]\"";
        }
        print OUT "))";

        my $dim=scalar(@in_r_link);
print OUT "
   (\"Polpool_in_r_link\"
    :terminals(\"Ribpool.in_r\"";
        for($j=0;$j<$dim;$j++){
                print OUT " \"$in_r_link[$j]\"";
        }
        print OUT "))";

print OUT ")";

print OUT ")"; # define module
} # end sub
	
1;
