#! /usr/bin/perl
use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
our @num_cl;
our @final_c;
our @fm_list;

# final_c - columns (each row is a possible configuration)
# 0: single/disj
# 1: out_int
# 2: first_f
# 3: second_f
# 4: gene_n
# 5: leak_p
# 6: (A)
# 7: (R)
# 8: (k)
# 9: (l)


sub final_layer{
my $s_kind=$_[0];		# solution kind
my $free=$_[1];			# number of free RBSs
my $cc=0;			# configuration-counter, first entry in @final_c; 
my $i;
my $qt;
my $re;
my $u_cl;
my $d_cl;
my $t_cl;
my $q_cl;
my $df;

####### Particular case: only one clause in the formula
if($num_cl[$sk] == 1){
init($cc);
	$final_c[$cc][0] = "disj";
	if($s_kind eq "POS"){
		if($free == 0){
			$final_c[$cc][1] .= "R";
			$final_c[$cc][2] = "";
			$final_c[$cc][3] = "not1R_f";
			$final_c[$cc][4] = $num_cl[$sk]+1;
			$final_c[$cc][5] = 0;
			$final_c[$cc][7]++;
		}elsif($free == 1){
			$final_c[$cc][1] .= "l";
			$final_c[$cc][2] = "";
			$final_c[$cc][3] = "not1l_f";
			$final_c[$cc][4] = $num_cl[$sk]+1;
			$final_c[$cc][5] = 0;
			$final_c[$cc][9]++;
		}
	}elsif($s_kind eq "SOP"){
			$final_c[$cc][1] .= "f";
			$final_c[$cc][2] = "";
			$final_c[$cc][3] = "";
			$final_c[$cc][4] = $num_cl[$sk];
			$final_c[$cc][5] = 0;
	}
}
# $cc must be equal to 0
if($num_cl[$sk] > 1){
######### Single solutions
init($cc);
### case 1) The same TF is produced by every gate. Always possible
$final_c[$cc][0] = "single";		 
if($s_kind eq "POS"){
	for($i=0; $i<$num_cl[$sk]; $i++){
		$final_c[$cc][1] .= "R";
	}
	$final_c[$cc][2] = "";
	$final_c[$cc][3] = "nor1R_f";		
	$final_c[$cc][4] = $num_cl[$sk]+1;
	$final_c[$cc][5] = 1;	#2**$num_cl[$sk];
	$final_c[$cc][7]++;
}elsif($s_kind eq "SOP"){
	for($i=0; $i<$num_cl[$sk]; $i++){
		$final_c[$cc][1] .= "A";
	}
	$final_c[$cc][2] = "";
	$final_c[$cc][3] = "or1A_f";		
	$final_c[$cc][4] = $num_cl[$sk]+1;
	$final_c[$cc][5] = 1;	#2**$num_cl[$sk];
	$final_c[$cc][6]++;
}

### case 2) Two different TFs are produced. Always possible
$cc++;
init($cc);
$final_c[$cc][0] = "single";
$qt=int($num_cl[$sk]/2);
$re=$num_cl[$sk]%2;
$u_cl=$qt+$re;
$d_cl=$qt;


if($s_kind eq "POS"){
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "S";	
	}	
	$final_c[$cc][2] = "";
	$final_c[$cc][3] = "nor2RR_f";		
	$final_c[$cc][4] = $num_cl[$sk]+1;
	$final_c[$cc][5] = 2;	#penalty_2($u_cl,$d_cl);
	$final_c[$cc][7] += 2;
}elsif($s_kind eq "SOP"){
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "A";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "B";	
	}	
	$final_c[$cc][2] = "";
	$final_c[$cc][3] = "or2AA_f";		
	$final_c[$cc][4] = $num_cl[$sk]+1;
	$final_c[$cc][5] = 2;	#penalty_2($u_cl,$d_cl);
	$final_c[$cc][6] += 2;
}

###### Additional possibilities due to the presence of free RBSs
if($free == 1){
	### case 3) One free RBS and one R produced by the other gates.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
        $u_cl=$num_cl[$sk]-1;	
	$d_cl=1;
	
	$final_c[$cc][1] .= "l";
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor2Rl_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 2; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7]++;
		$final_c[$cc][9]++;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor2Rl_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 2; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9]++;
	}
   if($num_cl[$sk]-$free >= 2){
	### case 4) One free RBS and two Rs produced by the other gates.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
	$df=$num_cl[$sk]-1;
	$qt=int($df/2);
	$re=$df%2;
	$u_cl=$qt+$re;
	$d_cl=$qt;	
	
	$final_c[$cc][1] .= "l";
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "S";
	}
	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor3RRl_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 3; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9]++;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor3RRl_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 3; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7] +=3;
		$final_c[$cc][9]++;
	}
   }
}elsif($free > 1){
    if($num_cl[$sk]-$free >= 1){	
	### case 5) One type of locks and one type of Rs.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
        $u_cl=$free;		# number of gates producing the lock
	$d_cl=$num_cl[$sk]-$u_cl;	# number of gates producing the R
	
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "l";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor2Rl_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 2; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7]++;
		$final_c[$cc][9]++;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor2Rl_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 2; #penalty_2($u_cl,$d_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9]++;
	}
     }
 	
     if($num_cl[$sk]-$free >= 2){	
	### case 6) One type of locks and two type of Rs.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
	$t_cl=$free;		        # number of gates producing the lock
	$df=$num_cl[$sk]-$t_cl;
	$qt=int($df/2);
	$re=$df%2;
	$u_cl=$qt+$re;			# number of gates producing R
	$d_cl=$qt;			# number of gates producing S
	

	for($i=0; $i<$t_cl; $i++){
		$final_c[$cc][1] .= "l";
	}
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "S";
	}
	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor3RRl_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 3;	# penalty_3($u_cl,$d_cl,$t_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9]++;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor3RRl_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 3;	#penalty_3($u_cl,$d_cl,$t_cl);
		$final_c[$cc][7] +=3;
		$final_c[$cc][9]++;
	}
     } 	

     if($num_cl[$sk]-$free >=1){	
	### case 7) Two types of locks and one type of Rs.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
	$u_cl=$num_cl[$sk]-$free;	# number of gates producing R
	$qt=int($free/2);
	$re=$free%2;
	$d_cl=$qt+$re;				# number of gates producing l
	$t_cl=$qt;                      	# number of gates producing o

	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "l";
	}
	for($i=0; $i<$t_cl; $i++){
		$final_c[$cc][1] .= "o";
	}
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor3Rll_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 3;	#penalty_3($u_cl,$d_cl,$t_cl);
		$final_c[$cc][7]++;
		$final_c[$cc][9] +=2;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor3Rll_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 3;	#penalty_3($u_cl,$d_cl,$t_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9] +=2;
	}
     }

     if($num_cl[$sk]-$free >=2){	 	
	### case 8) Two types of locks and two types of Rs.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
	$df=$num_cl[$sk]-$free;
	$qt=int($df/2);
	$re=$df%2;
	$u_cl=$qt+$re;				# number of gates producing R
	$d_cl=$qt;				# number of gates producing S

	$qt=int($free/2);
	$re=$free%2;
	$t_cl=$qt+$re;				# number of gates producing l
	$q_cl=$qt;                      	# number of gates producing o

	for($i=0; $i<$t_cl; $i++){
		$final_c[$cc][1] .= "l";
	}
	for($i=0; $i<$q_cl; $i++){
		$final_c[$cc][1] .= "o";
	}
	for($i=0; $i<$u_cl; $i++){
		$final_c[$cc][1] .= "R";
	}
	for($i=0; $i<$d_cl; $i++){
		$final_c[$cc][1] .= "S";
	}

	$final_c[$cc][2] = "";
	if($s_kind eq "POS"){
		$final_c[$cc][3] = "nor4RRll_f";
		$final_c[$cc][4] = $num_cl[$sk]+1;
		$final_c[$cc][5] = 4;	#penalty_4($u_cl,$d_cl,$t_cl,$q_cl);
		$final_c[$cc][7] +=2;
		$final_c[$cc][9] +=2;
	}elsif($s_kind eq "SOP"){
		$final_c[$cc][3] = "nor4RRll_R,not1R_f";
		$final_c[$cc][4] = $num_cl[$sk]+2;
		$final_c[$cc][5] = 4;	#penalty_4($u_cl,$d_cl,$t_cl,$q_cl);
		$final_c[$cc][7] +=3;
		$final_c[$cc][9] +=2;
	}
     }
	
     if($num_cl[$sk]-$free == 0){
	### case 9) One type of locks and no Rs.
	$cc++;
        init($cc);
	$final_c[$cc][0] = "single";
	if($s_kind eq "POS"){
        	for($i=0; $i<$num_cl[$sk]; $i++){
                	$final_c[$cc][1] .= "l";
        	}
        	$final_c[$cc][2] = "";
        	$final_c[$cc][3] = "nor1l_f";
        	$final_c[$cc][4] = $num_cl[$sk]+1;
        	$final_c[$cc][5] = 1; 	#2**$num_cl[$sk];
        	$final_c[$cc][9]++;
	}elsif($s_kind eq "SOP"){
        	for($i=0; $i<$num_cl[$sk]; $i++){
                	$final_c[$cc][1] .= "k";
        	}
        	$final_c[$cc][2] = "";
        	$final_c[$cc][3] = "or1k_f";
        	$final_c[$cc][4] = $num_cl[$sk]+1;
        	$final_c[$cc][5] = 1;	#2**$num_cl[$sk];
        	$final_c[$cc][8]++;
	}

	### case 10) Two types of locks and no Rs.
	$cc++;
	init($cc);
	$final_c[$cc][0] = "single";
	$qt=int($num_cl[$sk]/2);
	$re=$num_cl[$sk]%2;
	$u_cl=$qt+$re;
	$d_cl=$qt;
        for($i=0; $i<$u_cl; $i++){
                $final_c[$cc][1] .= "l";
        }
        for($i=0; $i<$d_cl; $i++){
                $final_c[$cc][1] .= "o";
        }
	if($s_kind eq "POS"){
        	$final_c[$cc][2] = "";
        	$final_c[$cc][3] = "nor2ll_f";
        	$final_c[$cc][4] = $num_cl[$sk]+1;
        	$final_c[$cc][5] = 2;	#penalty_2($u_cl,$d_cl);
        	$final_c[$cc][9] += 2;
	}elsif($s_kind eq "SOP"){
        	$final_c[$cc][2] = "";
        	$final_c[$cc][3] = "nor2ll_R,not1R_f";
        	$final_c[$cc][4] = $num_cl[$sk]+2;
        	$final_c[$cc][5] = 2;	#penalty_2($u_cl,$d_cl);
		$final_c[$cc][7]++; 
        	$final_c[$cc][9] += 2;
	}
     }

}  # end if -(rbs_free == 1)-

}  # end if-($num_cl >1)-
	
return($cc);

#----------------------------------------------------------------------------------------
}

sub penalty_2{
my $u=$_[0];
my $d=$_[1];
my $py;
	if($u == 1){
		if($d == 1){
			$py = 0;
		}else{
			$py = 2**$d;
		}
	}elsif($u > 1){
		if($d == 1){
			$py = 2**$u;
		}else{
			$py = 2**$u+2**$d;
		}
	}
	return($py);
}
#----------------------------------------


sub penalty_3{
my $u=$_[0];
my $d=$_[1];
my $t=$_[2];
my $py;
	if($u == 1){
		if($d == 1){
			if($t == 1){
				$py = 0;
			}else{
				$py = 2**$t;
			}
		}elsif($d > 1){
			if($t == 1){
				$py = 2**$d;
			}else{
				$py = 2**$d+2**$t;
			}
		}
	}elsif($u > 1){
		if($d == 1){
			if($t == 1){
				$py = 2**$u;
			}else{
				$py = 2**$u+2**$t;
			}
		}elsif($d > 1){
			if($t == 1){
				$py = 2**$u+2**$d;
			}else{
				$py = 2**$u+2**$d+2**$t;
			}
		}
	}

	return($py);
}
#----------------------------------------


sub penalty_4{
my $u=$_[0];
my $d=$_[1];
my $t=$_[2];
my $q=$_[3];
my $py;
	if($u == 1){
		if($d == 1){
			if($t == 1){
				if($q == 1){
					$py = 0;
				}else{
					$py = 2**$q;
				}
			}elsif($t > 1){
				if($q == 1){
					$py = 2**$t;
				}else{
					$py = 2**$t+2**$q;
				}
			}
		}elsif($d > 1){
			if($t == 1){
				if($q == 1){
					$py = 2**$d;
				}else{
					$py = 2**$d+2**$q;
				}
			}elsif($t > 1){
				if($q == 1){
					$py = 2**$d+2**$t;
				}else{
					$py = 2**$d+2**$t+2**$q;
				}
			}
		}
	}elsif($u > 1){
		if($d == 1){
			if($t == 1){
				if($q == 1){
					$py = 2**$u;
				}else{
					$py = 2**$u+2**$q;
				}
			}elsif($t > 1){
				if($q == 1){
					$py = 2**$u+2**$t;
				}else{
					$py = 2**$u+2**$t+2**$q;
				}
			}
		}elsif($d > 1){
			if($t == 1){
				if($q == 1){
					$py = 2**$u+2**$d;
				}else{
					$py = 2**$u+2**$d+2**$q;
				}
			}elsif($t > 1){
				if($q == 1){
					$py = 2**$u+2**$d+2**$t;
				}else{
					$py = 2**$u+2**$d+2**$t+2**$q;
				}
			}
		}
	}

	return($py);
}
#----------------------------------------


sub init{
my $cc=$_[0];
my $i;
	$final_c[$cc][1]="";
	for($i=6; $i<10; $i++){
		$final_c[$cc][$i] = 0;
	}
}
#----------------------------------------

1;

