#! /usr/bin/perl
# Calculating final layer schemes involving an extra (first_f) set of NOR gates
use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
our @num_cl;
our @final_c;

sub final_nor_and{
my $s_kind=$_[0];
my $free=$_[1];
my $cc=$_[2];

my $oi="";			# out_int
my $af=0;			# A number - for reg_fac
my $rf=0;			# R number - for reg_fac
my $lf=0;			# l number - for reg_fac
my $kf=0;			# k number - for reg_fac	
my $ln=$free;			# lock number
my $rn=$num_cl[$sk]-$ln;	# repressor number
my $max;
my $qt;
my $re;
my $norn;			# NOR number
my $i;
my $dr=$rn;			# deleting-repressors
my $dl=$ln;			# deleting-locks
my @norv;			# NOR vector
my @onor;			# output-nor vector
my @or_onor;			# ordered @onor
my $kn=0;			# keys-number
my $lgt;				
my $ff="";			# first-final
my $sf="";			# second-final
my $str="";


$cc++;
# Calculating out_int
for($i=0; $i<$free; $i++){
	$oi .= 'l';
	$lf++;
}
for($i=0; $i<$rn; $i++){
	$oi .= 'R';
	$rf++;
}

# Calculating the number of nor/not gates
if($rn >= $ln){
	$max=$rn;
}else{
	$max=$ln;
}

$qt=int($max/2);
$re=$max%2;

$norn=$qt+$re;

# Initializing the @norv and @onor vector
for($i=0;$i<$norn;$i++){
	$norv[$i] = "";
	$onor[$i] = "";
}

# Filling the NORs with repressors
$i=0;
while($dr > 0){
	$norv[$i] .= 'R';
	$dr--;
	$i++;
	if($i == $norn){
		$i=0;
	}
}
	
# Filling the NOR of length one with a lock
for($i=0; $i<$norn; $i++){
	if(length($norv[$i]) == 1){
		$norv[$i] .= 'l';
		$dl--;
	}
}

$i=0;
# Filling the NORs with locks
while($dl > 0){
	$norv[$i] .= 'l';	
	$dl--;
	$i++;
	if($i == $norn){
		$i=0;
	}
}

# Assigning an output to each NOR
if($norn > 1){
	for($i=0; $i<$norn; $i++){
		if($norv[$i] =~/l/){
			$onor[$i] = 'A';		
			$af++;
		}
		if($norv[$i] !~ /l/ && $kn < 2){
			$onor[$i] = 'k';
			$kf++;
			$kn++;
		}elsif($norv[$i] !~ /l/ && $kn >= 2){
			$onor[$i] = 'A';
			$af++;
		}
	}
}
	
# Writing the first-final sublayer
if($norn > 1){
	for($i=0; $i<$norn; $i++){
		$lgt=length($norv[$i]);
		if($lgt > 1){
			$str = "nor${lgt}"."$norv[$i]".'_'."$onor[$i]";
		}else{
			$str = "not${lgt}"."$norv[$i]".'_'."$onor[$i]";		
		}
		$ff .= "$str";
		$ff .= ',';	
	}
}else{
	$ff="";
}	

$ff =~ s/,$//;

# Ordering the first-final sublayer outputs - @onor
@or_onor=();
for($i=0; $i<$norn; $i++){
	if($onor[$i] eq 'A'){
		unshift(@or_onor,'A');
	}else{
		push(@or_onor,'k');
	}
}


# Writing the second-final sublayer
if($s_kind eq "POS"){
	if($norn > 1){
		$sf = "and"."$norn";	
		for($i=0; $i<$norn; $i++){
			$sf .= "$or_onor[$i]";
		}
		$sf .= "_f";	
	}else{
		$lgt=length($norv[0]);
		$sf="nor"."$lgt"."$norv[0]"."_f";
	}
}elsif($s_kind eq "SOP"){			# POS scheme, negated at the end
	my $k_flag=0;
	if($norn > 1){
		$sf = "and"."$norn";	
		for($i=0; $i<$norn; $i++){
			$sf .= "$or_onor[$i]";
			if($or_onor[$i] eq 'k'){
				$k_flag=1;
			}
		}
		if($k_flag == 0){
			$sf .= "_l,not1l_f";
			$lf++;
		}else{
			$sf .= "_R,not1R_f";
			$rf++;
		}	
	}else{
		$lgt=length($norv[0]);
		$sf="nor"."$lgt"."$norv[0]"."_R,not1R_f";
		$rf++;
	}
}

# Adding the new solution to final_c

$final_c[$cc][0] = "disj NOR-(N)AND";
$final_c[$cc][1] = $oi;
$final_c[$cc][2] = $ff;
$final_c[$cc][3] = $sf;
if($s_kind eq "POS"){
	$final_c[$cc][4] = $num_cl[$sk]+$norn+1;
}else{
	$final_c[$cc][4] = $num_cl[$sk]+$norn+2;
} 
$final_c[$cc][5] = 0;
$final_c[$cc][6] = $af;
$final_c[$cc][7] = $rf;
$final_c[$cc][8] = $kf;	
$final_c[$cc][9] = $lf;


if($s_kind eq "SOP"){		# Solution with a NAND as a second_f gate
	if($norn == 2){
		$cc++;
		$af=0;
		$kf=0;
		$ff="";
		$sf="";

		# Assigning a new output to each NOR
        	for($i=0; $i<$norn; $i++){
                        $onor[$i] = 'R';
			$rf++;
                }

		# Writing the new first-final sublayer
		$str="";
        	for($i=0; $i<$norn; $i++){
                	$lgt=length($norv[$i]);
                        $str = "nor${lgt}"."$norv[$i]".'_'."$onor[$i]";
                	$ff .= "$str";
                	$ff .= ',';
        	}

		$ff =~ s/,$//;

		# Writing the new second-final sublayer
                $sf = "nand"."$norn";
                for($i=0; $i<$norn; $i++){
                        $sf .= "$onor[$i]";
                }
                $sf .= "_f";
   
		# Adding the new solution to final_c
		$final_c[$cc][0] = "disj NOR-(N)AND";
		$final_c[$cc][1] = $oi;
		$final_c[$cc][2] = $ff;
		$final_c[$cc][3] = $sf;
        	$final_c[$cc][4] = $num_cl[$sk]+$norn+1;
		$final_c[$cc][5] = 0;
		$final_c[$cc][6] = $af;
		$final_c[$cc][7] = $rf;
		$final_c[$cc][8] = $kf;
		$final_c[$cc][9] = $lf;
	}
}

return($cc);

}
		
1;
