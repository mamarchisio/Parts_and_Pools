#! /usr/bin/perl
use strict;
use InputGates;
use InternalGates;
use FinalGates;
use ConnectionMakerDisj;
use ConnectionMakerSingle;
use ConnectionMakerCompact_POS;
use ConnectionMakerCompact_SOP;
use ConnectionMakerMixed;

sub circuit_scheme{
our $solu=$_[0];

our $n_in;
our @sol_cl;
our @sol_class;
our @sol_num_in;
our @sg;
our @nsg;
our @sol_prm;
our @sign_s;
our @sol_rbs;
our @input_l;
our @int_lay;
our @out_int;
our @first_f;
our @second_f;
our @type_s;
our @first_fa=();
our @second_fa=();
my $i;
my $gate;

our @num_in;
our $sk;

$n_in=$sol_num_in[$solu];
print "SCHEME $n_in $num_in[$sk] \n";
# Input layer construction
for($i=0; $i<$n_in; $i++){
	input_gate($input_l[$solu][$i],$type_s[$solu]);
}

# Internal layer construction
for($i=0; $i<$sol_cl[$solu]; $i++){
	$gate = $int_lay[$solu][$i];
	print "main:  $i \t $gate \n";
	if($gate =~ /not/){
		internal_not($i);
	}
	if($gate =~ /nor/){
		internal_nor($i);
	}
	if($gate =~ /yes/){
		internal_yes($i);
	}
	if($gate =~ /and/){
		internal_and($i);
	}
	
}

# Final layer construction
@first_fa=split(/,/,$first_f[$solu]);

for($i=0; $i<scalar(@first_fa); $i++){
	$gate = $first_fa[$i];
	print "main:  $i \t $gate \n";
	final_gate($gate);
}

@second_fa=split(/,/,$second_f[$solu]);
for($i=0; $i<scalar(@second_fa); $i++){
	$gate = $second_fa[$i];
	print "main:  $i \t $gate \n";
	final_gate($gate);
}

if($sol_class[$solu] eq "single"){
	connections_single();
}elsif($type_s[$solu] eq "POS" && $sol_class[$solu] eq "compact"){
	connections_compact_POS();
}elsif($type_s[$solu] eq "SOP" && $sol_class[$solu] eq "compact"){
        connections_compact_SOP();
}elsif($sol_class[$solu] eq "mixed"){
        connections_mixed();
}else{
	connections_disj();
}

}

1;
