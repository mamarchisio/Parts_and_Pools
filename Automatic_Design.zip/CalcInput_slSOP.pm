#! /usr/bin/perl
use strict;
# Finding unique and degenerate input layers
our @num_in;
our @sg;
our @nsg;
our @sign;
our $sk;
our @reg_fac;
our @gene_n;
our @input_l;
our @sg_min;
our $fm_min;

sub all_inp_slSOP{
my $h_p=$_[0];

my @deg_il=();
my $i;
my $j;
my $sig;
my $nsig;
	
	for($i=0; $i<$num_in[$sk]; $i++){
		# unique solutions
		$sig=$sg[$i];
		$nsig=uc($sig);
		if($sign[$i][1] == 0){
			if(${$h_p}{$sig} eq 'p'){
				$deg_il[$i][0]="yes0";
			}else{
				$deg_il[$i][0]="yes1";
			}
			#print "$deg_il[$i][0] \n";					
		}
			
		if($sign[$i][0] != 0 && $sign[$i][1] != 0){
      		        for(my $j=0; $j<scalar(@sg_min); $j++){
		           if($nsig eq $sg_min[$j]){
		                $deg_il[$i][0]="not2";    # correction for only negated single literals
		           }
		        }

			if(${$h_p}{$sig} eq 'p' &&  ${$h_p}{$nsig} eq 'p'){	
				$deg_il[$i][0]="not0";
			}elsif(${$h_p}{$sig} eq 'p' &&  ${$h_p}{$nsig} eq 'r'){
				$deg_il[$i][0]="not1";
			}elsif(${$h_p}{$sig} eq 'r' &&  ${$h_p}{$nsig} eq 'p'){
				$deg_il[$i][0]="not2";
			}elsif(${$h_p}{$sig} eq 'r' &&  ${$h_p}{$nsig} eq 'r'){
				$deg_il[$i][0]="not3";
			}

      		        for(my $j=0; $j<scalar(@sg_min); $j++){
		           if($nsig eq $sg_min[$j]){
		                $deg_il[$i][0]="not2";    # correction for only negated single literals
		           }
		        }
		}

		# degenerate solutions
		if($sign[$i][0] == 0){
			for($j=0; $j<2; $j++){
				if($j == 0){
					if(${$h_p}{$nsig} eq 'p'){
						$deg_il[$i][$j]="not2";
					}else{
						$deg_il[$i][$j]="not3";
					}
				}elsif($j == 1){
					if(${$h_p}{$nsig} eq 'p'){
						$deg_il[$i][$j]="not0";
					}else{
						$deg_il[$i][$j]="not1";
					}
				}
			}
		}
	}

	return(@deg_il);
}
#----------------------------------------------------------------------

sub inp_config_slSOP{
my $sd=$_[0];	# signal degeneracy
my $di=$_[1];	# degenerate input layers

my @input_c=();
my $i0;
my $i1;
my $i2;
my $i3;
my $cfg;

	$cfg=0;
	if($sg[0] ne ""){
		for($i0=0; $i0<${$sd}[0];$i0++){
			if($sg[1] ne ""){
				for($i1=0; $i1<${$sd}[1];$i1++){
					if($sg[2] ne ""){
						for($i2=0; $i2<${$sd}[2];$i2++){
							if($sg[3] ne ""){
								for($i3=0; $i3<${$sd}[3];$i3++){			
									$input_c[$cfg][0]=${$di}[0][$i0];
									$input_c[$cfg][1]=${$di}[1][$i1];
									$input_c[$cfg][2]=${$di}[2][$i2];
									$input_c[$cfg][3]=${$di}[3][$i3];
									$cfg++;								
								}
							}else{
								
								$input_c[$cfg][0]=${$di}[0][$i0];
								$input_c[$cfg][1]=${$di}[1][$i1];
								$input_c[$cfg][2]=${$di}[2][$i2];
								$cfg++;
							}
						}
					}else{
						$input_c[$cfg][0]=${$di}[0][$i0];
						$input_c[$cfg][1]=${$di}[1][$i1];
						$cfg++;
					}
				}
			}else{
				$input_c[$cfg][0]=${$di}[0][$i0];
				$cfg++;
			}
		}
	}

	my $i;
	my $j;
	for($i=0;$i<$cfg;$i++){
		for($j=0;$j<4;$j++){
#			print "$i \t $input_c[$i][$j] \n";		
		}
	}
	
	return(@input_c);
}
#----------------------------------------------------------------------


sub il_cost_slSOP{		# counting the regulatory factors due to the input layer
my $s_kind=$_[0];
my $sl=$_[1];
my $i;	

		for($i=0; $i<$num_in[$sk]; $i++){
			if($input_l[$sl][$i] eq "yes0"){
				$reg_fac[$sl][0]++;    # adding an activator
				$gene_n[$sl]++;
				next;
			}				

			if($input_l[$sl][$i] eq "yes1"){
				next;
			}				
			
			if($input_l[$sl][$i] eq "not0"){
				$reg_fac[$sl][0] += 2;
				$reg_fac[$sl][3] += 1;
				$gene_n[$sl] +=3;
				next;
			}
			
			if($input_l[$sl][$i] eq "not1"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;
				$gene_n[$sl] +=3;
				next;
			}

			if($input_l[$sl][$i] eq "not2"){
			  if($fm_min =~ $nsg[$i]){    
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=2;
			      }else{
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=2;
			      }
				next;
			}	
				
			if($input_l[$sl][$i] eq "not3"){
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;	
				$gene_n[$sl] +=2;
				next;
			}
	
		}
	}
#----------------------------------------------------------------------


1;
