%% Simulations 
options = odeset('AbsTol', 1e-12);
 entries=8;          
 varout = cell(1,entries);
 vart = cell(1,entries);
 out_number=53;          %%% to be changed for other solution simulations
 filename='digital_c';          %%% to be changed for other solution simulations
 i=1;
 wbh = waitbar(0, 'Starting first simulation...');
 for a=0:1
    if a == 0
        ia=0.0;
    else
        ia=1.0e-9;
    end 
     for b=0:1
        if b == 0
            ib=0.0;
        else
            ib=1.0e-9;
        end
         for c=0:1
            if c == 0
                ic=0.0;
            else
                ic=1.0e-9;
            end           
                [t,x]=ode15s(filename, 0:10:50000, [], options,ia,ib,ic);  % normally ode15s or ode23t                
                t0Index = find(t>=20000, 1, 'first');
                
                t = t(t0Index:end)-t(t0Index);
                x = x(t0Index:end, :);
                varout{i} = x(:,out_number); 
                vart{i} = t;
                wbh = waitbar(i/entries,wbh, sprintf('Finished simulation %g of %g...',i,entries));
                i=i+1;  
         end
     end
 end
 
 close(wbh);
 

 otp = {'000','001','010','011','100','101','110','111'};
 
 %% Plot results
 figure();
 hold on;
 
 lineSpec = {'b','r','k','c','g','m','y','b:'};
 for i=1:entries     
     plot(vart{i}, varout{i}, lineSpec{i});
 end
 
 legend('000','001','010','011','100','101','110','111');
 xlabel('Time (s)');
 ylabel('Concentration (M)');
 hold off;
