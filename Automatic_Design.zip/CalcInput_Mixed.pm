#! /usr/bin/perl
use strict;
use InputGates;
our @input_l;
our $two;

sub input_layer_mixed{
my $sl=$_[0];

if($two =~ /[abcd]/){
    $input_l[$sl][0]="yes1i";
    $input_l[$sl][1]="yes1i";
#    input_gate("yes1i","mixed");	
  }else{
    $input_l[$sl][0]="not1c";
    $input_l[$sl][1]="not1c";
#    input_gate("not1c","mixed");
  }

}
		
#----------------------------------------------------------------------
				
1;
