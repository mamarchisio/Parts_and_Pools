#! /usr/bin/perl
use strict;
our @out_int;
our @num_cl;
our @lg_cl;
our @v_cl=();
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $sk;
our @v_oc;
our @lg_ocl;

sub internal_layer_slPOS{
my $s_kind=$_[0];
my $sl=$_[1];

my $i;
my $j;
my $gate;
my $index;
my $g_sig;
my $prm;
my @sig_p;
my $n_sig;
my $rbs;
my @sig_r;
my @out_s=();
my $out;
my @uin;		# unordered input
my @oin;		# ordered input	
my $el;
	
@out_s=split(//,$out_int[$sl]);
for($i=0;$i<scalar(@v_oc);$i++){
  @uin=();
  @oin=();
  $gate="";
  @sig_p=();
  print "internal: $i \t $v_oc[$i] \t $lg_ocl[$i] \n";
#  if($lg_ocl[$i] == 1){ 
#    $gate="not1";
#  }
  # else{
  ##  $index=$lg_ocl[$i];
  #  $gate="nor".$index;
  #}
  
  $prm=$sol_prm[$sl][$i];
  @sig_p=split(//,$prm);
  $n_sig=scalar(@sig_p); 
  for($j=0; $j<$n_sig; $j++){	 # every signal to the promoter wants a repressor on the internal gate
    if($sig_p[$j] =~ /[abcd]/){
      push(@uin,"Ri");
    }else{
      push(@uin,"Ra");
    }
  }

  $rbs=$sol_rbs[$sl][$i];
  @sig_r=split(//,$rbs);
  $n_sig=scalar(@sig_r);
  for($j=0; $j<$n_sig; $j++){
    if($sig_r[$j] =~ /[abcd]/){ # every positive signal to the rbs is not accompanied by any regulatory factor
      push(@uin,'c');
    }
    if($sig_r[$j] =~ /[ABCD]/){ # every negative signal to the rbs requires a lock
      push(@uin,'l');
    }
  }
	
  $g_sig=scalar(@sig_p)+scalar(@sig_r); # CORR 24/11/10

  if($lg_ocl[$i] == 1){
    $gate="not1";
  }else{
    $index=$g_sig;
    $gate="nor".$index;
  }
		
  # Reordering the input -- Ri Ra l c
  foreach $el ("Ri","Ra",'l','c'){
    for($j=0; $j<scalar(@uin); $j++){
      if($uin[$j] eq $el){
	push(@oin,$el);
      }
    }
  }

  # Adding the input to the gate
  for($j=0; $j<scalar(@oin); $j++){
    $gate .=$oin[$j];
  }
  
  $out=$out_s[$i];
  $gate .= "_";
  $gate .= "$out";
  $int_lay[$sl][$i]=$gate;
}
}		
#----------------------------------------------------------------------


sub re_out_int_slPOS{
my $sl=$_[0];

my @new_outa=();
my @tmp=split(//,$out_int[$sl]);
my $i;
my $j;
my $loi="";

	for($i=0;$i<scalar(@v_oc);$i++){
		$new_outa[$i]="no";
	}

	f_l:for($i=0;$i<scalar(@v_oc);$i++){
		if($tmp[$i] eq 'l'){
			for($j=0;$j<scalar(@v_oc);$j++){
				if($sol_rbs[$sl][$j] eq "" && $new_outa[$j] eq "no"){
						$new_outa[$j] = $tmp[$i];
						next f_l;
				}
			}
		}
	}	

	s_l:for($i=0;$i<scalar(@v_oc);$i++){
		if($tmp[$i] eq 'R'){
			for($j=0;$j<scalar(@v_oc);$j++){
				if($new_outa[$j] eq "no"){
					$new_outa[$j] = $tmp[$i];
					next s_l;
				}
			}
		}
	}							

	for($i=0;$i<scalar(@v_oc);$i++){
		$loi .= $new_outa[$i];
	}
	$out_int[$sl]=$loi;
}
#----------------------------------------------------------------------








				
1;
