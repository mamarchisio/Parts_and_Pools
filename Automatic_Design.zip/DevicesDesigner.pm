#! /usr/bin/perl
use strict;

sub design_long{
my $name=$_[0];
my $pro=$_[1];
my $rbs=$_[2];
my $cod=$_[3];
my $ter=$_[4];
my $bn;
my @dev;
my $sips_1=0;
my $sips_2=0;

my $filename=$name.".mdl";

$bn=$name;
$bn =~ s/[1234]/_/;
@dev=split(/_/,$bn);

open (OUT,">$filename"); 
print OUT "
(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$dev[0].png\"
  :geometry-width \"900\"
  :geometry-height \"300\"";

# terminals
print OUT "
  :terminals	
  ((\"exc_pol\"
    :is-eq-to \"$pro.exc_pol\"
)";

if($pro =~ /Ri/ || $pro =~ /Ai/){
print OUT "
   (\"exc_tf_a_1\"
    :is-eq-to \"$pro.exc_tf_a_1\")	
   (\"exc_sig_1\"
    :is-eq-to \"$pro.exc_sig_1\"	
)";
}

if($pro =~ /RiRi/ || $pro =~ /AiAi/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\")	
   (\"exc_sig_2\"
    :is-eq-to \"$pro.exc_sig_2\"	
)";
}

if(($pro =~ /Ra/ && $pro !~ /RiRa/) || ($pro =~ /Aa/ && $pro !~ /AiAa/)){
print OUT "
   (\"exc_tf_a_1\"
    :is-eq-to \"$pro.exc_tf_a_1\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_1");
#	$sips_1=1;

}

if($pro =~ /RiRa/ || $pro =~ /AiAa/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_2");
#	$sips_2=1;
}

if($pro =~ /RaRa/ || $pro =~ /AaAa/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_2");
#	$sips_2=1;
}

print OUT "
   (\"exc_r\"
    :is-eq-to \"$rbs.exc_r\"
)";

if($rbs !~ "r0"){
print OUT "
   (\"exc_rf_1\"
    :is-eq-to \"$rbs.exc_rf_1\"	
)";
}

if($rbs =~ /cc/ || $rbs =~ /cl/ || $rbs =~ /ll/ || $rbs =~ /ii/ || $rbs =~ /ik/ || $rbs =~ /kk/){
print OUT "
   (\"exc_rf_2\"
    :is-eq-to \"$rbs.exc_rf_2\"	
)";
}

print OUT "
   (\"out_r\"
    :is-eq-to \"$cod.out_r\"
)";

if($cod =~ "tf"){
print OUT "
   (\"out_tf\"
    :is-eq-to \"$cod.out_tf\"
)";
}

print OUT "
   (\"out_pol\"
    :is-eq-to \"$ter.out_pol\"
))";

# modules	
print OUT "
  :modules
  ((\"$pro\"
    :is-a \"$pro\"
    :geometry-x \"150\"
    :geometry-y \"150\")
   (\"$rbs\"
    :is-a \"$rbs\"
    :geometry-x \"350\"
    :geometry-y \"150\")
   (\"$cod\"
    :is-a \"$cod\"
    :geometry-x \"550\"
    :geometry-y \"150\")
   (\"$ter\"
    :is-a \"$ter\"
    :geometry-x \"750\"
    :geometry-y \"150\")";
if($sips_1 == 1){
print OUT "
   (\"sips_off_1\"
    :is-a \"sips_off_1\"
    :geometry-x \"280\"
    :geometry-y \"250\")";
}
if($sips_2 == 1){
print OUT "
   (\"sips_off_2\"
    :is-a \"sips_off_2\"
    :geometry-x \"360\"
    :geometry-y \"250\")";
}
print OUT ")";

# links

print OUT "
  :links
  ((\"${cod}out_pol_${ter}in_pol\"
    :terminals (\"$cod.out_pol\" \"$ter.in_pol\"))
   (\"${pro}out_pol_${rbs}in_pol\"
    :terminals (\"$pro.out_pol\" \"$rbs.in_pol\"))
   (\"${rbs}out_r_${cod}in_r\"
    :terminals (\"$rbs.out_r\" \"$cod.in_r\"))
   (\"${rbs}out_pol_${cod}in_pol\"
    :terminals (\"$rbs.out_pol\" \"$cod.in_pol\"))";

if($pro !~ /p0/){
print OUT "
   (\"${pro}out_pol_lk${rbs}in_pol_lk\"
    :terminals (\"$pro.out_pol_lk\" \"$rbs.in_pol_lk\"))";
}

if($rbs !~ /r0/){
print OUT "
   (\"${rbs}out_r_lk${cod}in_r_lk\"
    :terminals (\"$rbs.out_r_lk\" \"$cod.in_r_lk\"))";
}

print OUT "))";

}
#---------------------------------------------------------------


sub design_short{
my $name=$_[0];
my $pro=$_[1];
my $srna=$_[2];
my $ter=$_[3];
my $bn;
my @dev;
my $sips_1=0;
my $sips_2=0;

my $filename=$name.".mdl";

$bn=$name;
$bn =~ s/[1234]/_/;
@dev=split(/_/,$bn);

open (OUT,">$filename"); 
print OUT "
(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$dev[0].png\"
  :geometry-width \"900\"
  :geometry-height \"300\"";

# terminals
print OUT "
  :terminals	
  ((\"exc_pol\"
    :is-eq-to \"$pro.exc_pol\"
)";

if($pro =~ /Ri/ || $pro =~ /Ai/){
print OUT "
   (\"exc_tf_a_1\"
    :is-eq-to \"$pro.exc_tf_a_1\")	
   (\"exc_sig_1\"
   :is-eq-to \"$pro.exc_sig_1\")	
";
}

if($pro =~ /RiRi/ || $pro =~ /AiAi/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\")	
   (\"exc_sig_2\"
    :is-eq-to \"$pro.exc_sig_2\"	
)";
}

if(($pro =~ /Ra/ && $pro !~ /RiRa/) || ($pro =~ /Aa/ && $pro !~ /AiAa/)){
print OUT "
   (\"exc_tf_a_1\"
    :is-eq-to \"$pro.exc_tf_a_1\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_1");
#	$sips_1=1;

}

if($pro =~ /RiRa/ || $pro =~ /AiAa/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_2");
#	$sips_2=1;
}

if($pro =~ /RaRa/ || $pro =~ /AaAa/){
print OUT "
   (\"exc_tf_a_2\"
    :is-eq-to \"$pro.exc_tf_a_2\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_2");
#	$sips_2=1;
}

print OUT "
   (\"out_pol\"
    :is-eq-to \"$ter.out_pol\"
)
   (\"out_rna\"
    :is-eq-to \"$ter.out_rna\"
))";

# modules	
print OUT "
  :modules
  ((\"$pro\"
    :is-a \"$pro\"
    :geometry-x \"150\"
    :geometry-y \"150\")
   (\"$srna\"
    :is-a \"$srna\"
    :geometry-x \"450\"
    :geometry-y \"150\")
   (\"$ter\"
    :is-a \"$ter\"
    :geometry-x \"750\"
    :geometry-y \"150\")";
if($sips_1 == 1){
print OUT "
   (\"sips_off_1\"
    :is-a \"sips_off_1\"
    :geometry-x \"280\"
    :geometry-y \"250\")";
}
if($sips_2 == 1){
print OUT "
   (\"sips_off_2\"
    :is-a \"sips_off_2\"
    :geometry-x \"360\"
    :geometry-y \"250\")";
}
print OUT ")";

# links

print OUT "
  :links
  ((\"${srna}out_pol_${ter}in_pol\"
    :terminals (\"$srna.out_pol\" \"$ter.in_pol\"))
   (\"${pro}out_pol_${srna}in_pol\"
    :terminals (\"$pro.out_pol\" \"$srna.in_pol\"))";

if($pro !~ /p0/){
print OUT "	 
   (\"${pro}out_pol_lk${srna}in_pol_lk\"
    :terminals (\"$pro.out_pol_lk\" \"$srna.in_pol_lk\"))
   (\"${srna}out_pol_lk${ter}in_pol_lk\"
    :terminals (\"$srna.out_pol_lk\" \"$ter.in_pol_lk\"))";
}


print OUT "))";
}
#---------------------------------------------------------------


sub design_two_long{
my $name=$_[0];
my $pro1=$_[1];
my $rbs1=$_[2];
my $cod1=$_[3];
my $ter1=$_[4];
my $pro2=$_[5];
my $rbs2=$_[6];
my $cod2=$_[7];
my $ter2=$_[8];
my $bn;
my @dev;
my $sips_1=0;

my $filename=$name.".mdl";

$bn=$name;
$bn =~ s/[0123]/_/;
@dev=split(/_/,$bn);

my $pro2_n=$pro2;	# n means name
my $rbs2_n=$rbs2;
my $cod2_n=$cod2;
my $ter2_n=$ter2;

# check parts' name
if($pro2 eq $pro1){
	$pro2_n=$pro2."_2";
}
if($rbs2 eq $rbs1){
	$rbs2_n=$rbs2."_2";
}
if($cod2 eq $cod1){
	$cod2_n=$cod2."_2";
}
if($ter2 eq $ter1){
	$ter2_n=$ter2."_2";
}

open (OUT,">$filename"); 
print OUT "
(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$dev[0].png\"
  :geometry-width \"1800\"
  :geometry-height \"500\"";

# terminals
print OUT "
  :terminals	
  ((\"exc_pol\"
    :is-eq-to \"polsum.pol_b_out\"
)";

if($pro2_n =~ /Ri/ || $pro2_n =~ /Ai/){ # CORR 25/11/10
print OUT "
   (\"exc_tf_a\" 
    :is-eq-to \"$pro2_n.exc_tf_a_1\")	
   (\"exc_sig_1\"
    :is-eq-to \"$pro2_n.exc_sig_1\"	
)";
}


if($pro2_n =~ /Ra/ || $pro2_n =~ /Aa/){ #CORR 25/11/10
print OUT "
   (\"exc_tf_a\"
    :is-eq-to \"$pro2_n.exc_tf_a_1\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_1");
#	$sips_1=1;

}

print OUT "
   (\"exc_r\"
    :is-eq-to \"ribsum.r_b_out\"
)";

if($rbs1 !~ "r0"){
print OUT "
   (\"exc_rf_1\"
    :is-eq-to \"$rbs1.exc_rf_1\"	
)";
}

print OUT "
   (\"out_r\"
    :is-eq-to \"ribsum.r_out\"
)";

print OUT "
   (\"out_tf_i\"
    :is-eq-to \"$cod1.out_tf\"
)";

print OUT "
   (\"out_tf\"
    :is-eq-to \"$cod2_n.out_tf\"
)";

print OUT "
   (\"out_pol\"
    :is-eq-to \"polsum.pol_out\"
))";

# modules	
print OUT "
  :modules
  ((\"$pro1\"
    :is-a \"$pro1\"
    :geometry-x \"150\"
    :geometry-y \"150\")
   (\"$rbs1\"
    :is-a \"$rbs1\"
    :geometry-x \"350\"
    :geometry-y \"150\")
   (\"$cod1\"
    :is-a \"$cod1\"
    :geometry-x \"550\"
    :geometry-y \"150\")
   (\"$ter1\"
    :is-a \"$ter1\"
    :geometry-x \"750\"
    :geometry-y \"150\")
   (\"$pro2_n\"
    :is-a \"$pro2\"
    :geometry-x \"1050\"
    :geometry-y \"150\")
   (\"$rbs2_n\"
    :is-a \"$rbs2\"
    :geometry-x \"1250\"
    :geometry-y \"150\")
   (\"$cod2_n\"
    :is-a \"$cod2\"
    :geometry-x \"1450\"
    :geometry-y \"150\")
   (\"$ter2_n\"
    :is-a \"$ter2\"
    :geometry-x \"1650\"
    :geometry-y \"150\")
   (\"polsum\"
    :is-a \"polsum\"
    :geometry-x \"400\"
    :geometry-y \"300\")
   (\"ribsum\"
    :is-a \"ribsum\"
    :geometry-x \"1300\"
    :geometry-y \"300\")";

if($sips_1 == 1){
print OUT "
   (\"sips_off_1\"
    :is-a \"sips_off_1\"
    :geometry-x \"950\"
    :geometry-y \"250\")";
}
print OUT ")";

# links



print OUT "
  :links
  ((\"polsum_b_link\"   
    :terminals (\"polsum.pol_b_in\" \"$pro1.exc_pol\" \"$pro2_n.exc_pol\"))
   (\"polsum_in_link\"
    :terminals (\"polsum.pol_in\" \"$ter1.out_pol\" \"$ter2_n.out_pol\"))
   (\"ribsum_b_link\"	
    :terminals (\"ribsum.r_b_in\" \"$rbs1.exc_r\" \"$rbs2_n.exc_r\"))
   (\"ribsum_in_link\" 	    
    :terminals (\"ribsum.r_in\" \"$cod1.out_r\" \"$cod2_n.out_r\"))
   (\"${cod1}out_pol_${ter1}in_pol\"
    :terminals (\"$cod1.out_pol\" \"$ter1.in_pol\"))
   (\"${pro1}out_pol_${rbs1}in_pol\"
    :terminals (\"$pro1.out_pol\" \"$rbs1.in_pol\"))
   (\"${rbs1}out_pol_${cod1}in_pol\"
    :terminals (\"$rbs1.out_pol\" \"$cod1.in_pol\"))
   (\"${rbs1}out_r_${cod1}in_r\"
    :terminals (\"$rbs1.out_r\" \"$cod1.in_r\"))
   (\"${cod2_n}out_pol_${ter2_n}in_pol\"
    :terminals (\"$cod2_n.out_pol\" \"$ter2_n.in_pol\"))
   (\"${pro2_n}out_pol_${rbs2_n}in_pol\"
    :terminals (\"$pro2_n.out_pol\" \"$rbs2_n.in_pol\"))
   (\"${rbs2_n}out_pol_${cod2_n}in_pol\"
    :terminals (\"$rbs2_n.out_pol\" \"$cod2_n.in_pol\"))
   (\"${rbs2_n}out_r_${cod2_n}in_r\"
    :terminals (\"$rbs2_n.out_r\" \"$cod2_n.in_r\"))";

if($pro1 !~ /p0/){
print OUT "
   (\"${pro1}out_pol_lk${rbs1}in_pol_lk\"
    :terminals (\"$pro1.out_pol_lk\" \"$rbs1.in_pol_lk\"))";
}

if($rbs1 !~ /r0/){
print OUT "
   (\"${rbs1}out_r_lk${cod1}in_r_lk\"
    :terminals (\"$rbs1.out_r_lk\" \"$cod1.in_r_lk\"))";
}

if($pro2_n !~ /p0/){
print OUT "
   (\"${pro2}out_pol_lk${rbs2}in_pol_lk\"
    :terminals (\"$pro2_n.out_pol_lk\" \"$rbs2_n.in_pol_lk\"))";
}

if($rbs2_n !~ /r0/){
print OUT "
   (\"${rbs2}out_r_lk${cod2}in_r_lk\"
    :terminals (\"$rbs2_n.out_r_lk\" \"$cod2_n.in_r_lk\"))";
}

print OUT "))";

}
#---------------------------------------------------------------


sub design_two_short{
my $name=$_[0];
my $pro1=$_[1];
my $rbs1=$_[2];
my $cod1=$_[3];
my $ter1=$_[4];
my $pro2=$_[5];
my $srna2=$_[6];
my $ter2=$_[7];
my $bn;
my @dev;
my $sips_1=0;

my $filename=$name.".mdl";

$bn=$name;
$bn =~ s/[0123]/_/;
@dev=split(/_/,$bn);

open (OUT,">$filename"); 
print OUT "
(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$dev[0].png\"
  :geometry-width \"1800\"
  :geometry-height \"500\"";

# terminals
print OUT "
  :terminals	
  ((\"exc_pol\"
    :is-eq-to \"polsum.pol_b_out\"
)";

if($pro2 =~ /Ri/ || $pro2 =~ /Ai/){ # CORR 25/11/10
print OUT "
   (\"exc_tf_a\"
    :is-eq-to \"$pro2.exc_tf_a_1\")	
   (\"exc_sig_1\"
    :is-eq-to \"$pro2.exc_sig_1\"	
)";
}


if($pro2 =~ /Ra/ || $pro2 =~ /Aa/){ # CORR 25/11/10
print OUT "
   (\"exc_tf_a\"
    :is-eq-to \"$pro2.exc_tf_a_1\"	
)";
	system("./PARTS/sips_off_gen.pl sips_off_1");
	$sips_1=1;

}

print OUT "
   (\"exc_r\"
    :is-eq-to \"$rbs1.exc_r\"
)";

if($rbs1 !~ "r0"){
print OUT "
   (\"exc_rf_1\"
    :is-eq-to \"$rbs1.exc_rf_1\"	
)";
}

print OUT "
   (\"out_r\"
    :is-eq-to \"$cod1.out_r\"
)";

print OUT "
   (\"out_tf_i\"
    :is-eq-to \"$cod1.out_tf\"
)";

print OUT "
   (\"out_rna\"
    :is-eq-to \"$ter2.out_rna\"
)";

print OUT "
   (\"out_pol\"
    :is-eq-to \"polsum.pol_out\"
))";

# modules	
print OUT "
  :modules
  ((\"$pro1\"
    :is-a \"$pro1\"
    :geometry-x \"150\"
    :geometry-y \"150\")
   (\"$rbs1\"
    :is-a \"$rbs1\"
    :geometry-x \"350\"
    :geometry-y \"150\")
   (\"$cod1\"
    :is-a \"$cod1\"
    :geometry-x \"550\"
    :geometry-y \"150\")
   (\"$ter1\"
    :is-a \"$ter1\"
    :geometry-x \"750\"
    :geometry-y \"150\")
   (\"$pro2\"
    :is-a \"$pro2\"
    :geometry-x \"1050\"
    :geometry-y \"150\")
   (\"$srna2\"
    :is-a \"$srna2\"
    :geometry-x \"1350\"
    :geometry-y \"150\")
   (\"$ter2\"
    :is-a \"$ter2\"
    :geometry-x \"1650\"
    :geometry-y \"150\")
   (\"polsum\"
    :is-a \"polsum\"
    :geometry-x \"400\"
    :geometry-y \"300\")";

print OUT ")";

# links

print OUT "
  :links
  ((\"polsum_b_link\"   
    :terminals (\"polsum.pol_b_in\" \"$pro1.exc_pol\" \"$pro2.exc_pol\"))
   (\"polsum_in_link\"
    :terminals (\"polsum.pol_in\" \"$ter1.out_pol\" \"$ter2.out_pol\")) 
   (\"${cod1}out_pol_${ter1}in_pol\"
    :terminals (\"$cod1.out_pol\" \"$ter1.in_pol\"))
   (\"${pro1}out_pol_${rbs1}in_pol\"
    :terminals (\"$pro1.out_pol\" \"$rbs1.in_pol\"))
   (\"${rbs1}out_pol_${cod1}in_pol\"
    :terminals (\"$rbs1.out_pol\" \"$cod1.in_pol\"))
   (\"${rbs1}out_r_${cod1}in_r\"
    :terminals (\"$rbs1.out_r\" \"$cod1.in_r\"))
   (\"${srna2}out_pol_${ter2}in_pol\"
    :terminals (\"$srna2.out_pol\" \"$ter2.in_pol\"))
   (\"${pro2}out_pol_${srna2}in_pol\"
    :terminals (\"$pro2.out_pol\" \"$srna2.in_pol\"))";

if($pro1 !~ /p0/){
print OUT "
   (\"${pro1}out_pol_lk${rbs1}in_pol_lk\"
    :terminals (\"$pro1.out_pol_lk\" \"$rbs1.in_pol_lk\"))";
}

if($rbs1 !~ /r0/){
print OUT "
   (\"${rbs1}out_r_lk${cod1}in_r_lk\"
    :terminals (\"$rbs1.out_r_lk\" \"$cod1.in_r_lk\"))";
}


if($pro2 !~ /p0/){
print OUT "
   (\"${pro2}out_pol_lk${srna2}in_pol_lk\"
    :terminals (\"$pro2.out_pol_lk\" \"$srna2.in_pol_lk\"))
   (\"${srna2}out_pol_lk${ter2}in_pol_lk\"
    :terminals (\"$srna2.out_pol_lk\" \"$ter2.in_pol_lk\"))";
}

print OUT "))";

}
#---------------------------------------------------------------


sub design_three{
my $name=$_[0];
my $pro1=$_[1];
my $rbs1=$_[2];
my $cod1=$_[3];
my $ter1=$_[4];
my $pro2=$_[5];
my $rbs2=$_[6];
my $cod2=$_[7];
my $ter2=$_[8];
my $pro3=$_[9];
my $srna3=$_[10];
my $ter3=$_[11];


my $bn;
my @dev;
my $sips_1=0;

my $filename=$name.".mdl";

$bn=$name;
$bn =~ s/[0123]/_/;
@dev=split(/_/,$bn);

my $pro2_n=$pro2;	# n means name
my $rbs2_n=$rbs2;
my $cod2_n=$cod2;
my $ter2_n=$ter2;

# check parts' name
if($pro2 eq $pro1){
	$pro2_n=$pro2."_2";
}
if($rbs2 eq $rbs1){
	$rbs2_n=$rbs2."_2";
}
if($cod2 eq $cod1){
	$cod2_n=$cod2."_2";
}
if($ter2 eq $ter1){
	$ter2_n=$ter2."_2";
}
open (OUT,">$filename"); 
print OUT "
(define-module
  :class \"$name\"
  :super-classes (\"module\")
  :icon \"$dev[0].png\"
  :geometry-width \"2400\"
  :geometry-height \"500\"";

# terminals
print OUT "
  :terminals	
  ((\"exc_pol\"
    :is-eq-to \"polsum.pol_b_out\"
    :geometry-side \"TOP\"
    :geometry-position \"0.1\")";

if($pro2_n =~ /Ai/){ # CORR 25/11/10
print OUT "
   (\"exc_tf_a_1\" 
    :is-eq-to \"$pro2_n.exc_tf_a_1\")	
   (\"exc_sig_1\"
    :is-eq-to \"$pro2_n.exc_sig_1\"	
)";
}

if($pro3 =~ /Ra/){
print OUT "
   (\"exc_tf_i2\"
    :is-eq-to \"$pro3.exc_tf_a_1\"	
)";
#	system("./PARTS/sips_off_gen.pl sips_off_1");
#	$sips_1=1;
}elsif($pro3 =~ /Ai/){ # CORR 25/11/10
print OUT "
   (\"exc_tf_a_1\"
    :is-eq-to \"$pro3.exc_tf_a_1\")	
   (\"exc_sig_1\"
    :is-eq-to \"$pro3.exc_sig_1\"	
)";
}

print OUT "
   (\"exc_r\"
    :is-eq-to \"ribsum.r_b_out\"
)";

if($rbs2 !~ "r0"){

print OUT "
   (\"exc_rf_1\"
    :is-eq-to \"$rbs2.exc_rf_1\"	
)
   (\"out_rna_i\"
    :is-eq-to \"$ter3.out_rna\"	
)";
}

print OUT "
   (\"out_r\"
    :is-eq-to \"ribsum.r_out\"
)";

print OUT "
   (\"out_tf_i1\"
    :is-eq-to \"$cod1.out_tf\"
)";

if($name eq "not0"){
print OUT "
   (\"out_tf\"
    :is-eq-to \"$cod2_n.out_tf\"
)";
}elsif($name eq "not1"){
print OUT "
   (\"out_tf_i2\"
    :is-eq-to \"$cod2_n.out_tf\"
)
   (\"out_rna\"
    :is-eq-to \"$ter3.out_rna\"	
)";
}

print OUT "
   (\"out_pol\"
    :is-eq-to \"polsum.pol_out\"
))";

# modules	
print OUT "
  :modules
  ((\"$pro1\"
    :is-a \"$pro1\"
    :geometry-x \"150\"
    :geometry-y \"150\")
   (\"$rbs1\"
    :is-a \"$rbs1\"
    :geometry-x \"350\"
    :geometry-y \"150\")
   (\"$cod1\"
    :is-a \"$cod1\"
    :geometry-x \"550\"
    :geometry-y \"150\")
   (\"$ter1\"
    :is-a \"$ter1\"
    :geometry-x \"750\"
    :geometry-y \"150\")
   (\"$pro2_n\"
    :is-a \"$pro2\"
    :geometry-x \"1050\"
    :geometry-y \"150\")
   (\"$rbs2_n\"
    :is-a \"$rbs2\"
    :geometry-x \"1250\"
    :geometry-y \"150\")
   (\"$cod2_n\"
    :is-a \"$cod2\"
    :geometry-x \"1450\"
    :geometry-y \"150\")
   (\"$ter2_n\"
    :is-a \"$ter2\"
    :geometry-x \"1650\"
    :geometry-y \"150\")
   (\"$pro3\"
    :is-a \"$pro3\"
    :geometry-x \"1800\"
    :geometry-y \"150\")
   (\"$srna3\"
    :is-a \"$srna3\"
    :geometry-x \"2000\"
    :geometry-y \"150\")
   (\"$ter3\"
    :is-a \"$ter3\"
    :geometry-x \"2200\"
    :geometry-y \"150\")
   (\"polsum\"
    :is-a \"polsum\"
    :geometry-x \"400\"
    :geometry-y \"300\")
   (\"ribsum\"
    :is-a \"ribsum\"
    :geometry-x \"1300\"
    :geometry-y \"300\")";
print OUT ")";

# links

print OUT "
  :links
  ((\"polsum_b_link\"   
    :terminals (\"polsum.pol_b_in\" \"$pro1.exc_pol\" \"$pro2_n.exc_pol\" \"$pro3.exc_pol\"))
   (\"polsum_in_link\"
    :terminals (\"polsum.pol_in\" \"$ter1.out_pol\" \"$ter2_n.out_pol\" \"$ter3.out_pol\"))
   (\"ribsum_b_link\"
    :terminals (\"ribsum.r_b_in\" \"$rbs1.exc_r\" \"$rbs2_n.exc_r\"))
   (\"ribsum_in_link\"
    :terminals (\"ribsum.r_in\" \"$cod1.out_r\" \"$cod2_n.out_r\"))
   (\"${cod1}out_pol_${ter1}in_pol\"
    :terminals (\"$cod1.out_pol\" \"$ter1.in_pol\"))
   (\"${pro1}out_pol_${rbs1}in_pol\"
    :terminals (\"$pro1.out_pol\" \"$rbs1.in_pol\"))
   (\"${rbs1}out_pol_${cod1}in_pol\"
    :terminals (\"$rbs1.out_pol\" \"$cod1.in_pol\"))
   (\"${rbs1}out_r_${cod1}in_r\"
    :terminals (\"$rbs1.out_r\" \"$cod1.in_r\"))
   (\"${cod2_n}out_pol_${ter2_n}in_pol\"
    :terminals (\"$cod2_n.out_pol\" \"$ter2_n.in_pol\"))
   (\"${pro2_n}out_pol_${rbs2_n}in_pol\"
    :terminals (\"$pro2_n.out_pol\" \"$rbs2_n.in_pol\"))
   (\"${rbs2_n}out_pol_${cod2_n}in_pol\"
    :terminals (\"$rbs2_n.out_pol\" \"$cod2_n.in_pol\"))
   (\"${rbs2_n}out_r_${cod2_n}in_r\"
    :terminals (\"$rbs2_n.out_r\" \"$cod2_n.in_r\"))
   (\"${srna3}out_pol_${ter3}in_pol\"
    :terminals (\"$srna3.out_pol\" \"$ter3.in_pol\"))
   (\"${pro3}out_pol_${srna3}in_pol\"
    :terminals (\"$pro3.out_pol\" \"$srna3.in_pol\"))";

if($pro2_n !~ /p0/){
print OUT "
   (\"${pro2}out_pol_lk${rbs2}in_pol_lk\"
    :terminals (\"$pro2.out_pol_lk\" \"$rbs2.in_pol_lk\"))";
}

if($rbs2_n !~ /r0/){
print OUT "
   (\"${rbs2}out_r_lk${cod2}in_r_lk\"
    :terminals (\"$rbs2.out_r_lk\" \"$cod2.in_r_lk\"))";
}

if($pro3 !~ /p0/){
print OUT "
   (\"${pro3}out_pol_lk${srna3}in_pol_lk\"
    :terminals (\"$pro3.out_pol_lk\" \"$srna3.in_pol_lk\"))
   (\"${srna3}out_pol_lk${ter3}in_pol_lk\"
    :terminals (\"$srna3.out_pol_lk\" \"$ter3.in_pol_lk\"))";
}

print OUT "))";

}
#---------------------------------------------------------------

1;
		
