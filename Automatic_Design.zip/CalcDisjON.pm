#! /usr/bin/perl
# Calculating final layer schemes involving an extra (first_f) set of OR gates
# Called if and only if free<3
use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
our @num_cl;
our @final_c;

sub final_or_nor{
my $s_kind=$_[0];
my $free=$_[1];
my $cc=$_[2];

my $i;
my $rcl;			# number of clauses which produce a repressor
my $cvt;			# number of clauses whose output can be converted into an activator
my $fx;				# number of fixed regulatory factors
my $rx;				# number of fixed repressors
my $tnf;			# total number of factors 
my $oi;				# out_int
my $af=0;                       # A number - for reg_fac
my $rf=0;                       # R number - for reg_fac
my $lf=0;                       # l number - for reg_fac
my $kf=0;                       # k number - for reg_fac
my $orn;			# Number of OR gates
my @oor;			# Vector containing the OR outputs
my $ff="";				# first-final layer
my $sf="";				# second-final layer


# Evalutating the existence of a solution
if($num_cl[$sk] == 3 && $free != 0){
        return($cc);		# No additional OR-NOR solution is allowed
}

if($num_cl[$sk] == 4 && $free > 1){
	return($cc);		# No additional OR-NOR solution is allowed
}

$rcl=$num_cl[$sk]-$free;
if($rcl%2 == 0){
	$cvt=$rcl;
}else{
	$cvt=$rcl-1;
}

$fx=$num_cl[$sk]-$cvt;
$tnf=$cvt/2 + $fx;
if($tnf > 4){
	return($cc);		# No additional OR-NOR solution is possible
}

# Looking for the OR-NOR solution
$cc++;

if( ($num_cl[$sk] == 4 && $free == 0) || ($num_cl[$sk] == 5 && $free == 1) || ($num_cl[$sk] == 6 && $free == 0)){
	# Recalculating $cvt and $fx to optimize the circuit scheme
	if($cvt/2+$fx+1 < 5){
		$cvt -= 2;
		$fx += 2;
	}
}

$rx=$fx-$free;

# Calculating out_int
for($i=0; $i<$free; $i++){
        $oi .= 'l';
        $lf++;
}
for($i=0; $i<$rx; $i++){
        $oi .= 'R';
        $rf++;
}
for($i=0; $i<$cvt; $i++){
        $oi .= 'A';
        $af++;
}

$orn=$cvt/2;

my $out_l=$free;

# Assigning an output to each OR
for($i=0; $i<$orn; $i++){
	if($out_l < 2){
		$oor[$i] = 'l';
		$out_l++;
		$lf++;
	}else{
		$oor[$i] = 'R';
		$rf++;
	}
}
# Reordering the OR output
my @t_oor=();
for($i=0; $i<$orn; $i++){
	if($oor[$i] eq 'l'){
		push(@t_oor,$oor[$i]);
	}else{
		unshift(@t_oor,$oor[$i]);
	}
}
@oor=@t_oor;

my $str;
# Writing the first-final sublayer
for($i=0; $i<$orn; $i++){
	$str = "or2AA_"."$oor[$i]".',';
	$ff .= $str;
}


$ff =~ s/,$//;

# Writing the second-final sublayer
my $ni=$orn+$fx;					# number-input to the final NOR
$sf = "nor"."$ni";

for($i=0;$i<$rx;$i++){
        $sf .= 'R';
}
for($i=0; $i<$orn; $i++){
	$sf .= "$oor[$i]";
}
for($i=0;$i<$free;$i++){
	$sf .= 'l';
}

if($s_kind eq "POS"){
	$sf .= "_f";
}else{
	$sf .= "_R,not1R_f";
}

# Adding the new solution to final_c

$final_c[$cc][0] = "disj OR-NOR";
$final_c[$cc][1] = $oi;
$final_c[$cc][2] = $ff;
$final_c[$cc][3] = $sf;
if($s_kind eq "POS"){
        $final_c[$cc][4] = $num_cl[$sk]+$orn+1;
}else{
        $final_c[$cc][4] = $num_cl[$sk]+$orn+2;
}
$final_c[$cc][5] = 0;
$final_c[$cc][6] = $af;
$final_c[$cc][7] = $rf;
$final_c[$cc][8] = $kf;
$final_c[$cc][9] = $lf;

return($cc);

}
#-----------------------------------------------------


1;

