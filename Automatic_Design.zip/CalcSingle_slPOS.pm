#! /usr/bin/perl
use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
#our @num_cl;
our @final_c;

our @sg_to_final;
our @v_oc;

# final_c - columns (each row is a possible configuration)
# 0: single/disj
# 1: out_int
# 2: first_f
# 3: second_f
# 4: gene_n
# 5: leak_p
# 6: (A)
# 7: (R)
# 8: (k)
# 9: (l)


sub final_layer_slPOS{
my $free=$_[0];			# number of free RBSs
my $cc=0;			# configuration-counter, first entry in @final_c; 
my $i;
my $qt;
my $re;
my $u_cl;
my $d_cl;
my $t_cl;
my $q_cl;
my $df;

# $cc must be equal to 0
######### Single solutions
######### One single negated literal - it is sent directly to the final gate's RBS
if(scalar(@sg_to_final) == 1){
  init($cc);
  ### case 1) The internal layer produces one Repressor 
  $final_c[$cc][0] = "compact";	
  for($i=0; $i<scalar(@v_oc); $i++){
    $final_c[$cc][1] .= "R";
  }
if(scalar(@v_oc)>0){	 
  $final_c[$cc][2] = "";
  $final_c[$cc][3] = "nor2Rc_f";		
  $final_c[$cc][4] = scalar(@v_oc)+1;
  $final_c[$cc][5] = 1;	
  $final_c[$cc][7]++;
}else{
  $final_c[$cc][2] = "";
  $final_c[$cc][3] = "nor1c_f";		
  $final_c[$cc][4] = scalar(@v_oc)+1;
  $final_c[$cc][5] = 0;	
}
  ### case 2) The internal layer produces one lock 
  if(scalar(@v_oc)-$free == 0){
    $cc++;
    init($cc);
    $final_c[$cc][0] = "compact";
    for($i=0; $i<scalar(@v_oc); $i++){
      $final_c[$cc][1] .= "l";
    }
    $final_c[$cc][2] = "";
    $final_c[$cc][3] = "nor2lc_f";
    $final_c[$cc][4] = scalar(@v_oc)+1;
    $final_c[$cc][5] = 1; 	
    $final_c[$cc][9]++;
  }
}elsif(scalar(@sg_to_final) == 2){
  print"TWO SIGNALS TO FINAL \n";
  init($cc);
  ### case 1) The internal layer produces one Repressor
  if(scalar(@v_oc) > 0){
    $final_c[$cc][0] = "compact";		 
    for($i=0; $i<scalar(@v_oc); $i++){
      $final_c[$cc][1] .= "R";
    }
    $final_c[$cc][2] = "";
    $final_c[$cc][3] = "nor3Rcc_f";		
    $final_c[$cc][4] = scalar(@v_oc)+1;
    $final_c[$cc][5] = 1;	
    $final_c[$cc][7]++;
  }else{
  ### case 2) There is no internal layer
    $final_c[$cc][0] = "compact";		 
    $final_c[$cc][2] = "";
    $final_c[$cc][3] = "nor2cc_f";		
    $final_c[$cc][4] = scalar(@v_oc)+1;
  }
}elsif(scalar(@sg_to_final) == 3){
  print"THEEE SIGNALS TO FINAL \n";
  init($cc);
  $final_c[$cc][0] = "compact";		 
  if(scalar(@v_oc) > 0){
    die "ERROR!!!";
  }
  $final_c[$cc][2] = "yes0";
  $final_c[$cc][3] = "nor3Ricc_f";		
  $final_c[$cc][4] = 2;
  $final_c[$cc][5] = 1;	
  $final_c[$cc][7]++;
}elsif(scalar(@sg_to_final) == 4){
  print"FOUR SIGNALS TO FINAL \n";
  $final_c[$cc][0] = "compact";		 
  
  if(scalar(@v_oc) > 0){
    die "ERROR!!!";
  }
  $final_c[$cc][2] = "yes0";  # the second yes0 gate is added into ConnectionMakerCompact
  $final_c[$cc][3] = "nor4RiRicc_f";		
  $final_c[$cc][4] = 3;
  $final_c[$cc][5] = 1;	
  $final_c[$cc][7] +=1;
  }
  
return($cc);
}
#----------------------------------------


sub init{
my $cc=$_[0];
my $i;
	$final_c[$cc][1]="";
	for($i=6; $i<10; $i++){
		$final_c[$cc][$i] = 0;
	}
}
#----------------------------------------

1;

