#! /usr/bin/perl
use strict;

sub printkm{
my $nr=$_[0];
my $nc=$_[1];
my $kv=$_[2];
my $i;
my $j;

print "KM \n";
print "---------------------------------- \n";
        for($i=0; $i<$nr+1; $i++){
                for($j=0; $j<$nc+1; $j++){
                        print "${$kv}[$i][$j] ";
                }
                print "\n";
        }
print "---------------------------------- \n";
}

1;
