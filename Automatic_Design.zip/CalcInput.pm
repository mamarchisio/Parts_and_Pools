#! /usr/bin/perl
use strict;
# Finding unique and degenerate input layers
our @num_in;
our @sg;
our @nsg;
our @sign;
our $sk;
our @reg_fac;
our @gene_n;
our @input_l;
our @sg_min;
our @common=();         # array of negated inputs that share a pool
our $common_flag;
our @co_sig=();
our @co_sig_cs=();

sub all_inp{
my $h_p=$_[0];

my @deg_il=();
my $i;
my $j;
my $sig;
my $nsig;

	for($i=0; $i<$num_in[$sk]; $i++){
		# unique solutions
		$sig=$sg[$i];
		$nsig=uc($sig);
		if($sign[$i][1] == 0){
			if(${$h_p}{$sig} eq 'p'){
				$deg_il[$i][0]="yes0";
			}else{
				$deg_il[$i][0]="yes1";
			}
		}
			
		if($sign[$i][0] != 0 && $sign[$i][1] != 0){
		  for(my $j=0; $j<scalar(@sg_min); $j++){
		    if($nsig eq $sg_min[$j]){
		      $deg_il[$i][0]="not2";
		    }
		  }
		  if(${$h_p}{$sig} eq 'p' &&  ${$h_p}{$nsig} eq 'p'){	
		    $deg_il[$i][0]="not0";
		  }elsif(${$h_p}{$sig} eq 'p' &&  ${$h_p}{$nsig} eq 'r'){
		    $deg_il[$i][0]="not1";
		  }elsif(${$h_p}{$sig} eq 'r' &&  ${$h_p}{$nsig} eq 'p'){
		    $deg_il[$i][0]="not2";
		  }elsif(${$h_p}{$sig} eq 'r' &&  ${$h_p}{$nsig} eq 'r'){
		    $deg_il[$i][0]="not3";
		  }
		}
		# degenerate solutions
		if($sign[$i][0] == 0){
			for($j=0; $j<2; $j++){
				if($j == 0){
					if(${$h_p}{$nsig} eq 'p'){
						$deg_il[$i][$j]="not2";
					}else{
						$deg_il[$i][$j]="not3";
					}
				}elsif($j == 1){
					if(${$h_p}{$nsig} eq 'p'){
						$deg_il[$i][$j]="not0";
					}else{
						$deg_il[$i][$j]="not1";
					}
				}
			}
		}
	}

	return(@deg_il);
}
#----------------------------------------------------------------------

sub inp_config{
my $sd=$_[0];	# signal degeneracy
my $di=$_[1];	# degenerate input layers

my @input_c=();
my $i0;
my $i1;
my $i2;
my $i3;
my $cfg;

	$cfg=0;
	if($sg[0] ne ""){
		for($i0=0; $i0<${$sd}[0];$i0++){
			if($sg[1] ne ""){
				for($i1=0; $i1<${$sd}[1];$i1++){
					if($sg[2] ne ""){
						for($i2=0; $i2<${$sd}[2];$i2++){
							if($sg[3] ne ""){
								for($i3=0; $i3<${$sd}[3];$i3++){			
									$input_c[$cfg][0]=${$di}[0][$i0];
									$input_c[$cfg][1]=${$di}[1][$i1];
									$input_c[$cfg][2]=${$di}[2][$i2];
									$input_c[$cfg][3]=${$di}[3][$i3];
									$cfg++;								
								}
							}else{
								
								$input_c[$cfg][0]=${$di}[0][$i0];
								$input_c[$cfg][1]=${$di}[1][$i1];
								$input_c[$cfg][2]=${$di}[2][$i2];
								$cfg++;
							}
						}
					}else{
						$input_c[$cfg][0]=${$di}[0][$i0];
						$input_c[$cfg][1]=${$di}[1][$i1];
						$cfg++;
					}
				}
			}else{
				$input_c[$cfg][0]=${$di}[0][$i0];
				$cfg++;
			}
		}
	}

	my $i;
	my $j;
	for($i=0;$i<$cfg;$i++){
		for($j=0;$j<4;$j++){
		}
	}
	
	return(@input_c);
}
#----------------------------------------------------------------------


sub il_cost{		# counting the regulatory factors due to the input layer
my $s_kind=$_[0];
my $sl=$_[1];
my $i;	
	if($s_kind eq "POS"){
		for($i=0; $i<$num_in[$sk]; $i++){
			if($input_l[$sl][$i] eq "yes0"){
				$reg_fac[$sl][1]++;    # adding a repressor
				$gene_n[$sl]++;
				next;
			}				

			if($input_l[$sl][$i] eq "yes1"){
				next;
			}				
			
			if($input_l[$sl][$i] eq "not0"){
				$reg_fac[$sl][1] += 2;
				$gene_n[$sl] +=2;
				next;
			}
			
			if($input_l[$sl][$i] eq "not1"){
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][3]++;
				$gene_n[$sl] +=2;
				next;
			}

			if($input_l[$sl][$i] eq "not2"){	
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=1;
				next;
			}	
				
			if($input_l[$sl][$i] eq "not3"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][3]++;	
				$gene_n[$sl] +=2;
				next;
			}
		}
		# Reducing the cost if some regulatory factor pools can be contracted 
		if($common_flag eq 'y'){
			my $ctr=scalar(@common); # number of possible contractions (max 2)
			for(my $j=0; $j<$ctr; $j++){ 
				my $ct_r=0;
				my $ct_l=0;
				for(my $k=0; $k<scalar(@{$co_sig_cs[$j]}); $k++){
					if($input_l[$sl][$co_sig_cs[$j][$k]] eq "not0" || $input_l[$sl][$co_sig_cs[$j][$k]] eq "not2"){
						$ct_r++;		
					}elsif($input_l[$sl][$co_sig_cs[$j][$k]] eq "not1" || $input_l[$sl][$co_sig_cs[$j][$k]] eq "not3"){
						$ct_l++;
					}
				}
	                        if($ct_r == 2){
        	                        $reg_fac[$sl][1]--;
                	        }
                        	if($ct_l == 2){
                                	$reg_fac[$sl][3]--;
                        	}
			}
		}				
	}elsif($s_kind eq "SOP"){
		for($i=0; $i<$num_in[$sk]; $i++){
			if($input_l[$sl][$i] eq "yes0"){
				$reg_fac[$sl][0]++;    # adding an activator
				$gene_n[$sl]++;
				next;
			}				

			if($input_l[$sl][$i] eq "yes1"){
				next;
			}				
			
			if($input_l[$sl][$i] eq "not0"){
				$reg_fac[$sl][0] += 2;
				$reg_fac[$sl][3] += 1;
				$gene_n[$sl] +=3;
				next;
			}
			
			if($input_l[$sl][$i] eq "not1"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;
				$gene_n[$sl] +=3;
				next;
			}

			if($input_l[$sl][$i] eq "not2"){
				$reg_fac[$sl][0]++;
				$reg_fac[$sl][1]++;
				$gene_n[$sl] +=2;
				next;
			}	
				
			if($input_l[$sl][$i] eq "not3"){
				$reg_fac[$sl][1]++;
				$reg_fac[$sl][2]++;	
				$gene_n[$sl] +=2;
				next;
			}
	
		}
	}

}	
#----------------------------------------------------------------------


1;
