#! /usr/bin/perl

`rm *mdl`;
`rm *txt`;
`cp LIB/ALL_NEW_LIB.mdl .`;

