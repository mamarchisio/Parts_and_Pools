#! /usr/bin/perl
use PartsMaker;
use DevicesDesigner;

use strict;
our $sk;
our @out_int;
our @first_f;
our @second_f;
our @gene_n;
our @reg_fac;
our @leak_p;
#our @num_cl;
our @final_c;
our @lts;
our $two;

our @sg_to_final;
our @v_oc;

# final_c - columns (each row is a possible configuration)
# 0: single/disj
# 1: out_int
# 2: first_f
# 3: second_f
# 4: gene_n
# 5: leak_p
# 6: (A)
# 7: (R)
# 8: (k)
# 9: (l)


sub final_layer_mixed{
my $cc=0;			# configuration-counter, first entry in @final_c; 
my $i;
my $qt;
my $re;
my $u_cl;
my $d_cl;
my $t_cl;
my $q_cl;
my $df;

# $cc must be equal to 0
######### Single solutions
init($cc);
### case 1) The input layer produces one TF, always 
$final_c[$cc][0] = "mixed";	
if($two =~ /[abcd]/){
  $final_c[$cc][1] .= "A";
  $final_c[$cc][3] = "or1A_";	
  $final_c[$cc][4] = 3;
  $final_c[$cc][6]++;	
}else{
  $final_c[$cc][1] .= "RR";
  $final_c[$cc][3] = "nand2RR_";
  $final_c[$cc][4] = 3;	
  $final_c[$cc][7] +=2;
}

$final_c[$cc][2] = "";

if(scalar(@lts) == 1){
	if($lts[0] =~ /[abcd]/){
  		$final_c[$cc][3] .= "yes1i_f";
	}else{
  		$final_c[$cc][3] .= "not1c_f";
	}
}elsif(scalar(@lts) == 2){
        if($lts[0] =~ /[abcd]/){
                $final_c[$cc][3] .= "and2ii_f";
        }else{
                $final_c[$cc][3] .= "nor2cc_f";
        }
}	

$final_c[$cc][5] = 0;

return($cc);
}
#----------------------------------------


sub init{
my $cc=$_[0];
my $i;
	$final_c[$cc][1]="";
	for($i=6; $i<10; $i++){
		$final_c[$cc][$i] = 0;
	}
}
#----------------------------------------

1;

