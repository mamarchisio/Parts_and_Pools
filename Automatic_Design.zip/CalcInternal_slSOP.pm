#! /usr/bin/perl
use strict;
our @out_int;
our @num_cl;
our @lg_cl;
our @v_cl=();
our @sol_prm;
our @sol_rbs;
our @int_lay;
our $sk;
our @sg_min;
our @sg_plus;
our @fm_list;
our $int_gt;



sub internal_layer_slSOP{
my $s_kind=$_[0];
my $sl=$_[1];

my $i;
my $j;
my $gate;
my $index;
my $g_sig;
my $prm;
my @sig_p;
my $n_sig;
my $rbs;
my @sig_r;
my @out_s=();
my $out;
my @uin;		# unordered input
my @oin;		# ordered input	
my $el;
$int_gt=$num_cl[$sk]-scalar(@sg_min);
my $fm = $fm_list[$sk];       
@out_s=split(//,$out_int[$sl]);
for($i=0;$i<scalar(@sg_min);$i++){
  push(@out_s,'A');
}
for($i=0;$i<$num_cl[$sk];$i++){
  @uin=();
  @oin=();
  $gate="";
  @sig_p=();
					
  $prm=$sol_prm[$sl][$i];
  @sig_p=split(//,$prm);
  $n_sig=scalar(@sig_p);
  for($j=0; $j<$n_sig; $j++){   # every signal to the promoter wants an activator on the internal gate
    if($sig_p[$j] =~ /[abcd]/){
      push(@uin,"Ai");
    }else{
      push(@uin,"Aa");
    }
  }
   
  $rbs=$sol_rbs[$sl][$i];
  @sig_r=split(//,$rbs);
  $n_sig=scalar(@sig_r);
  for($j=0; $j<$n_sig; $j++){
    if($sig_r[$j] =~ /[abcd]/){ # every positive signal to the rbs is not accompanied by any regulatory factor
      push(@uin,"i");
    }
    if($sig_r[$j] =~ /[ABCD]/){ # every negative signal to the rbs requires a key
      push(@uin,"k");
    }
  }

 $g_sig=scalar(@sig_p)+scalar(@sig_r); 

  if($lg_cl[$i] == 1){
    if($v_cl[$i] =~ /[ABCD]/){
      $gate="";
    }else{
      for(my $j=0; $j<scalar(@sg_plus); $j++){
        my $neg=uc($sg_plus[$j]);
        if($fm =~ /$neg/){
          $gate="";
        }else{
          $gate="yes1";
        }
      }
    }
  }else{
    $index=$g_sig;
    $gate="and".$index;
  }

 if($gate eq ""){
    next;
  }


  # Reordering the input -- Ai Aa k i
  foreach $el ("Ai","Aa",'k','i'){
    for($j=0; $j<scalar(@uin); $j++){
      if($uin[$j] eq $el){
	push(@oin,$el);
      }
    }
  }

  # Adding the input to the gate
  for($j=0; $j<scalar(@oin); $j++){
    $gate .=$oin[$j]
  }
  
  $out=$out_s[$i];
  $gate .= "_";
  $gate .= "$out";
  $int_lay[$sl][$i]=$gate;
}
}
#----------------------------------------------------------------------


sub re_out_int_slSOP{
my $sl=$_[0];

my @new_outa=();
my @tmp=split(//,$out_int[$sl]);
my $i;
my $j;
my $loi="";

$int_gt=$num_cl[$sk]-scalar(@sg_min);

	for($i=0;$i<$int_gt;$i++){
		$new_outa[$i]="no";
	}

	f_l:for($i=0;$i<$int_gt;$i++){
		if($tmp[$i] eq 'k'){
			for($j=0;$j<$int_gt;$j++){
				if($sol_rbs[$sl][$j] eq "" && $new_outa[$j] eq "no"){
						$new_outa[$j] = $tmp[$i];
						next f_l;
				}
			}
		}
	}	

	s_l:for($i=0;$i<$int_gt;$i++){
		if($tmp[$i] eq 'A' || $tmp[$i] eq 'f'){
			for($j=0;$j<$int_gt;$j++){
				if($new_outa[$j] eq "no"){
					$new_outa[$j] = $tmp[$i];
					next s_l;
				}
			}
		}
	}							

	for($i=0;$i<$int_gt;$i++){
		$loi .= $new_outa[$i];
	}
	$out_int[$sl]=$loi;
}
#----------------------------------------------------------------------








				
1;
